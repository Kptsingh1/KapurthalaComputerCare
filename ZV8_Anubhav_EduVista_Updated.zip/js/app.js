/* ==========================================================================
   APP.JS — Shared Application Utilities
   Computer Care (Anubhav EduVista) Academy Management System
   ========================================================================== */

/* ---------- THEME ---------- */
const ThemeManager = {
  init() {
    const saved = DB.getSettings().theme || 'dark';
    this.apply(saved);
  },
  apply(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    DB.saveSettings({ theme });
    if (typeof AcademyDesign !== 'undefined') AcademyDesign.applyFromSettings();
    const btn = document.getElementById('themeToggle');
    if (btn) btn.innerHTML = theme==='dark' ? '☀️' : '🌙';
  },
  injectFeatureLinksV2() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const session = Auth.getSession && Auth.getSession();
    const canUseManagementLinks = !session || session.role === 'admin' || session.role === 'teacher';
    document.querySelectorAll('.nav-menu').forEach(nav => {
      const addLink = (href, icon, label, afterEl, target) => {
        const existing = nav.querySelector(`a[href="${href}"]`);
        if (existing) return existing;
        const link = document.createElement('a');
        link.href = href;
        link.className = 'nav-item' + (currentPage === href ? ' active' : '');
        if (target) link.target = target;
        link.innerHTML = `<span class="nav-icon">${icon}</span><span class="nav-label">${label}</span>`;
        if (afterEl) afterEl.insertAdjacentElement('afterend', link);
        else nav.appendChild(link);
        return link;
      };

      const courses = nav.querySelector('a[href="courses.html"]');
      let inquiries = null;
      let internship = null;
      if (canUseManagementLinks) {
        inquiries = addLink('inquiries.html', '&#128222;', 'Inquiries', courses);
        internship = addLink('internship.html', '&#128188;', 'Internships', inquiries || courses);
      }

      let publicTitle = nav.querySelector('[data-public-section]');
      if (!publicTitle) {
        publicTitle = [...nav.querySelectorAll('.nav-section-title')]
          .find(el => el.textContent.trim().toLowerCase() === 'public') || null;
        if (publicTitle) publicTitle.dataset.publicSection = 'true';
      }
      if (!publicTitle) {
        publicTitle = document.createElement('span');
        publicTitle.className = 'nav-section-title';
        publicTitle.dataset.publicSection = 'true';
        publicTitle.textContent = 'Public';
        (internship || inquiries || courses || nav.lastElementChild).insertAdjacentElement('afterend', publicTitle);
      }

      const publicLink = addLink('public.html', '&#127760;', 'Public Website', publicTitle, '_blank');
      addLink('blog.html', '&#128240;', 'Blog', publicLink, '_blank');
    });
  },
  toggle() {
    const current = document.documentElement.getAttribute('data-theme');
    this.apply(current==='dark' ? 'light' : 'dark');
  },
};

/* ---------- SIDEBAR ---------- */
const Sidebar = {
  init() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    if (!sidebar) return;
    this.injectBackendLink();
    ThemeManager.injectFeatureLinksV2();

    const toggleBtn = document.getElementById('toggleSidebar');
    if (toggleBtn) toggleBtn.addEventListener('click', () => this.toggle());

    if (overlay) overlay.addEventListener('click', () => this.closeMobile());

    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.nav-item').forEach(item => {
      const href = item.getAttribute('href');
      if (href && currentPage.includes(href.replace('.html',''))) {
        item.classList.add('active');
      }
    });
  },
  injectBackendLink() {
    const session = Auth.getSession && Auth.getSession();
    if (!session || session.role !== 'admin') return;
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.nav-menu').forEach(nav => {
      if (nav.querySelector('a[href="backend.html"]')) return;
      const link = document.createElement('a');
      link.href = 'backend.html';
      link.className = 'nav-item' + (currentPage === 'backend.html' ? ' active' : '');
      link.innerHTML = '<span class="nav-icon">🗄️</span><span class="nav-label">Backend & DB</span>';
      const reports = nav.querySelector('a[href="reports.html"]');
      if (reports) reports.insertAdjacentElement('afterend', link);
      else nav.appendChild(link);
    });
  },
  injectFeatureLinksLegacy() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.nav-menu').forEach(nav => {
      if (!nav.querySelector('a[href="internship.html"]')) {
        const link = document.createElement('a');
        link.href = 'internship.html';
        link.className = 'nav-item' + (currentPage === 'internship.html' ? ' active' : '');
        link.innerHTML = '<span class="nav-icon">💼</span><span class="nav-label">Internships</span>';
        const courses = nav.querySelector('a[href="courses.html"]');
        if (courses) courses.insertAdjacentElement('afterend', link);
        else nav.appendChild(link);
      }
    });
  },
  injectFeatureLinks() {
    ThemeManager.injectFeatureLinksV2();
  },
  toggle() {
    const sidebar = document.getElementById('sidebar');
    if (!sidebar) return;
    if (window.innerWidth < 992) {
      sidebar.classList.toggle('mobile-open');
      const overlay = document.getElementById('sidebarOverlay');
      if (overlay) overlay.style.display = sidebar.classList.contains('mobile-open') ? 'block' : 'none';
    } else {
      sidebar.classList.toggle('collapsed');
    }
  },
  closeMobile() {
    const sidebar = document.getElementById('sidebar');
    if (sidebar) sidebar.classList.remove('mobile-open');
    const overlay = document.getElementById('sidebarOverlay');
    if (overlay) overlay.style.display = 'none';
  },
};

/* ---------- NAVIGATION SPEED ---------- */
const NavigationSpeed = {
  prefetched: new Set(),
  init() {
    this.ensureLoader();
    window.addEventListener('pageshow', () => this.finish());
    document.addEventListener('pointerover', e => this.prefetchFromEvent(e), { passive:true });
    document.addEventListener('focusin', e => this.prefetchFromEvent(e));
    document.addEventListener('click', e => {
      const link = e.target.closest && e.target.closest('a[href]');
      if (this.shouldAnimate(link, e)) this.start();
    }, true);
  },
  ensureLoader() {
    if (document.getElementById('pageLoadBar')) return;
    const bar = document.createElement('div');
    bar.id = 'pageLoadBar';
    bar.className = 'page-load-bar';
    document.body.appendChild(bar);
  },
  shouldAnimate(link, event) {
    if (!link || event.defaultPrevented || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return false;
    if (link.target && link.target !== '_self') return false;
    if (link.hasAttribute('download')) return false;
    const raw = link.getAttribute('href') || '';
    if (!raw || raw === '#' || raw.startsWith('#') || raw.startsWith('javascript:') || raw.startsWith('mailto:') || raw.startsWith('tel:')) return false;
    let url;
    try { url = new URL(link.href, window.location.href); } catch(e) { return false; }
    return url.origin === window.location.origin;
  },
  prefetchFromEvent(event) {
    const link = event.target.closest && event.target.closest('a[href]');
    if (!this.shouldPrefetch(link)) return;
    const href = new URL(link.href, window.location.href).href;
    if (this.prefetched.has(href)) return;
    this.prefetched.add(href);
    const prefetch = document.createElement('link');
    prefetch.rel = 'prefetch';
    prefetch.href = href;
    document.head.appendChild(prefetch);
  },
  shouldPrefetch(link) {
    if (!link || link.target === '_blank' || link.hasAttribute('download')) return false;
    const raw = link.getAttribute('href') || '';
    if (!raw || raw === '#' || raw.startsWith('#') || raw.startsWith('javascript:')) return false;
    let url;
    try { url = new URL(link.href, window.location.href); } catch(e) { return false; }
    return url.origin === window.location.origin && /\.html($|[?#])/.test(url.pathname + url.search + url.hash);
  },
  start() {
    this.ensureLoader();
    document.documentElement.classList.add('is-navigating');
  },
  finish() {
    document.documentElement.classList.remove('is-navigating');
  },
};

/* ---------- TOAST NOTIFICATIONS ---------- */
const Toast = {
  container: null,
  init() {
    let c = document.getElementById('toastContainer');
    if (!c) {
      c = document.createElement('div');
      c.id = 'toastContainer';
      c.className = 'toast-container';
      document.body.appendChild(c);
    }
    this.container = c;
  },
  show(message, type='info', duration=3500) {
    if (!this.container) this.init();
    const icons = { success:'✅', error:'❌', warning:'⚠️', info:'ℹ️', birthday:'🎂' };
    const toast = document.createElement('div');
    toast.className = `toast toast-${type==='birthday'?'success':type}`;
    toast.innerHTML = `<span style="font-size:1.1rem">${icons[type]||'ℹ️'}</span><span style="flex:1">${message}</span><button onclick="this.parentElement.remove()" style="background:none;border:none;color:inherit;cursor:pointer;font-size:1.1rem;opacity:0.7">×</button>`;
    this.container.appendChild(toast);
    setTimeout(() => {
      toast.style.animation = 'slideOutRight 0.3s ease forwards';
      setTimeout(() => toast.remove(), 300);
    }, duration);
  },
  success(msg,d) { this.show(msg,'success',d); },
  error(msg,d)   { this.show(msg,'error',d); },
  warning(msg,d) { this.show(msg,'warning',d); },
  info(msg,d)    { this.show(msg,'info',d); },
  birthday(msg)  { this.show(msg,'birthday',8000); },
};

/* ---------- HEADER NOTIFICATION POPUP ---------- */
const HeaderNotifications = {
  wrap: null,
  readKey: 'cc_notif_read',

  init() {
    const headerRight = document.querySelector('.top-header .header-right');
    if (!headerRight || document.getElementById('headerNotifDropdown')) return;
    if (!DB.getNotifications || !DB.notificationAppliesToSession) return;

    const wrap = document.createElement('div');
    wrap.className = 'header-notif';
    wrap.id = 'headerNotifDropdown';
    wrap.innerHTML = `
      <button class="btn btn-secondary header-notif-btn" type="button" aria-label="Notifications" title="Notifications">
        <span aria-hidden="true">&#128276;</span>
        <span class="header-notif-badge" id="headerNotifBadge">0</span>
      </button>
      <div class="header-notif-panel" id="headerNotifPanel">
        <div class="header-notif-head">
          <div>
            <div style="font-weight:800">Notifications</div>
            <div class="text-muted" style="font-size:0.74rem">Latest academy notices</div>
          </div>
          <button class="btn btn-sm btn-ghost" type="button" id="headerNotifMarkRead">Read</button>
        </div>
        <div class="header-notif-list" id="headerNotifList"></div>
        <div class="header-notif-foot">
          <a class="btn btn-sm btn-secondary" href="notifications.html">All Notices</a>
          <button class="btn btn-sm btn-ghost" type="button" id="headerNotifClose">Close</button>
        </div>
      </div>
    `;

    const themeBtn = document.getElementById('themeToggle');
    headerRight.insertBefore(wrap, themeBtn || headerRight.firstChild);
    this.wrap = wrap;

    wrap.querySelector('.header-notif-btn').addEventListener('click', e => {
      e.stopPropagation();
      wrap.classList.toggle('open');
      this.render();
    });
    wrap.querySelector('#headerNotifMarkRead').addEventListener('click', e => {
      e.stopPropagation();
      this.markAllRead();
    });
    wrap.querySelector('#headerNotifClose').addEventListener('click', e => {
      e.stopPropagation();
      wrap.classList.remove('open');
    });
    document.addEventListener('click', () => wrap.classList.remove('open'));
    wrap.querySelector('.header-notif-panel').addEventListener('click', e => e.stopPropagation());

    this.render();
  },

  visibleNotifications() {
    const session = Auth.getSession ? Auth.getSession() : null;
    return DB.getNotifications()
      .filter(n => DB.notificationAppliesToSession(n, session || { role:'admin' }))
      .sort((a, b) => String(b.createdAt || b.date || '').localeCompare(String(a.createdAt || a.date || '')));
  },

  readIds() {
    try { return JSON.parse(localStorage.getItem(this.readKey) || '[]'); }
    catch(e) { return []; }
  },

  isRead(id) {
    return this.readIds().includes(id);
  },

  markAllRead() {
    const ids = this.visibleNotifications().map(n => n.id);
    localStorage.setItem(this.readKey, JSON.stringify(ids));
    this.render();
    Toast.success('Notifications marked as read');
  },

  render() {
    const wrap = this.wrap || document.getElementById('headerNotifDropdown');
    if (!wrap) return;

    const list = wrap.querySelector('#headerNotifList');
    const badge = wrap.querySelector('#headerNotifBadge');
    const items = this.visibleNotifications();
    const unread = items.filter(n => !this.isRead(n.id));

    if (badge) {
      badge.textContent = unread.length > 99 ? '99+' : String(unread.length);
      badge.style.display = unread.length ? 'grid' : 'none';
    }

    if (!list) return;
    if (!items.length) {
      list.innerHTML = '<div class="empty-state" style="padding:28px 12px"><div class="empty-state-icon" style="font-size:2rem">&#128276;</div><p>No notifications yet</p></div>';
      return;
    }

    list.innerHTML = items.slice(0, 6).map(n => {
      const unreadClass = this.isRead(n.id) ? '' : ' unread';
      return `<a href="notifications.html" class="header-notif-item${unreadClass}">
        <span class="header-notif-icon">${n.icon || '&#128204;'}</span>
        <span>
          <span class="header-notif-title">${Fmt.escape(n.title || 'Notice')}</span>
          <span class="header-notif-msg">${Fmt.escape(n.message || '').slice(0, 120)}</span>
          <span class="text-muted" style="display:block;font-size:0.72rem;margin-top:4px">${Fmt.escape(n.type || 'Notice')} ${n.date ? '&middot; ' + Fmt.date(n.date) : ''}</span>
        </span>
      </a>`;
    }).join('');
  },
};

/* ---------- MODAL MANAGER ---------- */
const Modal = {
  open(id) {
    const el = document.getElementById(id);
    if (el) { el.classList.add('active'); document.body.style.overflow='hidden'; }
  },
  close(id) {
    const el = document.getElementById(id);
    if (el) { el.classList.remove('active'); document.body.style.overflow=''; }
  },
  closeAll() {
    document.querySelectorAll('.modal-overlay.active').forEach(m => {
      m.classList.remove('active');
    });
    document.body.style.overflow='';
  },
  init() {
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', e => {
        if (e.target === overlay) { overlay.classList.remove('active'); document.body.style.overflow=''; }
      });
    });
    document.querySelectorAll('.modal-close, [data-modal-close]').forEach(btn => {
      btn.addEventListener('click', () => {
        const overlay = btn.closest('.modal-overlay');
        if (overlay) { overlay.classList.remove('active'); document.body.style.overflow=''; }
      });
    });
    document.addEventListener('keydown', e => { if(e.key==='Escape') this.closeAll(); });
  },
};

/* ---------- TABS ---------- */
const Tabs = {
  init(containerSelector) {
    const containers = document.querySelectorAll(containerSelector || '[data-tabs]');
    containers.forEach(container => {
      const btns = container.querySelectorAll('.tab-btn');
      btns.forEach(btn => {
        btn.addEventListener('click', () => {
          const target = btn.dataset.tab;
          const tabContainer = btn.closest('[data-tabs]') || container;
          tabContainer.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
          tabContainer.querySelectorAll('.tab-pane').forEach(p=>p.classList.remove('active'));
          btn.classList.add('active');
          const pane = tabContainer.querySelector(`#${target}`);
          if(pane) pane.classList.add('active');
        });
      });
    });
  },
};

/* ---------- DROPDOWN ---------- */
const Dropdown = {
  init() {
    document.querySelectorAll('.dropdown').forEach(dd => {
      const trigger = dd.querySelector('[data-dropdown-trigger]');
      if (trigger) trigger.addEventListener('click', e => {
        e.stopPropagation();
        dd.classList.toggle('open');
      });
    });
    document.addEventListener('click', () => {
      document.querySelectorAll('.dropdown.open').forEach(d=>d.classList.remove('open'));
    });
  },
};

/* ---------- FORMAT HELPERS ---------- */
const Fmt = {
  escape(str) {
    return String(str ?? '').replace(/[&<>"']/g, ch => ({
      '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#039;'
    }[ch]));
  },
  currency(n, symbol='₹') {
    return symbol + Number(n||0).toLocaleString('en-IN');
  },
  date(str) {
    if (!str) return '—';
    try { return new Date(str).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}); }
    catch(e){ return str; }
  },
  dateTime(str) {
    if (!str) return '—';
    try { return new Date(str).toLocaleString('en-IN'); }
    catch(e){ return str; }
  },
  percent(n) { return Number(n||0).toFixed(1)+'%'; },
  initials(name) {
    if(!name) return '?';
    return name.split(' ').map(w=>w[0]).join('').toUpperCase().slice(0,2);
  },
  age(dob) {
    if(!dob) return 0;
    const d=new Date(dob), n=new Date();
    return Math.floor((n-d)/(365.25*24*3600*1000));
  },
  capitalize(s) { return s?s.charAt(0).toUpperCase()+s.slice(1):''; },
};

const ProfileImage = {
  avatar(person, sizeClass='', extraStyle='') {
    const p = person || {};
    const image = p.profileImage;
    const name = Fmt.escape(p.name || '');
    const style = extraStyle ? ` style="${extraStyle}"` : '';
    const cls = ['avatar', sizeClass].filter(Boolean).join(' ');
    if (image) {
      return `<div class="${cls}"${style}><img src="${image}" alt="${name}"></div>`;
    }
    return `<div class="${cls}"${style}>${Fmt.initials(p.name)}</div>`;
  },
  bindInput(inputId, previewId, initialValue='', onChange) {
    let value = initialValue || '';
    const input = document.getElementById(inputId);
    const preview = document.getElementById(previewId);
    const render = () => {
      if (!preview) return;
      preview.innerHTML = value
        ? `<img src="${value}" alt="Profile preview">`
        : '<span>No Image</span>';
    };
    render();
    if (input) {
      input.value = '';
      input.onchange = () => {
        const file = input.files && input.files[0];
        if (!file) return;
        if (!file.type.startsWith('image/')) {
          Toast.warning('Please choose an image file');
          input.value = '';
          return;
        }
        const reader = new FileReader();
        reader.onload = e => {
          value = e.target.result;
          render();
          if (typeof onChange === 'function') onChange(value);
        };
        reader.readAsDataURL(file);
      };
    }
    return {
      getValue: () => value,
      setValue: next => { value = next || ''; render(); if (input) input.value = ''; },
    };
  },
};

function populateCourseStatusSelect(selectId, selected='Continue', includeAll=true) {
  const select = document.getElementById(selectId);
  if (!select) return;
  const statuses = DB.getCourseStatuses().filter(s => includeAll || s.value !== 'All');
  select.innerHTML = statuses.map(s => `<option value="${s.value}" ${s.value===selected?'selected':''}>${s.label}</option>`).join('');
}

/* ---------- CHART DEFAULTS ---------- */
const ChartDefaults = {
  apply() {
    if (!window.Chart) return;
    Chart.defaults.color = getComputedStyle(document.documentElement).getPropertyValue('--text-muted').trim() || '#94a3b8';
    Chart.defaults.font.family = "'Inter','Segoe UI',sans-serif";
    Chart.defaults.plugins.legend.labels.color = Chart.defaults.color;
  },
  getColors() {
    return ['#5eead4','#8b9cff','#fbbf24','#fb7185','#34d399','#93c5fd','#f472b6','#a78bfa'];
  },
  lineOptions(label, labels, data, color='#5eead4') {
    return {
      type:'line',
      data:{
        labels,
        datasets:[{
          label, data,
          borderColor:color, backgroundColor:color+'22',
          borderWidth:2, tension:0.4, fill:true,
          pointBackgroundColor:color, pointRadius:4,
        }]
      },
      options:{
        responsive:true, maintainAspectRatio:false,
        plugins:{ legend:{display:false} },
        scales:{
          x:{ grid:{color:'rgba(255,255,255,0.05)'}, ticks:{color:Chart.defaults.color} },
          y:{ grid:{color:'rgba(255,255,255,0.05)'}, ticks:{color:Chart.defaults.color} },
        }
      }
    };
  },
  barOptions(labels, datasets) {
    const colors = this.getColors();
    return {
      type:'bar',
      data:{
        labels,
        datasets: datasets.map((d,i)=>({
          ...d,
          backgroundColor: colors[i%colors.length]+'99',
          borderColor: colors[i%colors.length],
          borderWidth:1, borderRadius:6,
        }))
      },
      options:{
        responsive:true, maintainAspectRatio:false,
        plugins:{ legend:{position:'top'} },
        scales:{
          x:{ grid:{color:'rgba(255,255,255,0.05)'} },
          y:{ grid:{color:'rgba(255,255,255,0.05)'} },
        }
      }
    };
  },
  doughnutOptions(labels, data) {
    const colors = this.getColors();
    return {
      type:'doughnut',
      data:{ labels, datasets:[{ data, backgroundColor:colors.slice(0,labels.length), borderWidth:2, borderColor:'transparent', hoverOffset:8 }] },
      options:{
        responsive:true, maintainAspectRatio:false,
        plugins:{ legend:{position:'bottom'} },
        cutout:'65%',
      }
    };
  },
};

/* ---------- EXPORT HELPERS ---------- */
const Exporter = {
  toCSV(headers, rows, filename) {
    const csv = [headers.join(','), ...rows.map(r=>r.map(c=>`"${String(c||'').replace(/"/g,'""')}"`).join(','))].join('\n');
    this.download(csv, filename||'export.csv', 'text/csv;charset=utf-8;');
  },
  toJSON(data, filename) {
    this.download(JSON.stringify(data,null,2), filename||'export.json', 'application/json');
  },
  download(content, filename, type) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([content],{type}));
    a.download = filename;
    a.click();
    URL.revokeObjectURL(a.href);
  },
  toPDF_simple(title, content_html) {
    const w = window.open('','_blank');
    if(!w) return;
    const settings = DB.getSettings();
    w.document.write(`<!DOCTYPE html><html><head><title>${title}</title>
    <style>
      body{font-family:Arial,sans-serif;margin:40px;color:#000;background:#fff;}
      h1{text-align:center;color:#047857;margin-bottom:4px;}
      .sub{text-align:center;color:#666;font-size:12px;margin-bottom:24px;}
      table{width:100%;border-collapse:collapse;font-size:12px;}
      th{background:#047857;color:#fff;padding:8px;}
      td{border:1px solid #ccc;padding:8px;}
      tr:nth-child(even){background:#f9f9f9;}
      @media print{body{margin:20px}button{display:none}}
    </style></head><body>
    <h1>${settings.academyName}</h1>
    <p class="sub">${settings.address} | ${settings.mobile} | ${settings.email}</p>
    <hr style="margin-bottom:20px">
    ${content_html}
    <br><button onclick="window.print()" style="padding:10px 20px;background:#047857;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:14px">🖨️ Print / Save PDF</button>
    </body></html>`);
    w.document.close();
  },
};

/* ---------- BIRTHDAY NOTIFIER ---------- */
const BirthdayNotifier = {
  STORAGE_KEY: 'cc_bday_shown',

  check() {
    const today = new Date().toISOString().slice(0,10);
    const shown = localStorage.getItem(this.STORAGE_KEY);

    // Only show once per day
    if (shown === today) return;

    const birthdays = DB.getTodayBirthdays();
    if (!birthdays.length) return;

    // Mark as shown today
    localStorage.setItem(this.STORAGE_KEY, today);

    // Show birthday banner
    setTimeout(() => {
      birthdays.forEach(p => {
        const age = Fmt.age(p.dob);
        const roleLabel = p.role === 'teacher' ? '👨‍🏫 Teacher' : '👨‍🎓 Student';
        Toast.birthday(`🎂 Happy Birthday, ${p.name}! (${roleLabel}) — Turning ${age} today! 🎉`);
      });

      // Also show a fixed banner if element exists
      this.renderBanner(birthdays);
    }, 1500);
  },

  renderBanner(birthdays) {
    let banner = document.getElementById('birthdayBanner');
    if (!banner) {
      banner = document.createElement('div');
      banner.id = 'birthdayBanner';
      banner.style.cssText = `
        position:fixed;top:70px;left:50%;transform:translateX(-50%);z-index:9999;
        background:linear-gradient(135deg,#f59e0b,#ef4444);color:#fff;
        border-radius:16px;padding:14px 24px;box-shadow:0 8px 32px rgba(0,0,0,0.3);
        display:flex;align-items:center;gap:12px;max-width:90vw;
        animation:slideInDown 0.5s ease;font-weight:600;font-size:0.95rem;
      `;
      document.body.appendChild(banner);
    }

    const names = birthdays.map(b=>b.name).join(', ');
    banner.innerHTML = `
      <span style="font-size:1.8rem">🎂</span>
      <div>
        <div style="font-size:1rem;font-weight:700">🎉 Birthday Today!</div>
        <div style="font-size:0.85rem;opacity:0.95">${names}</div>
      </div>
      <button onclick="this.parentElement.remove()" style="background:rgba(255,255,255,0.2);border:none;color:#fff;border-radius:50%;width:28px;height:28px;cursor:pointer;font-size:1rem;display:flex;align-items:center;justify-content:center;margin-left:8px">×</button>
    `;

    // Auto-remove after 15 seconds
    setTimeout(() => {
      if (banner.parentElement) {
        banner.style.animation = 'fadeOut 0.5s ease forwards';
        setTimeout(() => banner.remove(), 500);
      }
    }, 15000);
  },
};

/* ---------- CERTIFICATE GENERATOR ---------- */
const CertificateGenerator = {
  generate(student) {
    const settings = DB.getSettings();
    const today = new Date().toLocaleDateString('en-IN', { day:'2-digit', month:'long', year:'numeric' });
    const w = window.open('','_blank');
    if(!w) { Toast.error('Popup blocked! Please allow popups.'); return; }

    w.document.write(`<!DOCTYPE html>
<html><head><title>Course Completion Certificate — ${student.name}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Great+Vibes&family=Cinzel:wght@400;700&family=Open+Sans:wght@300;400;600&display=swap');
  * { margin:0; padding:0; box-sizing:border-box; }
  body { background:#f0e6d3; display:flex; justify-content:center; align-items:center; min-height:100vh; font-family:'Open Sans',sans-serif; }
  .cert-wrapper { padding:30px; }
  .certificate {
    width:900px; min-height:640px;
    background:linear-gradient(145deg,#fffdf7,#fef9ee);
    border:8px solid #b8860b;
    outline:3px solid #d4a017;
    outline-offset:-16px;
    border-radius:8px;
    padding:50px 60px;
    position:relative;
    box-shadow:0 20px 60px rgba(0,0,0,0.25);
    text-align:center;
  }
  .cert-watermark {
    position:absolute; top:50%; left:50%;
    transform:translate(-50%,-50%) rotate(-30deg);
    font-size:120px; opacity:0.04; font-weight:900;
    color:#b8860b; white-space:nowrap; pointer-events:none;
  }
  .cert-corner {
    position:absolute; font-size:2.5rem; opacity:0.4;
  }
  .cert-corner.tl { top:20px; left:20px; }
  .cert-corner.tr { top:20px; right:20px; }
  .cert-corner.bl { bottom:20px; left:20px; }
  .cert-corner.br { bottom:20px; right:20px; }
  .org-logo {
    width:70px; height:70px; background:linear-gradient(135deg,#047857,#065f46);
    border-radius:50%; display:flex; align-items:center; justify-content:center;
    color:#fff; font-size:1.6rem; font-weight:800; margin:0 auto 12px;
  }
  .org-name { font-family:'Cinzel',serif; font-size:1.5rem; color:#047857; font-weight:700; letter-spacing:2px; }
  .org-sub { font-size:0.78rem; color:#666; margin-top:4px; letter-spacing:1px; }
  .cert-title-label { font-family:'Cinzel',serif; font-size:0.85rem; letter-spacing:6px; color:#b8860b; margin:24px 0 8px; text-transform:uppercase; }
  .cert-title { font-family:'Cinzel',serif; font-size:2.8rem; color:#1a1a1a; font-weight:700; margin-bottom:20px; }
  .cert-presented { font-size:0.9rem; color:#555; letter-spacing:1px; margin-bottom:10px; }
  .student-name { font-family:'Great Vibes',cursive; font-size:3.8rem; color:#047857; margin:8px 0 20px; line-height:1.2; }
  .cert-desc { font-size:0.92rem; color:#444; line-height:1.8; max-width:600px; margin:0 auto 28px; }
  .cert-desc strong { color:#1a1a1a; }
  .divider { width:200px; height:2px; background:linear-gradient(90deg,transparent,#b8860b,transparent); margin:0 auto 28px; }
  .cert-meta { display:flex; justify-content:space-around; margin:20px 0; }
  .meta-item { text-align:center; }
  .meta-label { font-size:0.72rem; color:#888; text-transform:uppercase; letter-spacing:1px; margin-bottom:4px; }
  .meta-value { font-size:0.95rem; font-weight:600; color:#1a1a1a; }
  .signatures { display:flex; justify-content:space-between; margin-top:40px; padding-top:16px; border-top:1px solid #ddd; }
  .sig-block { text-align:center; width:160px; }
  .sig-line { width:120px; height:1px; background:#333; margin:0 auto 6px; }
  .sig-label { font-size:0.75rem; color:#555; }
  .cert-id { position:absolute; bottom:14px; right:20px; font-size:0.7rem; color:#aaa; }
  .seal {
    position:absolute; bottom:60px; left:50%; transform:translateX(-50%);
    width:80px; height:80px; border-radius:50%;
    border:4px solid #b8860b; display:flex; align-items:center; justify-content:center;
    flex-direction:column; font-size:0.55rem; font-weight:700; color:#b8860b;
    letter-spacing:1px; background:rgba(184,134,11,0.05);
    text-transform:uppercase; line-height:1.4;
  }
  .grade-badge {
    display:inline-block; background:linear-gradient(135deg,#047857,#065f46);
    color:#fff; padding:6px 20px; border-radius:999px;
    font-size:1.1rem; font-weight:700; margin-bottom:12px;
  }
  @media print {
    body { background:#fff; }
    .cert-wrapper { padding:0; }
    .no-print { display:none!important; }
    .certificate { box-shadow:none; }
  }
</style></head><body>
<div class="cert-wrapper">
  <div class="certificate">
    <div class="cert-watermark">CC</div>
    <div class="cert-corner tl">✦</div>
    <div class="cert-corner tr">✦</div>
    <div class="cert-corner bl">✦</div>
    <div class="cert-corner br">✦</div>

    <div class="org-logo">CC</div>
    <div class="org-name">${settings.academyName}</div>
    <div class="org-sub">${settings.address}</div>

    <div class="cert-title-label">Certificate of</div>
    <div class="cert-title">Course Completion</div>

    <div class="cert-presented">This is to certify that</div>
    <div class="student-name">${student.name}</div>

    ${student.grade ? `<div class="grade-badge">Grade: ${student.grade}${student.percentage?' | '+student.percentage+'%':''}</div>` : ''}

    <div class="divider"></div>
    <div class="cert-desc">
      has successfully completed the <strong>${student.course||'Computer Course'}</strong> program
      ${student.duration?`of <strong>${student.duration}</strong>`:''} offered by
      <strong>${settings.academyName}</strong>,
      demonstrating commitment, skill, and academic excellence throughout the course.
      ${student.subcategories&&student.subcategories.length?`<br><br>Modules covered: <strong>${student.subcategories.join(', ')}</strong>`:''}
    </div>

    <div class="cert-meta">
      <div class="meta-item">
        <div class="meta-label">Student ID</div>
        <div class="meta-value">${student.id}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">Batch</div>
        <div class="meta-value">${student.batchNo||'—'}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">Completion Date</div>
        <div class="meta-value">${today}</div>
      </div>
      <div class="meta-item">
        <div class="meta-label">Duration</div>
        <div class="meta-value">${student.duration||'—'}</div>
      </div>
    </div>

    <div class="seal">
      <div>✦</div>
      <div>Certified</div>
      <div>✦</div>
    </div>

    <div class="signatures">
      <div class="sig-block">
        <div class="sig-line"></div>
        <div class="sig-label">Student Signature</div>
      </div>
      <div class="sig-block">
        <div class="sig-line"></div>
        <div class="sig-label">Principal / Director</div>
        <div style="font-size:0.75rem;color:#047857;margin-top:2px">${settings.principalName||'Anubhav'}</div>
      </div>
      <div class="sig-block">
        <div class="sig-line"></div>
        <div class="sig-label">Course Instructor</div>
      </div>
    </div>

    <div class="cert-id">Cert No: CC-${student.id.toUpperCase()}-${Date.now().toString().slice(-6)}</div>
  </div>

  <div class="no-print" style="text-align:center;margin-top:20px">
    <button onclick="window.print()" style="padding:14px 36px;background:linear-gradient(135deg,#047857,#065f46);color:#fff;border:none;border-radius:10px;cursor:pointer;font-size:1rem;font-weight:700;margin-right:10px;box-shadow:0 4px 15px rgba(4,120,87,0.4)">🖨️ Print / Download PDF</button>
    <button onclick="window.close()" style="padding:14px 24px;background:#e5e7eb;color:#333;border:none;border-radius:10px;cursor:pointer;font-size:1rem">✕ Close</button>
  </div>
</div>
</body></html>`);
    w.document.close();
  },
};

/* ---------- HEADER USER INFO ---------- */
function renderHeaderUser() {
  const session = Auth.getSession();
  if (!session) return;
  const el = document.getElementById('headerUser');
  if (el) {
    const person = session.role === 'student' ? DB.getStudent(session.id) :
      (session.role === 'teacher' ? DB.getTeacher(session.id) : null);
    el.innerHTML = `
      ${ProfileImage.avatar(person || session, '', 'width:34px;height:34px;font-size:0.8rem;cursor:pointer')}
      <div style="display:flex;flex-direction:column;line-height:1.2">
        <span style="font-size:0.82rem;font-weight:600">${session.name}</span>
        <span style="font-size:0.7rem;color:var(--primary);text-transform:uppercase;letter-spacing:0.5px">${session.role}</span>
      </div>
    `;
  }
}

/* ---------- AUTO SAVE INDICATOR ---------- */
function showAutoSave() {
  const el = document.getElementById('autoSaveIndicator');
  if (el) {
    el.textContent = '✓ Saved';
    el.style.opacity = '1';
    setTimeout(()=>{ el.style.opacity='0'; }, 2000);
  }
}

/* ---------- SEARCH / FILTER ---------- */
function filterTable(inputId, tableId) {
  const input = document.getElementById(inputId);
  const table = document.getElementById(tableId);
  if (!input || !table) return;
  input.addEventListener('input', () => {
    const q = input.value.toLowerCase();
    table.querySelectorAll('tbody tr').forEach(row => {
      row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  });
}

/* ---------- ACADEMY FILTERS / VIEW CONTROLS ---------- */
const AcademyFilters = {
  allOption(label='All') {
    return `<option value="All">${label}</option>`;
  },
  unique(values) {
    return [...new Set((values || []).filter(Boolean))]
      .sort((a, b) => String(a).localeCompare(String(b), undefined, { numeric:true }));
  },
  coursesOptions(selected='All', allLabel='All Courses') {
    const courses = DB.getCourses ? DB.getCourses() : [];
    return this.allOption(allLabel) + courses.map(c =>
      `<option value="${Fmt.escape(c.id)}" ${selected === c.id ? 'selected' : ''}>${Fmt.escape(c.name)}</option>`
    ).join('');
  },
  batchOptions(selected='All', allLabel='All Batches') {
    const batches = DB.getBatches ? DB.getBatches() : this.unique((DB.getStudents ? DB.getStudents() : []).map(s => s.batchNo));
    return this.allOption(allLabel) + batches.map(batch =>
      `<option value="${Fmt.escape(batch)}" ${selected === batch ? 'selected' : ''}>${Fmt.escape(batch)}</option>`
    ).join('');
  },
  dayOptions(selected='All', allLabel='All Days') {
    const days = DB.getStudentDays ? DB.getStudentDays() : this.unique((DB.getStudents ? DB.getStudents() : []).map(s => s.day));
    return this.allOption(allLabel) + days.map(day =>
      `<option value="${Fmt.escape(day)}" ${selected === day ? 'selected' : ''}>${Fmt.escape(day)}</option>`
    ).join('');
  },
  optionList(values, selected='All', allLabel='All') {
    return this.allOption(allLabel) + this.unique(values).map(value =>
      `<option value="${Fmt.escape(value)}" ${selected === value ? 'selected' : ''}>${Fmt.escape(value)}</option>`
    ).join('');
  },
  feeStatusOptions(selected='All') {
    return [
      ['All','All Fees'],
      ['Pending','Pending Fees'],
      ['Partial','Partial Paid'],
      ['Cleared','Cleared Fees'],
      ['No Fee','No Fee Set'],
    ].map(([value, label]) => `<option value="${value}" ${selected === value ? 'selected' : ''}>${label}</option>`).join('');
  },
  statusOptions(selected='All', allLabel='All Status') {
    const statuses = DB.getCourseStatuses ? DB.getCourseStatuses() : [];
    return statuses.map(item =>
      `<option value="${Fmt.escape(item.value)}" ${selected === item.value ? 'selected' : ''}>${Fmt.escape(item.value === 'All' ? allLabel : item.label.replace(' Students List',''))}</option>`
    ).join('');
  },
  studentMatches(student, filters={}) {
    return DB.filterStudents ? DB.filterStudents({
      status:filters.status || 'All',
      gender:filters.gender || 'All',
      batch:filters.batch || 'All',
      courseId:filters.courseId || 'All',
      feesStatus:filters.feesStatus || 'All',
      day:filters.day || 'All',
      dateFrom:filters.dateFrom || '',
      dateTo:filters.dateTo || '',
      query:filters.query || '',
    }).some(s => s.id === student.id) : true;
  },
  readFilters(prefix) {
    const val = id => document.getElementById(prefix + id)?.value || '';
    return {
      query: val('Search'),
      status: val('Status') || 'All',
      gender: val('Gender') || 'All',
      batch: val('Batch') || 'All',
      courseId: val('Course') || 'All',
      feesStatus: val('Fees') || 'All',
      day: val('Day') || 'All',
      dateFrom: val('DateFrom'),
      dateTo: val('DateTo'),
    };
  },
};

const AcademyView = {
  storagePrefix: 'cc_view_',
  get(page, fallback='list') {
    try {
      const mode = localStorage.getItem(this.storagePrefix + page);
      return ['grid', 'list'].includes(mode) ? mode : fallback;
    }
    catch(e) { return fallback; }
  },
  set(page, mode) {
    if (!['grid', 'list'].includes(mode)) return;
    try { localStorage.setItem(this.storagePrefix + page, mode); } catch(e) {}
  },
  toggleMarkup(page, current='list', label='View') {
    return `<div class="view-toggle" role="group" aria-label="${Fmt.escape(label)}">
      <button type="button" class="view-toggle-btn ${current === 'grid' ? 'active' : ''}" data-view-choice="grid" title="Grid view">&#9638; Grid</button>
      <button type="button" class="view-toggle-btn ${current === 'list' ? 'active' : ''}" data-view-choice="list" title="List view">&#9776; List</button>
    </div>`;
  },
  toolbarMarkup(page, current='list', label='View', countId='', countText='0 records', actions='') {
    return `<div class="academy-view-toolbar" data-view-toolbar="${Fmt.escape(page)}">
      <div class="academy-view-meta">
        ${countId ? `<span class="academy-record-count" id="${Fmt.escape(countId)}">${Fmt.escape(countText)}</span>` : ''}
        <span class="academy-view-label">${Fmt.escape(label)}</span>
      </div>
      <div class="academy-view-actions">
        ${this.toggleMarkup(page, current, label)}
        ${actions}
      </div>
    </div>`;
  },
  bind(root, page, onChange) {
    if (!root) return;
    root.querySelectorAll('[data-view-choice]').forEach(btn => {
      btn.addEventListener('click', () => {
        const mode = btn.dataset.viewChoice || 'list';
        this.set(page, mode);
        root.querySelectorAll('[data-view-choice]').forEach(b => b.classList.toggle('active', b === btn));
        if (typeof onChange === 'function') onChange(mode);
      });
    });
  },
};

const AcademyAutoEnhance = {
  init() {
    setTimeout(() => this.enhancePage(), 250);
    const area = document.querySelector('.content-area');
    if (!area) return;
    const observer = new MutationObserver(() => {
      clearTimeout(this._timer);
      this._timer = setTimeout(() => this.enhancePage(), 120);
    });
    observer.observe(area, { childList:true, subtree:true });
  },
  enhancePage() {
    this.enhanceTables();
    this.enhanceCardGrids();
  },
  pageKey() {
    return (window.location.pathname.split('/').pop() || 'index.html').replace('.html','');
  },
  shouldSkipTable(table) {
    const id = table.id || '';
    const customPages = ['students','fees','attendance','timetable','inquiries'];
    return customPages.includes(this.pageKey()) || ['attTable','ttTable'].includes(id) || table.closest('[data-no-auto-enhance]');
  },
  enhanceTables() {
    document.querySelectorAll('.table-container table, table.smart-table').forEach((table, index) => {
      if (this.shouldSkipTable(table)) return;
      if (table.dataset.autoEnhanced === '1') {
        return;
      }
      table.dataset.autoEnhanced = '1';
      const container = table.closest('.table-container') || table.parentElement;
      if (!container || container.querySelector(':scope > .auto-list-grid')) return;
      const key = `${this.pageKey()}_table_${index}`;
      table.dataset.autoKey = key;
      const panel = this.createAutoPanel(key, () => this.applyTableFilters(table, key));
      container.insertAdjacentElement('beforebegin', panel);
      this.applyTableFilters(table, key);
    });
  },
  enhanceCardGrids() {
    document.querySelectorAll('#coursesGrid, #galleryGrid, #tasksList, #notifList, #internshipGrid, #notesList').forEach((grid, index) => {
      if (!grid || grid.closest('[data-no-auto-enhance]')) return;
      if (grid.dataset.autoEnhanced === '1') {
        return;
      }
      grid.dataset.autoEnhanced = '1';
      const key = `${this.pageKey()}_cards_${index}`;
      grid.dataset.autoKey = key;
      const panel = this.createAutoPanel(key, () => this.applyCardFilters(grid, key), true);
      grid.insertAdjacentElement('beforebegin', panel);
      this.applyCardFilters(grid, key);
    });
  },
  createAutoPanel(key, onChange, cardsOnly=false) {
    const wrap = document.createElement('div');
    wrap.className = 'auto-list-grid smart-filter-bar';
    wrap.innerHTML = `
      <div class="smart-filter-main">
        <div class="search-wrapper smart-search">
          <span class="search-icon">&#128269;</span>
          <input type="search" class="form-control" data-auto-search="${key}" placeholder="Fast search on this page">
        </div>
        <select class="form-control smart-mini-filter" data-auto-status="${key}">
          <option value="All">All Status</option>
          <option value="Pending">Pending</option>
          <option value="Continue">Continue</option>
          <option value="Complete">Complete</option>
          <option value="Open">Open</option>
          <option value="Follow Up">Follow Up</option>
          <option value="Completed">Completed</option>
          <option value="Active">Active</option>
        </select>
        <span class="smart-filter-count" data-auto-count="${key}">0 records</span>
      </div>
      ${cardsOnly ? '' : AcademyView.toggleMarkup(key, AcademyView.get(key, 'list'), 'Auto view')}
    `;
    wrap.querySelectorAll('input,select').forEach(el => {
      el.addEventListener('input', onChange);
      el.addEventListener('change', onChange);
    });
    if (!cardsOnly) {
      AcademyView.bind(wrap, key, () => onChange());
    }
    return wrap;
  },
  filterText(rowOrCard, key) {
    const q = (document.querySelector(`[data-auto-search="${key}"]`)?.value || '').trim().toLowerCase();
    const status = document.querySelector(`[data-auto-status="${key}"]`)?.value || 'All';
    const text = rowOrCard.textContent.toLowerCase();
    return (!q || text.includes(q)) && (status === 'All' || text.includes(status.toLowerCase()));
  },
  applyTableFilters(table, key) {
    const rows = [...table.querySelectorAll('tbody tr')];
    let visible = 0;
    rows.forEach(row => {
      const show = this.filterText(row, key);
      row.dataset.autoVisible = show ? '1' : '0';
      row.style.display = show ? '' : 'none';
      if (show) visible++;
    });
    this.updateCount(key, visible);
    this.renderTableGrid(table, key);
  },
  renderTableGrid(table, key) {
    const mode = AcademyView.get(key, 'list');
    let grid = table.parentElement.querySelector(`.auto-grid-cards[data-grid-for="${key}"]`);
    if (!grid) {
      grid = document.createElement('div');
      grid.className = 'auto-grid-cards';
      grid.dataset.gridFor = key;
      table.insertAdjacentElement('afterend', grid);
    }
    const showGrid = mode === 'grid';
    table.style.display = showGrid ? 'none' : '';
    grid.style.display = showGrid ? 'grid' : 'none';
    if (!showGrid) return;
    const heads = [...table.querySelectorAll('thead th')].map(th => th.textContent.trim()).filter(Boolean);
    const rows = [...table.querySelectorAll('tbody tr')].filter(row => row.dataset.autoVisible !== '0');
    grid.innerHTML = rows.map(row => {
      const cells = [...row.children].map((cell, i) => {
        const label = heads[i] || `Field ${i + 1}`;
        return `<div class="auto-card-row"><span>${Fmt.escape(label)}</span><strong>${cell.innerHTML}</strong></div>`;
      }).join('');
      return `<article class="auto-grid-card">${cells}</article>`;
    }).join('') || '<div class="empty-state"><p>No matching records</p></div>';
  },
  applyCardFilters(grid, key) {
    const cards = [...grid.children].filter(el => !el.classList.contains('auto-list-grid'));
    let visible = 0;
    cards.forEach(card => {
      const show = this.filterText(card, key);
      card.style.display = show ? '' : 'none';
      if (show) visible++;
    });
    this.updateCount(key, visible);
  },
  updateCount(key, visible) {
    const el = document.querySelector(`[data-auto-count="${key}"]`);
    if (el) el.textContent = `${visible} record${visible === 1 ? '' : 's'}`;
  },
};

/* ---------- GLOBAL DESIGN SETTINGS / RESPONSIVE CHROME ---------- */
const AcademyDesign = {
  defaults: {
    uiDesignMode: 'modern',
    uiSurfaceStyle: 'glass',
    uiDensity: 'comfortable',
    uiBottomNav: true,
    uiReduceMotion: false,
    uiWideTables: true,
    uiPalette: 'teal',
    uiBackgroundStyle: 'aurora',
    uiContrast: 'normal',
    uiFontFamily: 'inter',
    uiFontSize: 17,
    uiSidebarSize: 'normal',
    uiNavStyle: 'iconText',
    uiIconStyle: 'badge',
    uiCornerStyle: 'round',
    uiShadowLevel: 2,
    uiBorderLevel: 1,
    uiOutlineLevel: 2,
    uiBrightness: 100,
    uiSaturation: 115,
    uiHighlightLevel: 2,
    uiPanelOpacity: 78,
    uiBlurLevel: 18,
    uiScrollStyle: 'color',
  },
  resizeTimer: null,

  settings() {
    const saved = DB.getSettings ? DB.getSettings() : {};
    return { ...this.defaults, ...(saved || {}) };
  },

  init() {
    this.applyFromSettings();
    this.repairChrome();
    this.injectControls();
    this.injectQuickMenu();
    this.injectMobileBottomNav();
    this.bindGlobalShortcuts();
    document.addEventListener('click', e => {
      if (e.target.closest && e.target.closest('.nav-item')) {
        setTimeout(() => this.injectMobileBottomNav(true), 80);
      }
    });
    window.addEventListener('resize', () => {
      clearTimeout(this.resizeTimer);
      this.resizeTimer = setTimeout(() => this.injectMobileBottomNav(true), 120);
    });
  },

  save(patch, options={}) {
    DB.saveSettings(patch);
    this.applyFromSettings();
    if (options.render !== false) this.renderPanel();
    this.injectMobileBottomNav(true);
    if (typeof showAutoSave === 'function') showAutoSave();
  },

  reset() {
    const current = this.settings();
    DB.saveSettings({ ...this.defaults, theme: current.theme || 'dark' });
    this.applyFromSettings();
    this.renderPanel();
    this.injectMobileBottomNav(true);
    Toast.success('Design settings reset');
  },

  applyFromSettings() {
    const s = this.settings();
    const root = document.documentElement;
    root.dataset.uiMode = s.uiDesignMode || this.defaults.uiDesignMode;
    root.dataset.surfaceStyle = s.uiSurfaceStyle || this.defaults.uiSurfaceStyle;
    root.dataset.density = s.uiDensity || this.defaults.uiDensity;
    root.dataset.palette = s.uiPalette || this.defaults.uiPalette;
    root.dataset.bgStyle = s.uiBackgroundStyle || this.defaults.uiBackgroundStyle;
    root.dataset.contrast = s.uiContrast || this.defaults.uiContrast;
    root.dataset.fontFamily = s.uiFontFamily || this.defaults.uiFontFamily;
    root.dataset.sidebarSize = s.uiSidebarSize || this.defaults.uiSidebarSize;
    root.dataset.navStyle = s.uiNavStyle || this.defaults.uiNavStyle;
    root.dataset.iconStyle = s.uiIconStyle || this.defaults.uiIconStyle;
    root.dataset.cornerStyle = s.uiCornerStyle || this.defaults.uiCornerStyle;
    root.dataset.scrollStyle = s.uiScrollStyle || this.defaults.uiScrollStyle;
    root.dataset.highlightLevel = String(s.uiHighlightLevel ?? this.defaults.uiHighlightLevel);
    root.classList.toggle('reduce-motion', !!s.uiReduceMotion);
    root.classList.toggle('wide-tables', s.uiWideTables !== false);
    this.applyCustomVariables(s);
    if (document.body) {
      const hasNav = !!document.querySelector('.nav-menu');
      document.body.classList.toggle('has-bottom-nav', s.uiBottomNav !== false && hasNav);
    }
    this.syncHeaderButtons();
  },

  number(value, fallback, min, max) {
    const n = Number(value);
    if (!Number.isFinite(n)) return fallback;
    return Math.min(max, Math.max(min, n));
  },

  applyCustomVariables(s) {
    const root = document.documentElement;
    const fontSize = this.number(s.uiFontSize, this.defaults.uiFontSize, 13, 20);
    const shadow = this.number(s.uiShadowLevel, this.defaults.uiShadowLevel, 0, 4);
    const border = this.number(s.uiBorderLevel, this.defaults.uiBorderLevel, 0, 4);
    const outline = this.number(s.uiOutlineLevel, this.defaults.uiOutlineLevel, 0, 5);
    const brightness = this.number(s.uiBrightness, this.defaults.uiBrightness, 70, 135);
    const saturation = this.number(s.uiSaturation, this.defaults.uiSaturation, 50, 180);
    const highlight = this.number(s.uiHighlightLevel, this.defaults.uiHighlightLevel, 0, 4);
    const opacity = this.number(s.uiPanelOpacity, this.defaults.uiPanelOpacity, 45, 98);
    const blur = this.number(s.uiBlurLevel, this.defaults.uiBlurLevel, 0, 30);

    const sidebarMap = { compact:'236px', normal:'280px', wide:'336px' };
    const fontMap = {
      inter: "'Inter','Segoe UI',system-ui,-apple-system,sans-serif",
      system: "system-ui,-apple-system,'Segoe UI',Arial,sans-serif",
      serif: "Georgia,'Times New Roman',serif",
      mono: "'Cascadia Code','Consolas','Courier New',monospace",
    };
    const paletteMap = {
      teal:    { primary:'#5eead4', secondary:'#8b9cff', accent:'#fbbf24', focus:'#fbbf24' },
      blue:    { primary:'#60a5fa', secondary:'#22d3ee', accent:'#f59e0b', focus:'#38bdf8' },
      emerald: { primary:'#34d399', secondary:'#2dd4bf', accent:'#facc15', focus:'#86efac' },
      violet:  { primary:'#c084fc', secondary:'#60a5fa', accent:'#fb7185', focus:'#d8b4fe' },
      gold:    { primary:'#fbbf24', secondary:'#38bdf8', accent:'#34d399', focus:'#fde68a' },
    };
    const cornerMap = {
      sharp: ['4px','6px','8px','12px'],
      soft: ['8px','14px','20px','28px'],
      round: ['14px','20px','28px','36px'],
    };
    const radii = cornerMap[s.uiCornerStyle] || cornerMap.soft;
    const shadowAlpha = [0, 0.12, 0.22, 0.34, 0.46][shadow] ?? 0.22;
    const borderAlpha = [0.06, 0.12, 0.2, 0.32, 0.44][border] ?? 0.12;
    const palette = paletteMap[s.uiPalette] || paletteMap.teal;
    const isLight = root.getAttribute('data-theme') === 'light';
    const panelOpacity = opacity / 100;
    const glassLight = isLight
      ? `rgba(255,255,255,${panelOpacity})`
      : `rgba(18,28,43,${panelOpacity})`;
    const glassMedium = isLight
      ? `rgba(255,255,255,${Math.min(0.98, panelOpacity + 0.1)})`
      : `rgba(28,43,61,${Math.min(0.96, panelOpacity + 0.08)})`;
    const glassHeavy = isLight
      ? `rgba(255,255,255,${Math.min(1, panelOpacity + 0.18)})`
      : `rgba(11,18,30,${Math.min(0.99, panelOpacity + 0.16)})`;

    root.style.setProperty('--ui-font-size', fontSize + 'px');
    root.style.setProperty('--font-main', fontMap[s.uiFontFamily] || fontMap.inter);
    root.style.setProperty('--primary', palette.primary);
    root.style.setProperty('--secondary', palette.secondary);
    root.style.setProperty('--accent', palette.accent);
    root.style.setProperty('--focus-ring', palette.focus);
    root.style.setProperty('--primary-glow', this.hexToRgba(palette.primary, 0.34));
    root.style.setProperty('--glass-bg-light', glassLight);
    root.style.setProperty('--glass-bg-medium', glassMedium);
    root.style.setProperty('--glass-bg-heavy', glassHeavy);
    root.style.setProperty('--sidebar-width', sidebarMap[s.uiSidebarSize] || sidebarMap.normal);
    root.style.setProperty('--radius-sm', radii[0]);
    root.style.setProperty('--radius-md', radii[1]);
    root.style.setProperty('--radius-lg', radii[2]);
    root.style.setProperty('--radius-xl', radii[3]);
    root.style.setProperty('--glass-border', `rgba(226,232,240,${borderAlpha})`);
    root.style.setProperty('--glass-border-highlight', `rgba(255,255,255,${Math.min(0.72, borderAlpha + 0.18)})`);
    root.style.setProperty('--glass-blur', `blur(${blur}px) saturate(${(saturation / 100).toFixed(2)})`);
    root.style.setProperty('--ui-brightness', (brightness / 100).toFixed(2));
    root.style.setProperty('--ui-saturation', (saturation / 100).toFixed(2));
    root.style.setProperty('--ui-highlight-opacity', String(Math.min(0.32, highlight * 0.06 + 0.02)));
    root.style.setProperty('--ui-outline-size', outline + 'px');
    root.style.setProperty('--ui-panel-opacity', (opacity / 100).toFixed(2));
    root.style.setProperty('--glass-shadow', shadow
      ? `0 ${6 + shadow * 5}px ${18 + shadow * 16}px rgba(0,0,0,${shadowAlpha}), inset 0 1px 0 rgba(255,255,255,0.1)`
      : 'none');
    root.style.setProperty('--material-elevation-3', shadow
      ? `0 ${8 + shadow * 6}px ${20 + shadow * 18}px rgba(0,0,0,${shadowAlpha})`
      : 'none');

    if (s.uiContrast === 'high') {
      root.style.setProperty('--text-main', isLight ? '#020617' : '#ffffff');
      root.style.setProperty('--text-muted', isLight ? '#0f172a' : '#e2e8f0');
      root.style.setProperty('--input-border', isLight ? 'rgba(2,6,23,0.38)' : 'rgba(255,255,255,0.42)');
    } else if (s.uiContrast === 'soft') {
      root.style.setProperty('--text-muted', isLight ? '#64748b' : 'rgba(226,232,240,0.68)');
      root.style.setProperty('--input-border', isLight ? 'rgba(15,23,42,0.1)' : 'rgba(226,232,240,0.12)');
      root.style.removeProperty('--text-main');
    } else {
      root.style.removeProperty('--text-main');
      root.style.removeProperty('--text-muted');
      root.style.removeProperty('--input-border');
    }
  },

  hexToRgba(hex, alpha) {
    const clean = String(hex || '').replace('#', '');
    if (clean.length !== 6) return `rgba(94,234,212,${alpha})`;
    const n = parseInt(clean, 16);
    const r = (n >> 16) & 255;
    const g = (n >> 8) & 255;
    const b = n & 255;
    return `rgba(${r},${g},${b},${alpha})`;
  },

  injectControls() {
    if (!document.body || document.getElementById('academyDesignFab')) return;
    const fab = document.createElement('button');
    fab.type = 'button';
    fab.id = 'academyDesignFab';
    fab.className = 'academy-design-fab no-print';
    fab.setAttribute('aria-label', 'Open design settings');
    fab.title = 'Design settings';
    fab.innerHTML = '<span aria-hidden="true">&#9881;</span>';
    fab.addEventListener('click', () => this.openPanel());
    document.body.appendChild(fab);
    this.ensurePanel();
  },

  ensurePanel() {
    if (!document.body || document.getElementById('academyDesignModal')) return;
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay design-settings-modal';
    overlay.id = 'academyDesignModal';
    overlay.innerHTML = `
      <div class="modal modal-sm design-settings-dialog" role="dialog" aria-modal="true" aria-labelledby="academyDesignTitle">
        <div class="modal-header">
          <h3 class="modal-title" id="academyDesignTitle">Design Settings</h3>
          <button class="modal-close" type="button" data-design-close aria-label="Close design settings">x</button>
        </div>
        <div class="modal-body" id="academyDesignBody"></div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-design-reset>Reset</button>
          <button class="btn btn-primary" type="button" data-design-close>Done</button>
        </div>
      </div>`;
    overlay.addEventListener('click', e => {
      if (e.target === overlay || e.target.closest('[data-design-close]')) this.closePanel();
      if (e.target.closest('[data-design-reset]')) this.reset();
    });
    document.body.appendChild(overlay);
    this.renderPanel();
  },

  openPanel() {
    this.ensurePanel();
    this.renderPanel();
    Modal.open('academyDesignModal');
  },

  closePanel() {
    Modal.close('academyDesignModal');
  },

  renderPanel() {
    const body = document.getElementById('academyDesignBody');
    if (!body) return;
    const s = this.settings();
    const choice = (setting, value, label, hint='') => `
      <button class="design-choice ${s[setting] === value ? 'active' : ''}" type="button"
        data-design-setting="${setting}" data-design-value="${value}" aria-pressed="${s[setting] === value}">
        <strong>${label}</strong>${hint ? `<span>${hint}</span>` : ''}
      </button>`;
    const toggle = (setting, label, hint='') => `
      <label class="design-toggle-row">
        <span><strong>${label}</strong>${hint ? `<em>${hint}</em>` : ''}</span>
        <input type="checkbox" data-design-toggle="${setting}" ${s[setting] !== false ? 'checked' : ''}>
        <i aria-hidden="true"></i>
      </label>`;
    const range = (setting, label, min, max, step=1, unit='') => {
      const value = this.number(s[setting], this.defaults[setting], min, max);
      return `<label class="design-range-row">
        <span><strong>${label}</strong><em data-range-value="${setting}">${value}${unit}</em></span>
        <input type="range" min="${min}" max="${max}" step="${step}" value="${value}" data-design-range="${setting}" data-range-unit="${unit}">
      </label>`;
    };

    body.innerHTML = `
      <div class="design-settings-stack">
        <section class="design-settings-section">
          <div class="settings-card-kicker">Color palette</div>
          <div class="design-choice-grid five">
            ${choice('uiPalette', 'teal', 'Teal', 'Computer Care default')}
            ${choice('uiPalette', 'blue', 'Blue', 'Cool academy')}
            ${choice('uiPalette', 'emerald', 'Emerald', 'Fresh contrast')}
            ${choice('uiPalette', 'violet', 'Violet', 'Creative portal')}
            ${choice('uiPalette', 'gold', 'Gold', 'Warm premium')}
          </div>
        </section>
        <section class="design-settings-section">
          <div class="settings-card-kicker">Old and new design</div>
          <div class="design-choice-grid">
            ${choice('uiDesignMode', 'modern', 'New', 'Glass, gradients, richer depth')}
            ${choice('uiDesignMode', 'classic', 'Old', 'Cleaner legacy academy layout')}
          </div>
        </section>
        <section class="design-settings-section">
          <div class="settings-card-kicker">Surface style</div>
          <div class="design-choice-grid three">
            ${choice('uiSurfaceStyle', 'glass', 'Glass', 'Transparent panels')}
            ${choice('uiSurfaceStyle', 'neumorphic', 'Neo', 'Soft raised controls')}
            ${choice('uiSurfaceStyle', 'flat', 'Flat', 'Material-style clarity')}
          </div>
        </section>
        <section class="design-settings-section">
          <div class="settings-card-kicker">Background and contrast</div>
          <div class="design-choice-grid three">
            ${choice('uiBackgroundStyle', 'aurora', 'Aurora', 'Colorful gradient background')}
            ${choice('uiBackgroundStyle', 'clean', 'Clean', 'Quiet solid workspace')}
            ${choice('uiBackgroundStyle', 'mesh', 'Mesh', 'Layered academy depth')}
          </div>
          <div class="design-choice-grid three mt-1">
            ${choice('uiContrast', 'soft', 'Soft', 'Lower visual pressure')}
            ${choice('uiContrast', 'normal', 'Normal', 'Balanced contrast')}
            ${choice('uiContrast', 'high', 'High', 'Strong text and borders')}
          </div>
        </section>
        <section class="design-settings-section">
          <div class="settings-card-kicker">Font and text size</div>
          <div class="design-choice-grid four">
            ${choice('uiFontFamily', 'inter', 'Inter', 'Modern UI font')}
            ${choice('uiFontFamily', 'system', 'System', 'Native device font')}
            ${choice('uiFontFamily', 'serif', 'Serif', 'Formal reports feel')}
            ${choice('uiFontFamily', 'mono', 'Mono', 'Technical console feel')}
          </div>
          ${range('uiFontSize', 'Base font size', 13, 20, 1, 'px')}
        </section>
        <section class="design-settings-section">
          <div class="settings-card-kicker">Spacing</div>
          <div class="design-choice-grid">
            ${choice('uiDensity', 'comfortable', 'Comfort', 'More breathing room')}
            ${choice('uiDensity', 'compact', 'Compact', 'More records on screen')}
          </div>
          <div class="design-choice-grid three mt-1">
            ${choice('uiCornerStyle', 'sharp', 'Sharp', 'Small corners')}
            ${choice('uiCornerStyle', 'soft', 'Soft', 'Default rounded style')}
            ${choice('uiCornerStyle', 'round', 'Round', 'Softer large corners')}
          </div>
        </section>
        <section class="design-settings-section">
          <div class="settings-card-kicker">Navigation and icons</div>
          <div class="design-choice-grid three">
            ${choice('uiSidebarSize', 'compact', 'Compact Aside', 'Narrow side bar')}
            ${choice('uiSidebarSize', 'normal', 'Normal Aside', 'Balanced navigation')}
            ${choice('uiSidebarSize', 'wide', 'Wide Aside', 'More menu text room')}
          </div>
          <div class="design-choice-grid three mt-1">
            ${choice('uiNavStyle', 'iconText', 'Icons + Text', 'Full navigation labels')}
            ${choice('uiNavStyle', 'pills', 'Pills', 'Stronger active menu bars')}
            ${choice('uiNavStyle', 'minimal', 'Minimal', 'Quiet aside/menu style')}
          </div>
          <div class="design-choice-grid three mt-1">
            ${choice('uiIconStyle', 'plain', 'Plain Icons', 'Simple symbols')}
            ${choice('uiIconStyle', 'badge', 'Badge Icons', 'Icon chips')}
            ${choice('uiIconStyle', 'mono', 'Mono Icons', 'Reduced color noise')}
          </div>
        </section>
        <section class="design-settings-section">
          <div class="settings-card-kicker">Effects and visibility</div>
          ${range('uiShadowLevel', 'Shadow depth', 0, 4, 1)}
          ${range('uiBorderLevel', 'Border strength', 0, 4, 1)}
          ${range('uiOutlineLevel', 'Focus outline', 0, 5, 1, 'px')}
          ${range('uiBrightness', 'Brightness', 70, 135, 5, '%')}
          ${range('uiSaturation', 'Saturation', 50, 180, 5, '%')}
          ${range('uiHighlightLevel', 'Highlight glow', 0, 4, 1)}
          ${range('uiPanelOpacity', 'Panel opacity', 45, 98, 1, '%')}
          ${range('uiBlurLevel', 'Glass blur', 0, 30, 1, 'px')}
        </section>
        <section class="design-settings-section">
          <div class="settings-card-kicker">Scrolling and responsive behavior</div>
          <div class="design-choice-grid three">
            ${choice('uiScrollStyle', 'thin', 'Thin Scroll', 'Compact scrollbars')}
            ${choice('uiScrollStyle', 'color', 'Color Scroll', 'High visibility scrollbars')}
            ${choice('uiScrollStyle', 'bold', 'Bold Scroll', 'Large touch scrollbars')}
          </div>
          ${toggle('uiBottomNav', 'Mobile bottom navigation', 'Quick portal links on phones')}
          ${toggle('uiWideTables', 'Wide data tables', 'Keeps columns readable with horizontal scroll')}
          ${toggle('uiReduceMotion', 'Reduced motion', 'Turns down animations and transitions')}
        </section>
      </div>`;

    body.querySelectorAll('[data-design-setting]').forEach(btn => {
      btn.addEventListener('click', () => {
        this.save({ [btn.dataset.designSetting]: btn.dataset.designValue });
      });
    });
    body.querySelectorAll('[data-design-toggle]').forEach(input => {
      input.addEventListener('change', () => {
        this.save({ [input.dataset.designToggle]: input.checked });
      });
    });
    body.querySelectorAll('[data-design-range]').forEach(input => {
      const update = () => {
        const output = body.querySelector(`[data-range-value="${input.dataset.designRange}"]`);
        if (output) output.textContent = input.value + (input.dataset.rangeUnit || '');
      };
      input.addEventListener('input', () => {
        update();
        this.save({ [input.dataset.designRange]: Number(input.value) }, { render:false });
      });
      input.addEventListener('change', () => this.renderPanel());
    });
  },

  repairChrome() {
    document.querySelectorAll('.nav-menu').forEach(nav => nav.setAttribute('aria-label', nav.getAttribute('aria-label') || 'Portal navigation'));
    document.querySelectorAll('.nav-item.active').forEach(item => item.setAttribute('aria-current', 'page'));
    document.querySelectorAll('.modal').forEach(modal => {
      modal.setAttribute('role', modal.getAttribute('role') || 'dialog');
      modal.setAttribute('aria-modal', modal.getAttribute('aria-modal') || 'true');
    });
    document.querySelectorAll('.modal-close').forEach(btn => {
      if (!btn.getAttribute('aria-label')) btn.setAttribute('aria-label', 'Close dialog');
    });
    const labels = {
      themeToggle: 'Toggle light or dark theme',
      toggleSidebar: 'Toggle navigation menu',
      logoutBtn: 'Logout',
    };
    Object.entries(labels).forEach(([id, label]) => {
      document.querySelectorAll('#' + id).forEach(btn => {
        btn.setAttribute('aria-label', btn.getAttribute('aria-label') || label);
        btn.title = btn.title || label;
      });
    });
    document.querySelectorAll('button, .btn').forEach(btn => {
      if (!btn.getAttribute('title') && btn.textContent.trim().length <= 3) {
        btn.title = btn.getAttribute('aria-label') || btn.textContent.trim();
      }
    });
  },

  syncHeaderButtons() {
    const btn = document.getElementById('academyDesignFab');
    if (btn) {
      const s = this.settings();
      btn.dataset.mode = s.uiDesignMode || 'modern';
      btn.dataset.surface = s.uiSurfaceStyle || 'glass';
    }
  },

  injectQuickMenu() {
    const headerRight = document.querySelector('.top-header .header-right');
    if (!headerRight || document.getElementById('portalQuickMenu')) return;
    const wrap = document.createElement('div');
    wrap.className = 'portal-quick-menu no-print';
    wrap.id = 'portalQuickMenu';
    wrap.innerHTML = `
      <button class="btn btn-secondary portal-quick-trigger" type="button" aria-label="Open quick menu" title="Quick menu">
        <span aria-hidden="true">&#9776;</span>
      </button>
      <div class="portal-quick-panel" role="menu" aria-label="Quick menu"></div>`;
    const themeBtn = document.getElementById('themeToggle');
    headerRight.insertBefore(wrap, themeBtn || headerRight.firstChild);
    wrap.querySelector('.portal-quick-trigger').addEventListener('click', e => {
      e.stopPropagation();
      this.renderQuickMenu(wrap.querySelector('.portal-quick-panel'));
      wrap.classList.toggle('open');
    });
    wrap.querySelector('.portal-quick-panel').addEventListener('click', e => e.stopPropagation());
    document.addEventListener('click', () => wrap.classList.remove('open'));
  },

  renderQuickMenu(panel) {
    if (!panel) return;
    panel.innerHTML = '';
    this.navItems().slice(0, 12).forEach(item => {
      panel.appendChild(this.actionFromNavItem(item, 'portal-quick-item'));
    });
    const settings = document.createElement('button');
    settings.type = 'button';
    settings.className = 'portal-quick-item';
    settings.innerHTML = '<span class="nav-icon">&#9881;</span><span>Design Settings</span>';
    settings.addEventListener('click', () => {
      document.getElementById('portalQuickMenu')?.classList.remove('open');
      this.openPanel();
    });
    panel.appendChild(settings);
  },

  navItems() {
    return [...document.querySelectorAll('.nav-menu .nav-item')]
      .filter(item => (item.querySelector('.nav-label') || item).textContent.trim());
  },

  actionFromNavItem(item, className) {
    const href = item.getAttribute('href') || '#';
    const isLink = href && href !== '#';
    const action = document.createElement(isLink ? 'a' : 'button');
    action.className = className + (item.classList.contains('active') ? ' active' : '');
    if (isLink) {
      action.href = href;
      if (item.target) action.target = item.target;
    } else {
      action.type = 'button';
      action.addEventListener('click', () => item.click());
    }
    const icon = item.querySelector('.nav-icon')?.innerHTML || '&#9679;';
    const label = (item.querySelector('.nav-label') || item).textContent.trim().replace(/\s+/g, ' ');
    action.innerHTML = `<span class="nav-icon">${icon}</span><span>${Fmt.escape(label)}</span>`;
    action.addEventListener('click', () => {
      document.getElementById('portalQuickMenu')?.classList.remove('open');
      setTimeout(() => this.injectMobileBottomNav(true), 60);
    });
    return action;
  },

  injectMobileBottomNav(force=false) {
    if (!document.body) return;
    const enabled = this.settings().uiBottomNav !== false;
    const existing = document.getElementById('mobileBottomNav');
    const items = this.navItems();
    if (!enabled || !items.length || document.body.classList.contains('login-layout')) {
      if (existing) existing.remove();
      document.body.classList.remove('has-bottom-nav');
      return;
    }
    let nav = existing;
    if (!nav) {
      nav = document.createElement('nav');
      nav.id = 'mobileBottomNav';
      nav.className = 'mobile-bottom-nav no-print';
      nav.setAttribute('aria-label', 'Mobile quick navigation');
      document.body.appendChild(nav);
    } else if (!force) {
      return;
    }
    nav.innerHTML = '';
    items.slice(0, 4).forEach(item => nav.appendChild(this.actionFromNavItem(item, 'mobile-bottom-link')));
    const settings = document.createElement('button');
    settings.type = 'button';
    settings.className = 'mobile-bottom-link';
    settings.innerHTML = '<span class="nav-icon">&#9881;</span><span>Settings</span>';
    settings.addEventListener('click', () => this.openPanel());
    nav.appendChild(settings);
    document.body.classList.add('has-bottom-nav');
  },

  bindGlobalShortcuts() {
    document.addEventListener('keydown', e => {
      if ((e.ctrlKey || e.metaKey) && e.key === ',') {
        e.preventDefault();
        this.openPanel();
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        const trigger = document.querySelector('#portalQuickMenu .portal-quick-trigger');
        if (trigger) {
          e.preventDefault();
          trigger.click();
        }
      }
    });
  },
};

/* ---------- INIT ALL ON DOM READY ---------- */
document.addEventListener('DOMContentLoaded', () => {
  DB.init();
  ThemeManager.init();
  Toast.init();
  Modal.init();
  Sidebar.init();
  HeaderNotifications.init();
  AcademyCustomization.init();
  AcademyAutoEnhance.init();
  AcademyDesign.init();
  Tabs.init();
  Dropdown.init();
  NavigationSpeed.init();
  ChartDefaults.apply();
  renderHeaderUser();

  // Birthday check
  BirthdayNotifier.check();

  // Theme toggle button
  const themeBtn = document.getElementById('themeToggle');
  if (themeBtn) themeBtn.addEventListener('click', ()=>ThemeManager.toggle());

  // Logout button
  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) logoutBtn.addEventListener('click', ()=>Auth.logout());
});


/* ---------- CUSTOMIZATION: GRID/LIST, FILTERS, SYLLABUS REVIEWS, REMINDERS ---------- */
const AcademyCustomization = (() => {
  const SYLLABUS_KEY = 'cc_syllabus_topics';
  const REVIEW_KEY = 'cc_syllabus_reviews';
  const RUN_KEY = 'cc_auto_notification_runs';
  const SEED_KEY = 'cc_syllabus_seed_version';
  const SEED_VERSION = 'latest-pdf-2026-06-26-v2';
  const STATUSES = ['All','Pending','Continue','Complete','Leave','Left'];
  const DEFAULTS = [
  {
    "id": "pdf_word",
    "course": "Basic Computer - Microsoft Word",
    "title": "Latest PDF Syllabus 26-6-26",
    "type": "Group",
    "status": "Pending",
    "source": "All Computer Care Full Latest Syllabus 26-6-26.pdf",
    "topics": [
      {
        "id": "pdf_word_t1",
        "title": "Page Settings",
        "status": "Continue",
        "subtopics": [
          "Page layout",
          "margins",
          "orientation",
          "size",
          "borders",
          "page color",
          "watermark",
          "columns"
        ]
      },
      {
        "id": "pdf_word_t2",
        "title": "Dictionary",
        "status": "Pending",
        "subtopics": [
          "Grammar and spelling checker",
          "find and replace",
          "remove extra spaces"
        ]
      },
      {
        "id": "pdf_word_t3",
        "title": "Introduction",
        "status": "Pending",
        "subtopics": [
          "Font",
          "paragraph",
          "alignment",
          "borders and shading"
        ]
      },
      {
        "id": "pdf_word_t4",
        "title": "Application Form",
        "status": "Pending",
        "subtopics": [
          "With and without textbox",
          "first and second page both side"
        ]
      },
      {
        "id": "pdf_word_t5",
        "title": "Reference Tab",
        "status": "Pending",
        "subtopics": [
          "Footnote",
          "endnote",
          "bibliography and index"
        ]
      },
      {
        "id": "pdf_word_t6",
        "title": "Insert Tools",
        "status": "Pending",
        "subtopics": [
          "Pictures",
          "shapes",
          "symbols",
          "SmartArt",
          "charts",
          "text box",
          "WordArt"
        ]
      },
      {
        "id": "pdf_word_t7",
        "title": "Brochures and Certificates",
        "status": "Pending",
        "subtopics": [
          "Portrait",
          "landscape",
          "project formats and design practice"
        ]
      },
      {
        "id": "pdf_word_t8",
        "title": "Tables",
        "status": "Pending",
        "subtopics": [
          "Table features",
          "pamphlet tables",
          "convert text to table",
          "repeat header row"
        ]
      },
      {
        "id": "pdf_word_t9",
        "title": "Resume, Invoice and Mail Merge",
        "status": "Pending",
        "subtopics": [
          "Resume formats",
          "invoice practice",
          "mail merge and labels"
        ]
      },
      {
        "id": "pdf_word_t10",
        "title": "AI, Tips and Tricks",
        "status": "Pending",
        "subtopics": [
          "Artificial intelligence use",
          "shortcuts and practical projects"
        ]
      }
    ]
  },
  {
    "id": "pdf_excel",
    "course": "Basic Computer - Microsoft Excel",
    "title": "Latest PDF Syllabus 26-6-26",
    "type": "Group",
    "status": "Pending",
    "source": "All Computer Care Full Latest Syllabus 26-6-26.pdf",
    "topics": [
      {
        "id": "pdf_excel_t1",
        "title": "Student Report",
        "status": "Continue",
        "subtopics": [
          "School assignment",
          "marks",
          "percentage",
          "grade and result formulas"
        ]
      },
      {
        "id": "pdf_excel_t2",
        "title": "Attendance Register",
        "status": "Pending",
        "subtopics": [
          "Date",
          "student attendance",
          "present and absent reports"
        ]
      },
      {
        "id": "pdf_excel_t3",
        "title": "Product Sale and GST",
        "status": "Pending",
        "subtopics": [
          "Quantity",
          "rate",
          "GST",
          "total",
          "payable amount and invoice style sheets"
        ]
      },
      {
        "id": "pdf_excel_t4",
        "title": "Salary Sheet",
        "status": "Pending",
        "subtopics": [
          "Basic pay",
          "HRA",
          "PF",
          "ESI",
          "leave and monthly salary"
        ]
      },
      {
        "id": "pdf_excel_t5",
        "title": "Data Validation",
        "status": "Pending",
        "subtopics": [
          "Validation rules",
          "invalid data circles",
          "dates and allowed values"
        ]
      },
      {
        "id": "pdf_excel_t6",
        "title": "Macros",
        "status": "Pending",
        "subtopics": [
          "Application form format",
          "tick marks and automated steps"
        ]
      },
      {
        "id": "pdf_excel_t7",
        "title": "Formulas",
        "status": "Pending",
        "subtopics": [
          "Sum",
          "average",
          "count",
          "max",
          "min",
          "IF and nested formulas"
        ]
      },
      {
        "id": "pdf_excel_t8",
        "title": "Data Tools",
        "status": "Pending",
        "subtopics": [
          "Separation",
          "Go To Special",
          "blanks and current region"
        ]
      },
      {
        "id": "pdf_excel_t9",
        "title": "Lookup Functions",
        "status": "Pending",
        "subtopics": [
          "VLOOKUP",
          "HLOOKUP",
          "XLOOKUP and lookup practice"
        ]
      },
      {
        "id": "pdf_excel_t10",
        "title": "Advanced Excel",
        "status": "Pending",
        "subtopics": [
          "Countifs",
          "sequence",
          "filtering",
          "manage data and practical assignments"
        ]
      }
    ]
  },
  {
    "id": "pdf_powerpoint",
    "course": "Basic Computer - Microsoft PowerPoint",
    "title": "Latest PDF Syllabus 26-6-26",
    "type": "Group",
    "status": "Pending",
    "source": "All Computer Care Full Latest Syllabus 26-6-26.pdf",
    "topics": [
      {
        "id": "pdf_powerpoint_t1",
        "title": "Introduction",
        "status": "Continue",
        "subtopics": [
          "PowerPoint interface and presentation basics"
        ]
      },
      {
        "id": "pdf_powerpoint_t2",
        "title": "Slides and Layout",
        "status": "Pending",
        "subtopics": [
          "Slide layouts",
          "sections and arrangement"
        ]
      },
      {
        "id": "pdf_powerpoint_t3",
        "title": "Designs and Templates",
        "status": "Pending",
        "subtopics": [
          "Themes",
          "variants",
          "custom design and templates"
        ]
      },
      {
        "id": "pdf_powerpoint_t4",
        "title": "Animations",
        "status": "Pending",
        "subtopics": [
          "Entrance",
          "emphasis",
          "exit and motion paths"
        ]
      },
      {
        "id": "pdf_powerpoint_t5",
        "title": "Transitions",
        "status": "Pending",
        "subtopics": [
          "Slide transitions",
          "timing and sound"
        ]
      },
      {
        "id": "pdf_powerpoint_t6",
        "title": "Presentation Projects",
        "status": "Pending",
        "subtopics": [
          "Student presentation",
          "business presentation and final slideshow"
        ]
      }
    ]
  },
  {
    "id": "pdf_design",
    "course": "Graphic Designing - Canva/Corel/Photoshop",
    "title": "Latest PDF Syllabus 26-6-26",
    "type": "Group",
    "status": "Pending",
    "source": "All Computer Care Full Latest Syllabus 26-6-26.pdf",
    "topics": [
      {
        "id": "pdf_design_t1",
        "title": "Canva Basics",
        "status": "Continue",
        "subtopics": [
          "Size",
          "elements",
          "text",
          "image",
          "background and templates"
        ]
      },
      {
        "id": "pdf_design_t2",
        "title": "Visiting Card and Logo",
        "status": "Pending",
        "subtopics": [
          "Multiple visiting card and logo design projects"
        ]
      },
      {
        "id": "pdf_design_t3",
        "title": "Poster and Brochure",
        "status": "Pending",
        "subtopics": [
          "Poster",
          "brochure",
          "letterhead and project report"
        ]
      },
      {
        "id": "pdf_design_t4",
        "title": "CorelDRAW Tools",
        "status": "Pending",
        "subtopics": [
          "Pick",
          "shape",
          "crop",
          "zoom",
          "curve",
          "artistic media and text tools"
        ]
      },
      {
        "id": "pdf_design_t5",
        "title": "Photoshop Drawing Tools",
        "status": "Pending",
        "subtopics": [
          "Pen",
          "freeform pen",
          "curvature",
          "anchor point and shape tools"
        ]
      },
      {
        "id": "pdf_design_t6",
        "title": "Photoshop Shortcuts",
        "status": "Pending",
        "subtopics": [
          "Undo",
          "redo",
          "zoom",
          "duplicate layer",
          "curves and common controls"
        ]
      },
      {
        "id": "pdf_design_t7",
        "title": "Design Projects",
        "status": "Pending",
        "subtopics": [
          "Certificates",
          "social media post",
          "report cover and print-ready layout"
        ]
      }
    ]
  },
  {
    "id": "pdf_html",
    "course": "Web Designing - HTML",
    "title": "Latest PDF Syllabus 26-6-26",
    "type": "Group",
    "status": "Pending",
    "source": "All Computer Care Full Latest Syllabus 26-6-26.pdf",
    "topics": [
      {
        "id": "pdf_html_t1",
        "title": "Website Types",
        "status": "Continue",
        "subtopics": [
          "Static",
          "dynamic",
          "frontend",
          "backend and database websites"
        ]
      },
      {
        "id": "pdf_html_t2",
        "title": "HTML Structure",
        "status": "Pending",
        "subtopics": [
          "HTML",
          "head",
          "title and body document structure"
        ]
      },
      {
        "id": "pdf_html_t3",
        "title": "Basic Tags",
        "status": "Pending",
        "subtopics": [
          "Heading",
          "paragraph",
          "line break",
          "horizontal line and formatting tags"
        ]
      },
      {
        "id": "pdf_html_t4",
        "title": "Font and Body Attributes",
        "status": "Pending",
        "subtopics": [
          "Font size",
          "face",
          "color",
          "body margins and page settings"
        ]
      },
      {
        "id": "pdf_html_t5",
        "title": "Lists and Tables",
        "status": "Pending",
        "subtopics": [
          "Ordered list",
          "unordered list",
          "table",
          "row",
          "cell and table attributes"
        ]
      },
      {
        "id": "pdf_html_t6",
        "title": "Forms",
        "status": "Pending",
        "subtopics": [
          "Input",
          "select",
          "textarea",
          "button",
          "labels and form attributes"
        ]
      },
      {
        "id": "pdf_html_t7",
        "title": "Frames and Iframes",
        "status": "Pending",
        "subtopics": [
          "Frame",
          "frameset",
          "iframe attributes and layout"
        ]
      },
      {
        "id": "pdf_html_t8",
        "title": "HTML5 Semantic Tags",
        "status": "Pending",
        "subtopics": [
          "Details",
          "article",
          "nav",
          "section and modern semantic layout"
        ]
      }
    ]
  },
  {
    "id": "pdf_css",
    "course": "Web Designing - CSS",
    "title": "Latest PDF Syllabus 26-6-26",
    "type": "Group",
    "status": "Pending",
    "source": "All Computer Care Full Latest Syllabus 26-6-26.pdf",
    "topics": [
      {
        "id": "pdf_css_t1",
        "title": "CSS Structure",
        "status": "Continue",
        "subtopics": [
          "Inline",
          "internal",
          "external CSS syntax and file connection"
        ]
      },
      {
        "id": "pdf_css_t2",
        "title": "Selectors",
        "status": "Pending",
        "subtopics": [
          "Element",
          "ID",
          "class",
          "grouping",
          "universal and attribute selectors"
        ]
      },
      {
        "id": "pdf_css_t3",
        "title": "Pseudo Classes",
        "status": "Pending",
        "subtopics": [
          "Hover",
          "focus",
          "nth child",
          "first and last type selectors"
        ]
      },
      {
        "id": "pdf_css_t4",
        "title": "Animation and Keyframes",
        "status": "Pending",
        "subtopics": [
          "Keyframes",
          "animation name",
          "duration",
          "timing and delay"
        ]
      },
      {
        "id": "pdf_css_t5",
        "title": "Backgrounds",
        "status": "Pending",
        "subtopics": [
          "Background color",
          "image",
          "repeat",
          "position",
          "size and attachment"
        ]
      },
      {
        "id": "pdf_css_t6",
        "title": "Borders",
        "status": "Pending",
        "subtopics": [
          "Border width",
          "style",
          "color",
          "radius",
          "image and individual sides"
        ]
      },
      {
        "id": "pdf_css_t7",
        "title": "Box Model",
        "status": "Pending",
        "subtopics": [
          "Width",
          "height",
          "margin",
          "padding",
          "box sizing and overflow"
        ]
      },
      {
        "id": "pdf_css_t8",
        "title": "Display and Position",
        "status": "Pending",
        "subtopics": [
          "Block",
          "inline",
          "flex",
          "grid",
          "float and positioning"
        ]
      },
      {
        "id": "pdf_css_t9",
        "title": "Flexbox",
        "status": "Pending",
        "subtopics": [
          "Flex direction",
          "wrap",
          "justify content",
          "align items and gap"
        ]
      },
      {
        "id": "pdf_css_t10",
        "title": "CSS Grid",
        "status": "Pending",
        "subtopics": [
          "Grid template columns",
          "rows",
          "grid item placement and area"
        ]
      },
      {
        "id": "pdf_css_t11",
        "title": "Fonts and Text",
        "status": "Pending",
        "subtopics": [
          "Font family",
          "size",
          "weight",
          "style",
          "line height and text alignment"
        ]
      },
      {
        "id": "pdf_css_t12",
        "title": "Transitions and Transforms",
        "status": "Pending",
        "subtopics": [
          "2D/3D transform",
          "transition property",
          "duration and timing"
        ]
      },
      {
        "id": "pdf_css_t13",
        "title": "CSS Functions",
        "status": "Pending",
        "subtopics": [
          "Calc",
          "clamp",
          "min",
          "max",
          "var",
          "rgb",
          "rgba and filter functions"
        ]
      }
    ]
  }
];

  function sess(){ try { return (typeof Auth !== 'undefined' && Auth.getSession && Auth.getSession()) || {}; } catch(e){ return {}; } }
  function canEdit(){ const role = sess().role; return role === 'admin' || role === 'teacher'; }
  function isStudent(){ return sess().role === 'student'; }
  function esc(v){ return String(v == null ? '' : v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function uid(prefix){ return prefix + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,7); }
  function clone(value){ return JSON.parse(JSON.stringify(value)); }
  function getSyllabus(){
    let rows = DB.get(SYLLABUS_KEY) || [];
    const seedVersion = DB.get(SEED_KEY);
    if (!rows.length || seedVersion !== SEED_VERSION) {
      const customRows = rows.filter(row => row && row.custom === true);
      rows = clone(DEFAULTS).concat(customRows);
      DB.set(SYLLABUS_KEY, rows);
      DB.set(SEED_KEY, SEED_VERSION);
    }
    return rows;
  }
  function setSyllabus(rows){ DB.set(SYLLABUS_KEY, rows); }
  function getReviews(){ return DB.get(REVIEW_KEY) || []; }
  function setReviews(rows){ DB.set(REVIEW_KEY, rows); }
  function statusOptions(selected){ return ['Pending','Continue','Complete','Leave','Left'].map(s => '<option value="'+s+'" '+(s===selected?'selected':'')+'>'+s+'</option>').join(''); }
  function optionList(values, suffix){ return values.map(v => '<option value="'+esc(v)+'">'+esc(v)+(suffix || '')+'</option>').join(''); }

  function enhanceNavigation(){
    document.querySelectorAll('.nav-menu').forEach(nav => {
      const courses = nav.querySelector('a[href="courses.html"]') || nav.lastElementChild;
      const ensure = (href, icon, label, after) => {
        let a = nav.querySelector('a[href="'+href+'"]');
        if (!a) {
          a = document.createElement('a');
          a.href = href;
          a.className = 'nav-item';
          a.innerHTML = '<span class="nav-icon">'+icon+'</span><span class="nav-label">'+label+'</span>';
          (after || courses || nav.lastElementChild).insertAdjacentElement('afterend', a);
        }
        return a;
      };
      const inquiry = ensure('inquiries.html','&#128222;','Inquiries',courses);
      ensure('internship.html','&#128188;','Internships',inquiry);
    });
  }

  function initNotesSyllabus(){
    if (!/teacher-notes.html$/i.test(location.pathname)) return;
    const area = document.querySelector('.content-area');
    if (!area || document.getElementById('syllabusReviewSection')) return;
    const nav = document.createElement('div');
    nav.className = 'notes-subnav no-print';
    nav.innerHTML = '<button class="notes-subtab active" data-view="notes">Notes</button><button class="notes-subtab" data-view="syllabus">Syllabus & Reviews</button>';
    area.insertAdjacentElement('afterbegin', nav);
    const section = document.createElement('section');
    section.id = 'syllabusReviewSection';
    section.className = 'syllabus-review-wrap hidden';
    area.appendChild(section);
    nav.querySelectorAll('[data-view]').forEach(btn => btn.addEventListener('click', () => {
      const show = btn.dataset.view === 'syllabus';
      document.querySelectorAll('.notes-subtab').forEach(b => b.classList.toggle('active', b === btn));
      document.querySelectorAll('.content-area > :not(.notes-subnav):not(#syllabusReviewSection):not(#globalViewFilterBar)').forEach(el => el.classList.toggle('hidden', show));
      section.classList.toggle('hidden', !show);
      renderSyllabus();
    }));
    renderSyllabus();
  }

  function shell(){
    const courseNames = [...new Set(getSyllabus().map(s => s.course).concat((DB.getCourses ? DB.getCourses() : []).map(c => c.name)))].filter(Boolean);
    const students = DB.getStudents ? DB.getStudents() : [];
    const studentOptions = students.map(st => '<label class="student-picker-option"><input type="checkbox" value="'+esc(st.id)+'"><span>'+esc(st.name)+'</span></label>').join('');
    const viewMode = AcademyView.get('syllabusTopics', 'grid');
    const cardLayout = getCardLayout();
    return '<div class="glass-panel syllabus-toolbar"><div class="search-wrapper"><span class="search-icon">&#128269;</span><input id="syllabusSearch" class="form-control" placeholder="Search syllabus, topic, sub-topic, review"></div><select id="syllabusCourseFilter" class="form-control"><option value="All">All Courses</option>'+optionList(courseNames,'')+'</select><select id="syllabusStatusFilter" class="form-control">'+optionList(STATUSES,' Status')+'</select><select id="syllabusTypeFilter" class="form-control"><option value="All">All Types</option><option value="Individual">Individual</option><option value="Group">Group</option></select>'+AcademyView.toggleMarkup('syllabusTopics', viewMode, 'Layout')+layoutToggleMarkup(cardLayout)+(canEdit()?'<button class="btn btn-secondary" onclick="AcademyCustomization.resetLatestSyllabus()">Use Latest PDF Defaults</button>':'')+'</div>'+(canEdit()?'<div class="glass-panel syllabus-editor"><h4>Syllabus Builder</h4><div class="form-grid syllabus-form-grid"><input id="syCourse" class="form-control" placeholder="Course name"><input id="syTitle" class="form-control" placeholder="Syllabus title"><input id="syTopic" class="form-control" placeholder="Topic"><input id="sySubtopics" class="form-control" placeholder="Sub topics comma separated"><select id="syStatus" class="form-control"><option>Pending</option><option>Continue</option><option>Complete</option><option>Leave</option><option>Left</option></select><select id="syType" class="form-control" onchange="AcademyCustomization.toggleStudentPicker(this.value)"><option>Group</option><option>Individual</option></select><div class="student-picker" id="syStudentsWrap" style="display:none"><button type="button" class="form-control student-picker-btn" id="syStudentsBtn" onclick="AcademyCustomization.toggleStudentPanel(event)">Select students &#9662;</button><div class="student-picker-panel hidden" id="syStudentsPanel">'+(studentOptions || '<div class="text-muted" style="padding:8px">No students found</div>')+'</div></div><button class="btn btn-primary" onclick="AcademyCustomization.addSyllabusTopic()">Add Topic</button></div></div>':'')+'<div id="syllabusList" class="syllabus-list'+(cardLayout==='layout2'?' layout-2':'')+'" data-view="'+esc(viewMode)+'"></div>';
  }

  const CARD_LAYOUT_KEY = 'cc_syllabus_card_layout';
  function getCardLayout(){ try { const v = localStorage.getItem(CARD_LAYOUT_KEY); return v === 'layout2' ? 'layout2' : 'default'; } catch(e) { return 'default'; } }
  function setCardLayout(mode){ try { localStorage.setItem(CARD_LAYOUT_KEY, mode === 'layout2' ? 'layout2' : 'default'); } catch(e) {} }
  function layoutToggleMarkup(current){
    return '<div class="view-toggle" role="group" aria-label="Card Layout">'
      + '<button type="button" class="view-toggle-btn '+(current==='default'?'active':'')+'" data-layout-choice="default" title="Default card layout">&#9642; Default</button>'
      + '<button type="button" class="view-toggle-btn '+(current==='layout2'?'active':'')+'" data-layout-choice="layout2" title="Alternate card layout">&#9733; Layout 2</button>'
      + '</div>';
  }

  function refreshCourseFilterOptions(){
    const sel = document.getElementById('syllabusCourseFilter');
    if (!sel) return;
    const current = sel.value || 'All';
    const courseNames = [...new Set(getSyllabus().map(s => s.course).concat((DB.getCourses ? DB.getCourses() : []).map(c => c.name)))].filter(Boolean).sort();
    sel.innerHTML = '<option value="All">All Courses</option>' + optionList(courseNames, '');
    sel.value = (current === 'All' || courseNames.includes(current)) ? current : 'All';
  }

  function toggleStudentPicker(type){
    const wrap = document.getElementById('syStudentsWrap');
    if (wrap) wrap.style.display = type === 'Individual' ? '' : 'none';
    if (type !== 'Individual') closeStudentPanel();
  }
  function toggleStudentPanel(evt){
    if (evt) evt.stopPropagation();
    const panel = document.getElementById('syStudentsPanel');
    const btn = document.getElementById('syStudentsBtn');
    if (!panel || !btn) return;
    const opening = panel.classList.contains('hidden');
    if (opening) {
      document.body.appendChild(panel);
      const rect = btn.getBoundingClientRect();
      panel.style.position = 'fixed';
      panel.style.top = (rect.bottom + 6) + 'px';
      panel.style.left = rect.left + 'px';
      panel.style.width = rect.width + 'px';
      panel.style.zIndex = 9999;
      panel.classList.remove('hidden');
    } else {
      panel.classList.add('hidden');
    }
  }
  function closeStudentPanel(){
    const panel = document.getElementById('syStudentsPanel');
    if (panel) panel.classList.add('hidden');
  }
  function getSelectedStudentIds(){
    return [...document.querySelectorAll('#syStudentsPanel input[type="checkbox"]:checked')].map(c => c.value);
  }
  function updateStudentPickerLabel(){
    const btn = document.getElementById('syStudentsBtn');
    if (!btn) return;
    const n = document.querySelectorAll('#syStudentsPanel input[type="checkbox"]:checked').length;
    btn.textContent = (n ? n + ' student' + (n > 1 ? 's' : '') + ' selected' : 'Select students') + ' \u25be';
  }

  function renderSyllabus(){
    const section = document.getElementById('syllabusReviewSection');
    if (!section) return;
    if (!document.getElementById('syllabusList')) {
      section.innerHTML = shell();
      AcademyView.bind(section, 'syllabusTopics', mode => {
        const list = document.getElementById('syllabusList');
        if (list) list.dataset.view = mode;
      });
      section.querySelectorAll('[data-layout-choice]').forEach(btn => {
        btn.addEventListener('click', () => {
          const mode = btn.dataset.layoutChoice === 'layout2' ? 'layout2' : 'default';
          setCardLayout(mode);
          section.querySelectorAll('[data-layout-choice]').forEach(b => b.classList.toggle('active', b === btn));
          const list = document.getElementById('syllabusList');
          if (list) list.classList.toggle('layout-2', mode === 'layout2');
        });
      });
      const stuPanel = document.getElementById('syStudentsPanel');
      if (stuPanel) stuPanel.addEventListener('change', updateStudentPickerLabel);
      document.addEventListener('click', (e) => {
        const wrap = document.getElementById('syStudentsWrap');
        const panel = document.getElementById('syStudentsPanel');
        if (wrap && !wrap.contains(e.target) && !(panel && panel.contains(e.target))) closeStudentPanel();
      });
      document.querySelector('.content-area')?.addEventListener('scroll', closeStudentPanel, { passive: true });
      window.addEventListener('resize', closeStudentPanel);
    }
    refreshCourseFilterOptions();
    ['syllabusSearch','syllabusCourseFilter','syllabusStatusFilter','syllabusTypeFilter'].forEach(id => {
      const el = document.getElementById(id);
      if (el && !el.dataset.bound) {
        el.dataset.bound = '1';
        el.addEventListener('input', renderSyllabus);
        el.addEventListener('change', renderSyllabus);
      }
    });
    const q = (document.getElementById('syllabusSearch')?.value || '').toLowerCase().trim();
    const course = document.getElementById('syllabusCourseFilter')?.value || 'All';
    const status = document.getElementById('syllabusStatusFilter')?.value || 'All';
    const type = document.getElementById('syllabusTypeFilter')?.value || 'All';
    const reviews = getReviews();
    const myId = sess().id;
    const matchesStatus = (item) => {
      if (status === 'All') return true;
      if (Array.isArray(item.topics) && item.topics.length) return item.topics.some(t => t.status === status);
      return item.status === status;
    };
    const rows = getSyllabus().filter(item => {
      const text = (JSON.stringify(item) + JSON.stringify(reviews.filter(r => r.syllabusId === item.id))).toLowerCase();
      const visibleToMe = !isStudent() || item.type !== 'Individual' || (Array.isArray(item.studentIds) && item.studentIds.map(String).includes(String(myId)));
      return visibleToMe && (!q || text.includes(q)) && (course === 'All' || item.course === course) && (type === 'All' || item.type === type) && matchesStatus(item);
    });
    document.getElementById('syllabusList').innerHTML = rows.map(item => {
      const displayItem = status === 'All' ? item : Object.assign({}, item, { topics: (item.topics || []).filter(t => t.status === status) });
      return card(displayItem, reviews.filter(r => r.syllabusId === item.id));
    }).join('') || '<div class="empty-state"><div class="empty-state-icon">📋</div><p>No syllabus found.</p></div>';
  }

  function card(item, itemReviews){
    const reviewHtml = itemReviews.length ? itemReviews.map(r => {
      const ratingControl = canEdit()
        ? '<select class="form-control" onchange="AcademyCustomization.rateReview(\''+r.id+'\',this.value)"><option value="">Teacher rating</option>'+[1,2,3,4,5,6,7,8,9,10].map(n => '<option value="'+n+'" '+(String(r.teacherRating)===String(n)?'selected':'')+'>'+n+'/10</option>').join('')+'</select>'
        : '<span>Teacher: '+(r.teacherRating ? esc(r.teacherRating) + '/10' : 'Pending')+'</span>';
      return '<div class="review-row"><strong>'+esc(r.studentName)+'</strong><span>'+esc(r.studentRating)+'/5</span><span>'+esc(r.comment)+'</span>'+ratingControl+'</div>';
    }).join('') : '<div class="text-muted">No reviews yet.</div>';
    const allStudents = DB.getStudents ? DB.getStudents() : [];
    const assignedIds = Array.isArray(item.studentIds) ? item.studentIds : [];
    const studentNames = item.type === 'Individual' ? assignedIds.map(id => allStudents.find(s => s.id === id)?.name).filter(Boolean) : [];
    const studentMeta = item.type === 'Individual' ? ' | Students: '+esc(studentNames.length ? studentNames.join(', ') : 'Not assigned') : '';
    const studentEditor = (canEdit() && item.type === 'Individual')
      ? '<select class="form-control" multiple size="3" title="Hold Ctrl/Cmd to pick multiple students" onchange="AcademyCustomization.updateSyllabusStudents(\''+item.id+'\',this)">'+allStudents.map(st => '<option value="'+esc(st.id)+'" '+(assignedIds.includes(st.id)?'selected':'')+'>'+esc(st.name)+'</option>').join('')+'</select>'
      : '';
    const actions = canEdit()
      ? '<div class="syllabus-actions"><select class="form-control" onchange="AcademyCustomization.updateSyllabusStatus(\''+item.id+'\',this.value)">'+statusOptions(item.status)+'</select>'+studentEditor+'<button class="btn btn-danger btn-sm" onclick="AcademyCustomization.removeSyllabus(\''+item.id+'\')">Remove Syllabus</button></div>'
      : '';
    return '<article class="glass-panel syllabus-card" data-status="'+esc(item.status)+'" data-type="'+esc(item.type)+'"><div class="syllabus-card-head"><div><h3>'+esc(item.course)+' - '+esc(item.title)+'</h3><p>'+esc(item.type)+' | '+esc(item.status)+' Status | Reviews: '+itemReviews.length+studentMeta+' | '+esc(item.source || 'Custom syllabus')+'</p></div>'+actions+'</div><div class="syllabus-topic-grid">'+item.topics.map(t => topicCard(item,t)).join('')+'</div><div class="review-list">'+reviewHtml+'</div></article>';
  }

  function updateSyllabusStudents(sid, selectEl){
    const ids = [...selectEl.selectedOptions].map(o => o.value);
    mutateSyllabus(rows => { const item = rows.find(s => s.id === sid); if (item) item.studentIds = ids; });
    Toast.success('Assigned students updated');
  }

  function topicCard(item, topic){
    const subtopics = (topic.subtopics || []).map((sub, index) => '<li><span>'+esc(sub)+'</span>'+(canEdit()?'<button class="icon-btn danger" title="Remove sub topic" onclick="AcademyCustomization.removeSubtopic(\''+item.id+'\',\''+topic.id+'\','+index+')">&times;</button>':'')+'</li>').join('');
    const editControls = canEdit()
      ? '<div class="topic-edit-row"><select class="form-control" onchange="AcademyCustomization.updateTopicStatus(\''+item.id+'\',\''+topic.id+'\',this.value)">'+statusOptions(topic.status)+'</select><input class="form-control" id="addsub_'+topic.id+'" placeholder="New sub topic"><button class="btn btn-secondary btn-sm" onclick="AcademyCustomization.addSubtopic(\''+item.id+'\',\''+topic.id+'\')">Add</button><button class="btn btn-danger btn-sm" onclick="AcademyCustomization.removeTopic(\''+item.id+'\',\''+topic.id+'\')">Remove Topic</button></div>'
      : '';
    const reviewControls = isStudent()
      ? '<div class="student-review-form"><select id="rating_'+topic.id+'" class="form-control"><option value="5">5 Star</option><option value="4">4 Star</option><option value="3">3 Star</option><option value="2">2 Star</option><option value="1">1 Star</option></select><input id="review_'+topic.id+'" class="form-control" placeholder="Your feedback"><button class="btn btn-primary btn-sm" onclick="AcademyCustomization.addReview(\''+item.id+'\',\''+topic.id+'\')">Review</button></div>'
      : '';
    return '<div class="syllabus-topic" data-status="'+esc(topic.status)+'"><div class="topic-title"><span>'+esc(topic.title)+'</span><span class="badge badge-secondary">'+esc(topic.status)+'</span></div><ul>'+subtopics+'</ul>'+editControls+reviewControls+'</div>';
  }

  function mutateSyllabus(fn){ const rows = getSyllabus(); fn(rows); setSyllabus(rows); renderSyllabus(); }
  function addSyllabusTopic(){
    const course = document.getElementById('syCourse').value.trim();
    const topic = document.getElementById('syTopic').value.trim();
    if (!course || !topic) { Toast.warning('Course and topic are required'); return; }
    const title = document.getElementById('syTitle').value.trim() || course;
    const type = document.getElementById('syType').value;
    const studentIds = type === 'Individual' ? getSelectedStudentIds() : [];
    if (type === 'Individual' && !studentIds.length) { Toast.warning('Pick at least one student for an Individual syllabus'); return; }
    mutateSyllabus(rows => {
      let group = rows.find(r => r.course.trim().toLowerCase() === course.toLowerCase() && r.type === type);
      if (!group) {
        group = {id:uid('sy'), course, title, type, status:document.getElementById('syStatus').value, source:'Teacher/Admin', custom:true, topics:[]};
        rows.push(group);
      } else {
        group.custom = true;
        if (type === 'Individual') {
          const existingIds = Array.isArray(group.studentIds) ? group.studentIds : [];
          group.studentIds = [...new Set([...existingIds, ...studentIds])];
        }
      }
      group.topics.push({id:uid('topic'), title:topic, status:document.getElementById('syStatus').value, subtopics:(document.getElementById('sySubtopics').value || '').split(',').map(s => s.trim()).filter(Boolean)});
    });
    ['syCourse','syTitle','syTopic','sySubtopics'].forEach(id => document.getElementById(id).value = '');
    document.querySelectorAll('#syStudentsPanel input[type="checkbox"]:checked').forEach(c => c.checked = false);
    updateStudentPickerLabel();
    closeStudentPanel();
    Toast.success('Syllabus topic saved');
  }
  function removeSyllabus(id){ if (!confirm('Remove this syllabus?')) return; setSyllabus(getSyllabus().filter(s => s.id !== id)); renderSyllabus(); Toast.info('Syllabus removed'); }
  function removeTopic(sid, tid){ if (!confirm('Remove this topic?')) return; mutateSyllabus(rows => { const item = rows.find(s => s.id === sid); if (item) item.topics = item.topics.filter(t => t.id !== tid); }); Toast.info('Topic removed'); }
  function removeSubtopic(sid, tid, index){ mutateSyllabus(rows => { const topic = rows.find(s => s.id === sid)?.topics.find(t => t.id === tid); if (topic) topic.subtopics.splice(index,1); }); }
  function addSubtopic(sid, tid){ const input = document.getElementById('addsub_'+tid); const value = (input?.value || '').trim(); if (!value) { Toast.warning('Write sub topic first'); return; } mutateSyllabus(rows => { const topic = rows.find(s => s.id === sid)?.topics.find(t => t.id === tid); if (topic) { topic.subtopics = topic.subtopics || []; topic.subtopics.push(value); } }); }
  function updateTopicStatus(sid, tid, status){ mutateSyllabus(rows => { const topic = rows.find(s => s.id === sid)?.topics.find(t => t.id === tid); if (topic) topic.status = status; }); }
  function updateSyllabusStatus(sid, status){ mutateSyllabus(rows => { const item = rows.find(s => s.id === sid); if (item) item.status = status; }); }
  function resetLatestSyllabus(){ if (!confirm('Replace old default syllabus with latest PDF defaults? Teacher-added custom syllabus will stay.')) return; const customRows = getSyllabus().filter(row => row.custom === true); setSyllabus(clone(DEFAULTS).concat(customRows)); DB.set(SEED_KEY, SEED_VERSION); document.getElementById('syllabusReviewSection').innerHTML = shell(); renderSyllabus(); Toast.success('Latest PDF syllabus restored'); }
  function addReview(sid, tid){ const comment = document.getElementById('review_'+tid).value.trim(); if (!comment) { Toast.warning('Please write feedback'); return; } const s = sess(); const rows = getReviews(); rows.push({id:uid('rev'), syllabusId:sid, topicId:tid, studentId:s.id, studentName:s.name || s.username || 'Student', studentRating:Number(document.getElementById('rating_'+tid).value || 5), comment, teacherRating:'', createdAt:new Date().toISOString()}); setReviews(rows); renderSyllabus(); Toast.success('Review submitted'); }
  function rateReview(id, rating){ const rows = getReviews(); const row = rows.find(r => r.id === id); if (row) { row.teacherRating = Number(rating); row.ratedBy = sess().name || sess().username; row.ratedAt = new Date().toISOString(); setReviews(rows); Toast.success('Review rating saved'); } }


  function initStudentPortalSyllabus(){
    if (!/student-portal\.html$/i.test(location.pathname)) return;
    const notesSec = document.getElementById('sec-notes');
    if (!notesSec || document.getElementById('syllabusReviewSection')) return;
    const notesPanel = notesSec.querySelector('.glass-panel');
    const nav = document.createElement('div');
    nav.className = 'notes-subnav no-print';
    nav.innerHTML = '<button class="notes-subtab active" data-view="notes">Notes</button><button class="notes-subtab" data-view="syllabus">Syllabus Reviews</button>';
    notesSec.insertAdjacentElement('afterbegin', nav);
    const section = document.createElement('section');
    section.id = 'syllabusReviewSection';
    section.className = 'syllabus-review-wrap hidden';
    notesSec.appendChild(section);
    nav.querySelectorAll('[data-view]').forEach(btn => btn.addEventListener('click', () => {
      const show = btn.dataset.view === 'syllabus';
      nav.querySelectorAll('.notes-subtab').forEach(b => b.classList.toggle('active', b === btn));
      if (notesPanel) notesPanel.classList.toggle('hidden', show);
      section.classList.toggle('hidden', !show);
      renderSyllabus();
    }));
  }

  function automaticNotifications(){
    if (!DB.upsertNotification) return;
    const now = new Date();
    const today = now.toISOString().slice(0,10);
    const runs = DB.get(RUN_KEY) || {};
    // DB.generateMonthlyFeeReminders() (already called once from DB.init() on every
    // page load, above in this same DOMContentLoaded handler) is the single source of
    // truth for fee-reminder notifications: it builds the detailed teacher + per-
    // student messages AND only actually fires from the 10th of the month onward.
    // This module used to duplicate that with a second, simpler notification that
    // ignored the date gate entirely - producing two conflicting fee reminders every
    // month, one of them appearing before the 10th. That duplicate has been removed;
    // we just track that today's pass has happened.
    if (runs.feeMonth !== today.slice(0,7) && now.getDate() >= 10) {
      runs.feeMonth = today.slice(0,7);
    }
    if (runs.birthdayDate !== today) {
      const mmdd = today.slice(5);
      (DB.getStudents().concat(DB.getTeachers())).filter(p => p.dob && String(p.dob).slice(5) === mmdd).forEach(p => {
        DB.upsertNotification({id:'auto_birthday_'+today+'_'+p.id, title:'Birthday Today - '+p.name, message:'Today is '+p.name+' birthday. Wish them from Computer Care Academy.', type:'Birthday', target:'all', date:today, createdBy:'system', createdAt:new Date().toISOString(), priority:'Medium', icon:'🎂'});
      });
      runs.birthdayDate = today;
    }
    DB.set(RUN_KEY, runs);
  }

  function init(){ enhanceNavigation(); initNotesSyllabus(); initStudentPortalSyllabus(); automaticNotifications(); }
  return { init, addSyllabusTopic, removeSyllabus, removeTopic, removeSubtopic, addSubtopic, updateTopicStatus, updateSyllabusStatus, resetLatestSyllabus, addReview, rateReview, toggleStudentPicker, toggleStudentPanel, updateSyllabusStudents, getCardLayout, setCardLayout };
})();

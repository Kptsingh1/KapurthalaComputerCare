/* ==========================================================================
   ATTENDANCE.JS — Daily Attendance Register
   ========================================================================== */

const ATT_CYCLE = ['', 'P', 'A', 'L']; // quadruple click cycle: None > Present > Absent > Leave

let currentMonth = new Date().toISOString().slice(0,7);
let currentType = 'students'; // or 'teachers'
let currentAttCourseStatus = 'Continue';
let currentAttGender = 'All';
let currentAttBatch = 'All';
let currentAttCourse = 'All';
let currentAttClassDay = 'All';
let currentAttDate = 'All';
let currentAttMark = 'All';
let currentAttSearch = '';
let attViewMode = AcademyView ? AcademyView.get('attendance_people', 'list') : 'list';

function initAttendancePage() {
  const session = Auth.requireAuth(['admin','teacher']);
  if (!session) return;
  populateCourseStatusSelect('attCourseStatusFilter', currentAttCourseStatus, true);
  enhanceAttendanceFilters();
  const statusFilter = document.getElementById('attCourseStatusFilter');
  if (statusFilter) {
    statusFilter.value = currentAttCourseStatus;
    statusFilter.addEventListener('change', () => {
      currentAttCourseStatus = statusFilter.value || 'All';
      renderAttendanceTable();
      renderAttendanceSummary();
    });
  }
  const genderFilter = document.getElementById('attGenderFilter');
  if (genderFilter) {
    genderFilter.addEventListener('change', () => {
      currentAttGender = genderFilter.value || 'All';
      renderAttendanceTable();
      renderAttendanceSummary();
    });
  }

  // Month picker
  const monthPicker = document.getElementById('attMonthPicker');
  if (monthPicker) {
    monthPicker.value = currentMonth;
    monthPicker.addEventListener('change', ()=>{
      currentMonth = monthPicker.value;
      updateAttendanceDayOptions();
      renderAttendanceTable();
      renderAttendanceSummary();
    });
  }

  // Type tabs
  document.querySelectorAll('[data-att-type]').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      document.querySelectorAll('[data-att-type]').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      currentType = btn.dataset.attType;
      renderAttendanceTable();
      renderAttendanceSummary();
    });
  });

  renderAttendanceTable();
  renderAttendanceSummary();
}

function enhanceAttendanceFilters() {
  const filterShell = document.querySelector('.sticky-filters');
  if (filterShell && !document.getElementById('attAdvancedFilters')) {
    filterShell.classList.add('has-attendance-filters');
    filterShell.insertAdjacentHTML('beforeend', `
      <div class="academy-filter-panel attendance-filter-panel" id="attAdvancedFilters" data-no-auto-enhance="true">
        <div class="academy-filter-grid">
          <div class="search-wrapper">
            <span class="search-icon">&#128269;</span>
            <input type="search" id="attSearch" class="form-control" placeholder="Search name, batch, course">
          </div>
          <select id="attCourseFilter" class="form-control">${AcademyFilters.coursesOptions()}</select>
          <select id="attBatchFilter" class="form-control">${AcademyFilters.batchOptions()}</select>
          <select id="attClassDayFilter" class="form-control">${AcademyFilters.dayOptions('All', 'All Class Days')}</select>
          <select id="attDateFilter" class="form-control"></select>
          <select id="attMarkFilter" class="form-control">
            <option value="All">Any Mark</option>
            <option value="P">Present on selected day</option>
            <option value="A">Absent on selected day</option>
            <option value="L">Leave on selected day</option>
            <option value="">Not marked on selected day</option>
          </select>
          <button type="button" class="btn btn-secondary filter-clear-btn" onclick="clearAttendanceFilters()">Clear Filters</button>
        </div>
      </div>
    `);
  }
  const attendancePanel = document.querySelector('.att-table-panel');
  if (attendancePanel && !document.getElementById('attendanceViewToolbar')) {
    attendancePanel.insertAdjacentHTML('beforebegin', AcademyView.toolbarMarkup('attendance_people', attViewMode, 'Attendance view', 'attAdvancedCount', '0 records'));
    const toolbar = document.querySelector('[data-view-toolbar="attendance_people"]');
    if (toolbar) toolbar.id = 'attendanceViewToolbar';
    AcademyView.bind(toolbar, 'attendance_people', mode => {
      attViewMode = mode;
      renderAttendanceTable();
    });
  }
  updateAttendanceDayOptions();
  [
    ['attSearch', value => { currentAttSearch = value; }],
    ['attCourseFilter', value => { currentAttCourse = value || 'All'; }],
    ['attBatchFilter', value => { currentAttBatch = value || 'All'; }],
    ['attClassDayFilter', value => { currentAttClassDay = value || 'All'; }],
    ['attDateFilter', value => { currentAttDate = value || 'All'; }],
    ['attMarkFilter', value => { currentAttMark = value; }],
  ].forEach(([id, setter]) => {
    const el = document.getElementById(id);
    if (!el || el.dataset.boundAttFilter === '1') return;
    el.dataset.boundAttFilter = '1';
    const refresh = () => {
      setter(el.value || '');
      renderAttendanceTable();
      renderAttendanceSummary();
    };
    el.addEventListener('input', refresh);
    el.addEventListener('change', refresh);
  });
}

function updateAttendanceDayOptions() {
  const sel = document.getElementById('attDateFilter');
  if (!sel) return;
  const days = getDaysInMonth(currentMonth);
  const old = sel.value || 'All';
  sel.innerHTML = '<option value="All">All Dates</option>' +
    Array.from({ length:days }, (_, i) => `<option value="${i + 1}">Date ${i + 1} (${getDayName(currentMonth, i + 1)})</option>`).join('');
  sel.value = [...sel.options].some(o => o.value === old) ? old : 'All';
  currentAttDate = sel.value || 'All';
}

function clearAttendanceFilters() {
  ['attSearch'].forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
  [['attCourseFilter','All'],['attBatchFilter','All'],['attClassDayFilter','All'],['attDateFilter','All'],['attMarkFilter','All'],['attGenderFilter','All'],['attCourseStatusFilter','All']].forEach(([id, value]) => {
    const el = document.getElementById(id);
    if (el) el.value = value;
  });
  currentAttCourseStatus = 'All';
  currentAttGender = 'All';
  currentAttBatch = 'All';
  currentAttCourse = 'All';
  currentAttClassDay = 'All';
  currentAttDate = 'All';
  currentAttMark = 'All';
  currentAttSearch = '';
  renderAttendanceTable();
  renderAttendanceSummary();
}

function getDaysInMonth(yearMonth) {
  const [y,m] = yearMonth.split('-').map(Number);
  return new Date(y, m, 0).getDate();
}

function getDayName(yearMonth, day) {
  const [y,m] = yearMonth.split('-').map(Number);
  const d = new Date(y, m-1, day);
  return d.toLocaleDateString('en-IN',{weekday:'short'});
}

function renderAttendanceTable() {
  const people = getAttendancePeople();
  const attData = DB.getAttendance(currentMonth);
  const days = getDaysInMonth(currentMonth);
  const tableWrap = document.getElementById('attendanceTableWrap');
  if (!tableWrap) return;
  const countEl = document.getElementById('attAdvancedCount');
  if (countEl) countEl.textContent = `${people.length} record${people.length === 1 ? '' : 's'}`;
  if (attViewMode === 'grid') {
    tableWrap.classList.add('is-grid-view');
    renderAttendanceCards(people, attData, days, tableWrap);
    return;
  }
  tableWrap.classList.remove('is-grid-view');

  const todayObj = new Date();
  todayObj.setHours(0,0,0,0);
  const [cy, cm] = currentMonth.split('-').map(Number);

  // Build header
  let header = '<tr><th style="position:sticky;left:0;top:0;z-index:5;min-width:160px;background:var(--table-header-bg);white-space:nowrap">Name</th>';
  for(let d=1; d<=days; d++){
    const dayName = getDayName(currentMonth, d);
    const isSun = dayName==='Sun';
    const thisDate = new Date(cy, cm-1, d);
    thisDate.setHours(0,0,0,0);
    const isToday = thisDate.getTime() === todayObj.getTime();
    const isFuture = thisDate > todayObj;
    let thClass = '';
    if(isSun) thClass += ' att-sunday';
    if(isToday) thClass += ' att-today';
    const futureStyle = isFuture ? 'opacity:0.45;' : '';
    header += `<th class="${thClass.trim()}" style="position:sticky;top:0;z-index:2;background:var(--table-header-bg);${futureStyle}">`
      + `${d}<br><span style="font-size:0.63rem;font-weight:400">${dayName}</span>`
      + (isToday ? `<br><span style="font-size:0.6rem;color:var(--primary);font-weight:700">TODAY</span>` : '')
      + `</th>`;
  }
  header += '<th style="position:sticky;right:0;top:0;z-index:5;background:var(--table-header-bg);min-width:110px;white-space:nowrap">Summary</th></tr>';

  // Build rows
  let rows = '';
  if(!people.length){
    rows = `<tr><td colspan="${days+2}" class="text-center text-muted" style="padding:30px">No ${currentType} found</td></tr>`;
  } else {
    people.forEach(person=>{
      const personAtt = attData[person.id] || {};
      let P=0,A=0,L=0;
      let rowCells = '';
      for(let d=1; d<=days; d++){
        const status = personAtt[d] || '';
        if(status==='P') P++;
        else if(status==='A') A++;
        else if(status==='L') L++;
        const label = status||'—';
        const editable = isEditableAttendanceDay(currentMonth, d);
        const dayName2 = getDayName(currentMonth, d);
        const isSun2 = dayName2==='Sun';
        const thisDate2 = new Date(cy, cm-1, d);
        thisDate2.setHours(0,0,0,0);
        const isToday2 = thisDate2.getTime() === todayObj.getTime();
        let tdClass = '';
        if(isSun2) tdClass += ' att-sunday';
        if(isToday2) tdClass += ' att-today';
        rowCells += `<td class="${tdClass.trim()}" style="padding:3px"><div class="att-cell" data-status="${status}" data-person="${person.id}" data-day="${d}" data-editable="${editable?'1':'0'}" onclick="cycleAttendance(this)" title="${editable?'Click: None→P→A→L':'Future dates are locked'}">${label}</div></td>`;
      }
      const total = P+A+L;
      const pct = total>0 ? Math.round((P/total)*100) : 0;
      rows += `<tr>
        <td style="position:sticky;left:0;z-index:2;background:var(--glass-bg-heavy);padding:8px 12px;min-width:160px;white-space:nowrap">
          <div style="display:flex;align-items:center;gap:8px">
            ${ProfileImage.avatar(person, '', 'width:26px;height:26px;font-size:0.65rem;flex-shrink:0')}
            <span style="font-size:0.82rem;font-weight:600;white-space:nowrap">${person.name}</span>
          </div>
        </td>
        ${rowCells}
        <td style="position:sticky;right:0;z-index:2;background:var(--glass-bg-heavy);padding:6px 10px;min-width:110px;white-space:nowrap">
          <div style="font-size:0.72rem;display:flex;flex-direction:column;gap:2px">
            <span style="color:var(--success)">✔ P:${P}</span>
            <span style="color:var(--danger)">✘ A:${A}</span>
            <span style="color:var(--warning)">○ L:${L}</span>
            <span style="color:var(--info);font-weight:700">${pct}%</span>
          </div>
        </td>
      </tr>`;
    });
  }

  const minTableWidth = 160 + days*46 + 120;
  tableWrap.innerHTML = `
    <div class="att-scroll-wrap" id="attScrollWrap">
      <button class="att-scroll-btn scroll-left hidden" id="attScrollLeft" onclick="attScroll(-1)" title="Scroll Left">&#9664;</button>
      <div class="att-scroll-inner" id="attScrollInner">
        <table class="timetable" id="attTable" style="width:100%;min-width:${minTableWidth}px">
          <thead>${header}</thead><tbody>${rows}</tbody>
        </table>
      </div>
      <button class="att-scroll-btn scroll-right" id="attScrollRight" onclick="attScroll(1)" title="Scroll Right">&#9654;</button>
    </div>`;

  initAttScrollButtons();
  scrollToTodayColumn();
}

function renderAttendanceCards(people, attData, days, tableWrap) {
  tableWrap.innerHTML = `<div class="attendance-card-grid">
    ${people.length ? people.map(person => {
      const personAtt = attData[person.id] || {};
      let P = 0, A = 0, L = 0;
      const chips = Array.from({ length:days }, (_, i) => {
        const day = i + 1;
        const status = personAtt[day] || '';
        if (status === 'P') P++;
        else if (status === 'A') A++;
        else if (status === 'L') L++;
        const cls = status === 'P' ? 'is-p' : status === 'A' ? 'is-a' : status === 'L' ? 'is-l' : '';
        return `<button type="button" class="attendance-day-chip ${cls}" data-status="${status}" data-person="${person.id}" data-day="${day}" data-editable="${isEditableAttendanceDay(currentMonth, day) ? '1' : '0'}" onclick="cycleAttendance(this)" title="Date ${day}">${status || day}</button>`;
      }).join('');
      const total = P + A + L;
      const pct = total ? Math.round((P / total) * 100) : 0;
      return `<article class="attendance-person-card">
        <div class="attendance-card-top">
          <div style="display:flex;gap:10px;align-items:center;min-width:0">
            ${ProfileImage.avatar(person, '', 'width:42px;height:42px;font-size:0.82rem;flex-shrink:0')}
            <div style="min-width:0">
              <div class="person-title">${Fmt.escape(person.name)}</div>
              <div class="card-meta-line"><span>${Fmt.escape(person.course || person.subject || currentType)}</span><span>${Fmt.escape(person.batchNo || '')}</span></div>
            </div>
          </div>
          <span class="badge badge-info">${pct}%</span>
        </div>
        <div class="inquiry-status-strip">
          <span class="badge badge-success">P ${P}</span>
          <span class="badge badge-danger">A ${A}</span>
          <span class="badge badge-warning">L ${L}</span>
        </div>
        <div class="attendance-day-strip">${chips}</div>
      </article>`;
    }).join('') : '<div class="empty-state"><p>No attendance records match filters</p></div>'}
  </div>`;
}



function getAttendancePeople() {
  const q = String(currentAttSearch || '').trim().toLowerCase();
  let people = currentType === 'teachers'
    ? DB.filterTeachers({ gender:currentAttGender })
    : DB.filterStudents({
        status:currentAttCourseStatus,
        gender:currentAttGender,
        batch:currentAttBatch,
        courseId:currentAttCourse,
        day:currentAttClassDay,
      });
  if (q) {
    people = people.filter(p => [p.name, p.mobile, p.course, p.subject, p.batchNo, p.pcNo, p.day, p.gender].join(' ').toLowerCase().includes(q));
  }
  if (currentAttMark !== 'All' && currentAttDate !== 'All') {
    const data = DB.getAttendance(currentMonth);
    people = people.filter(p => (data[p.id] || {})[currentAttDate] === currentAttMark);
  }
  return people;
}

function isEditableAttendanceDay(yearMonth, day) {
  const [y, m] = yearMonth.split('-').map(Number);
  const target = new Date(y, m - 1, day);
  target.setHours(0, 0, 0, 0);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return target <= today;
}

function getMaxEditableDay(yearMonth) {
  const [y, m] = yearMonth.split('-').map(Number);
  const today = new Date();
  const days = getDaysInMonth(yearMonth);
  if (today.getFullYear() === y && today.getMonth() + 1 === m) return today.getDate();
  if (new Date(y, m - 1, 1) > today) return 0;
  return days;
}

function cycleAttendance(cell) {
  if (cell.dataset.editable !== '1') {
    Toast.warning('Attendance can be marked for old dates and today only');
    return;
  }
  const personId = cell.dataset.person;
  const day = parseInt(cell.dataset.day);
  const currentStatus = cell.dataset.status;
  const idx = ATT_CYCLE.indexOf(currentStatus);
  const nextStatus = ATT_CYCLE[(idx+1) % ATT_CYCLE.length];

  DB.markAttendance(currentMonth, personId, day, nextStatus);
  cell.dataset.status = nextStatus;
  cell.textContent = nextStatus || '—';

  // Update row summary
  updateRowSummary(personId);
  renderAttendanceSummary();
  if (attViewMode === 'grid') renderAttendanceTable();
  showAutoSave();
}

function updateRowSummary(personId) {
  const cells = document.querySelectorAll(`.att-cell[data-person="${personId}"]`);
  let P=0,A=0,L=0,T=0;
  cells.forEach(c=>{ if(c.dataset.status==='P'){P++;T++;} else if(c.dataset.status==='A'){A++;T++;} else if(c.dataset.status==='L'){L++;T++;} });
  const pct = T>0?Math.round((P/T)*100):0;
  // find summary cell
  const firstCell = cells[0];
  if(!firstCell) return;
  const row = firstCell.closest('tr');
  if(!row) return;
  const sumCell = row.lastElementChild;
  if(sumCell) sumCell.innerHTML = `<div style="font-size:0.72rem;display:flex;flex-direction:column;gap:2px"><span style="color:var(--success)">P:${P}</span><span style="color:var(--danger)">A:${A}</span><span style="color:var(--warning)">L:${L}</span><span style="color:var(--info)">${pct}%</span></div>`;
}

function renderAttendanceSummary() {
  const students = getAttendancePeople();
  const attData = DB.getAttendance(currentMonth);
  let totalP=0,totalA=0,totalL=0;
  students.forEach(s=>{
    const days = attData[s.id]||{};
    Object.values(days).forEach(v=>{ if(v==='P')totalP++; else if(v==='A')totalA++; else if(v==='L')totalL++; });
  });
  const total=totalP+totalA+totalL;
  const el=id=>document.getElementById(id);
  const set=(id,v)=>{const e=el(id);if(e)e.textContent=v;};
  set('attSumPresent',totalP);
  set('attSumAbsent',totalA);
  set('attSumLeave',totalL);
  set('attSumTotal',total);
  set('attSumPct',total?Math.round((totalP/total)*100)+'%':'0%');
}

function markAllPresent() {
  const people = getAttendancePeople();
  const maxDay = getMaxEditableDay(currentMonth);
  if (!maxDay) { Toast.warning('Future month is locked'); return; }
  people.forEach(p=>{ for(let d=1;d<=maxDay;d++) DB.markAttendance(currentMonth, p.id, d, 'P'); });
  renderAttendanceTable();
  renderAttendanceSummary();
  Toast.success('Marked all present up to today');
}

function exportAttendance() {
  const people = getAttendancePeople();
  const attData = DB.getAttendance(currentMonth);
  const days = getDaysInMonth(currentMonth);
  const headers = ['Name', ...Array.from({length:days},(_,i)=>`Day ${i+1}`), 'Present','Absent','Leave'];
  const rows = people.map(p=>{
    const pAtt = attData[p.id]||{};
    const dayVals = Array.from({length:days},(_,i)=>pAtt[i+1]||'');
    const P=dayVals.filter(v=>v==='P').length;
    const A=dayVals.filter(v=>v==='A').length;
    const L=dayVals.filter(v=>v==='L').length;
    return [p.name,...dayVals,P,A,L];
  });
  Exporter.toCSV(headers,rows,`attendance_${currentMonth}.csv`);
  Toast.success('Attendance exported!');
}

function printAttendance() {
  const people = getAttendancePeople();
  const attData = DB.getAttendance(currentMonth);
  const days = getDaysInMonth(currentMonth);
  const header = `<tr><th>Name</th>${Array.from({length:days},(_,i)=>`<th>${i+1}</th>`).join('')}<th>P</th><th>A</th><th>L</th></tr>`;
  const rows = people.map(p=>{
    const pAtt=attData[p.id]||{};
    const dayVals=Array.from({length:days},(_,i)=>pAtt[i+1]||'');
    const P=dayVals.filter(v=>v==='P').length;const A=dayVals.filter(v=>v==='A').length;const L=dayVals.filter(v=>v==='L').length;
    return `<tr><td>${p.name}</td>${dayVals.map(v=>`<td style="text-align:center;font-size:10px;color:${v==='P'?'green':v==='A'?'red':v==='L'?'orange':'#999'}">${v||'—'}</td>`).join('')}<td>${P}</td><td>${A}</td><td>${L}</td></tr>`;
  }).join('');
  Exporter.toPDF_simple(`Attendance — ${currentMonth}`,`<h2>Attendance Register — ${currentMonth}</h2><div style="overflow-x:auto"><table style="font-size:10px"><thead>${header}</thead><tbody>${rows}</tbody></table></div>`);
}

document.addEventListener('DOMContentLoaded', initAttendancePage);

/* ---------- SCROLL HELPERS ---------- */
function attScroll(dir) {
  const inner = document.getElementById('attScrollInner');
  if (!inner) return;
  const scrollAmt = inner.clientWidth * 0.7;
  inner.scrollBy({ left: dir * scrollAmt, behavior: 'smooth' });
  setTimeout(updateAttScrollBtns, 350);
}

function updateAttScrollBtns() {
  const inner = document.getElementById('attScrollInner');
  const leftBtn = document.getElementById('attScrollLeft');
  const rightBtn = document.getElementById('attScrollRight');
  if (!inner || !leftBtn || !rightBtn) return;
  const atLeft = inner.scrollLeft <= 4;
  const atRight = inner.scrollLeft + inner.clientWidth >= inner.scrollWidth - 4;
  leftBtn.classList.toggle('hidden', atLeft);
  rightBtn.classList.toggle('hidden', atRight);
}

function initAttScrollButtons() {
  const inner = document.getElementById('attScrollInner');
  if (!inner) return;
  inner.addEventListener('scroll', updateAttScrollBtns, { passive: true });
  updateAttScrollBtns();
}

function scrollToTodayColumn() {
  const inner = document.getElementById('attScrollInner');
  const table = document.getElementById('attTable');
  if (!inner || !table) return;
  // Find today header cell
  const todayTh = table.querySelector('th.att-today');
  if (!todayTh) return;
  const tableRect = table.getBoundingClientRect();
  const thRect = todayTh.getBoundingClientRect();
  const scrollTo = todayTh.offsetLeft - inner.clientWidth / 2 + todayTh.offsetWidth / 2;
  inner.scrollLeft = Math.max(0, scrollTo);
  setTimeout(updateAttScrollBtns, 100);
}

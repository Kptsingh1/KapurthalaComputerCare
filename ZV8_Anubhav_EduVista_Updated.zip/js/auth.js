/* ==========================================================================
   AUTH.JS — Authentication & Session Management
   Computer Care (Anubhav EduVista) Academy Management System
   ========================================================================== */

const Auth = {
  login(username, password) {
    const user = DB.login(username.trim(), password.trim());
    if (!user) return { success:false, message:'Invalid username or password' };
    const session = {
      ...user,
      loginTime: new Date().toISOString(),
      expires: Date.now() + 8*60*60*1000, // 8 hours
    };
    DB.setSession(session);
    return { success:true, user:session };
  },

  logout() {
    DB.clearSession();
    window.location.href = 'index.html';
  },

  getSession() {
    const s = DB.getSession();
    if (!s) return null;
    if (Date.now() > s.expires) { DB.clearSession(); return null; }
    return s;
  },

  requireAuth(allowedRoles) {
    const session = this.getSession();
    if (!session) { window.location.href='index.html'; return null; }
    if (allowedRoles && !allowedRoles.includes(session.role)) {
      if (session.role === 'student') { window.location.href='student-portal.html'; }
      else { window.location.href='teacher-dashboard.html'; }
      return null;
    }
    return session;
  },

  isLoggedIn() { return !!this.getSession(); },

  getRole() { const s=this.getSession(); return s?s.role:null; },

  redirectByRole() {
    const session = this.getSession();
    if (!session) { window.location.href='index.html'; return; }
    if (session.role==='student') window.location.href='student-portal.html';
    else window.location.href='teacher-dashboard.html';
  },
};

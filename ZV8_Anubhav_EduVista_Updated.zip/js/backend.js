/* Backend database control page. */

function initBackendPage() {
  const session = Auth.requireAuth(['admin']);
  if (!session) return;
  refreshBackendPage();
}

function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function countPayments(fees) {
  return Object.values(fees || {}).reduce((sum, record) => {
    if (Array.isArray(record)) return sum + record.length;
    return sum + ((record && record.payments && record.payments.length) || 0);
  }, 0);
}

function collectionSummary(snapshot) {
  const data = snapshot || DB.exportStorage();
  return [
    ['Students', (data.cc_students || []).length, '👥'],
    ['Teachers', (data.cc_teachers || []).length, '👨‍🏫'],
    ['Courses', (data.cc_courses || []).length, '🎓'],
    ['Payments', countPayments(data.cc_fees), '🧾'],
    ['Topics', (data.cc_topics || []).length, '📚'],
    ['Tasks', (data.cc_tasks || []).length, '✅'],
    ['Notifications', (data.cc_notifications || []).length, '🔔'],
    ['Internships', (data.cc_internships || []).length, '💼'],
    ['Devices', ((data.cc_timetable && (data.cc_timetable.devices || data.cc_timetable.days)) || []).length, '💻'],
  ];
}

function renderDatabaseSummary(snapshot) {
  const wrap = document.getElementById('databaseSummary');
  if (!wrap) return;
  wrap.innerHTML = collectionSummary(snapshot).map(([label, count, icon]) => `
    <div class="database-pill">
      <span class="database-pill-icon">${icon}</span>
      <span>${label}</span>
      <strong>${count}</strong>
    </div>
  `).join('');
}

async function refreshBackendPage() {
  const local = DB.exportStorage();
  setText('localStudentCount', String((local.cc_students || []).length));
  setText('localTeacherCount', String((local.cc_teachers || []).length));
  renderDatabaseSummary(local);

  try {
    const health = await fetch('api/health', { cache:'no-store' }).then(r => r.json());
    setText('backendStatus', health.ok ? 'Online' : 'Offline');
    setText('serverUpdatedAt', health.updatedAt ? Fmt.dateTime(health.updatedAt) : '-');
    const serverData = await fetch('api/db', { cache:'no-store' }).then(r => r.json());
    renderDatabaseSummary(serverData);
  } catch (err) {
    setText('backendStatus', 'Offline');
    setText('serverUpdatedAt', '-');
  }
}

async function syncLocalToServer() {
  try {
    const snapshot = DB.exportStorage();
    snapshot._updatedAt = new Date().toISOString();
    await fetch('api/db', {
      method: 'POST',
      headers: { 'Content-Type':'application/json' },
      body: JSON.stringify(snapshot),
    }).then(r => {
      if (!r.ok) throw new Error('Server save failed');
      return r.json();
    });
    Toast.success('Browser data saved to backend database');
    refreshBackendPage();
  } catch (err) {
    Toast.error('Backend is not running. Start it with npm start.');
  }
}

async function loadServerToLocal() {
  if (!confirm('Load server database into this browser? Current browser data will be replaced.')) return;
  try {
    const snapshot = await fetch('api/db', { cache:'no-store' }).then(r => {
      if (!r.ok) throw new Error('Server load failed');
      return r.json();
    });
    DB.applyStorageSnapshot(snapshot);
    Toast.success('Server database loaded into browser');
    refreshBackendPage();
  } catch (err) {
    Toast.error('Could not load server database');
  }
}

function downloadServerJSON() {
  window.location.href = 'api/db/download';
}

function downloadLocalJSON() {
  Exporter.toJSON(DB.exportStorage(), 'computer-care-browser-backup-' + new Date().toISOString().slice(0, 10) + '.json');
}

function importBackendSnapshot() {
  const input = document.getElementById('backendImportFile');
  if (!input || !input.files || !input.files[0]) {
    Toast.warning('Choose a JSON backup first');
    return;
  }
  const reader = new FileReader();
  reader.onload = event => {
    try {
      const snapshot = JSON.parse(event.target.result);
      const normalized = snapshot.cc_students ? snapshot : {
        cc_students: snapshot.students || [],
        cc_teachers: snapshot.teachers || [],
        cc_fees: snapshot.fees || {},
        cc_attendance: snapshot.attendance || {},
        cc_timetable: snapshot.timetable || null,
        cc_topics: snapshot.topics || [],
        cc_gallery: snapshot.gallery || [],
        cc_courses: snapshot.courses || [],
        cc_tasks: snapshot.tasks || [],
        cc_salary: snapshot.salary || {},
        cc_notifications: snapshot.notifications || [],
        cc_internships: snapshot.internships || [],
        cc_blog: snapshot.blog || [],
        cc_teacher_notes: snapshot.teacherNotes || [],
        cc_settings: snapshot.settings || DB.DEFAULT_SETTINGS,
        _updatedAt: new Date().toISOString(),
      };
      DB.applyStorageSnapshot(normalized);
      Toast.success('Backup imported into browser');
      refreshBackendPage();
    } catch (err) {
      Toast.error('Invalid JSON backup');
    }
  };
  reader.readAsText(input.files[0]);
}

document.addEventListener('DOMContentLoaded', initBackendPage);

/* ==========================================================================
   DASHBOARD.JS — Teacher Dashboard Logic
   ========================================================================== */

let dashCourseViewMode = AcademyView ? AcademyView.get('dashboard_course_analysis', 'list') : 'list';
let dashEntriesViewMode = AcademyView ? AcademyView.get('dashboard_recent_entries', 'list') : 'list';
let dashStudentsViewMode = AcademyView ? AcademyView.get('dashboard_recent_students', 'grid') : 'grid';
let dashQuickLinksViewMode = AcademyView ? AcademyView.get('dashboard_quick_links', 'grid') : 'grid';

function initDashboardViewControls() {
  setupDashboardViewToolbar({
    page:'dashboard_course_analysis',
    toolbarId:'dashCourseViewToolbar',
    countId:'dashCourseRecordCount',
    label:'Course analysis view',
    mode:dashCourseViewMode,
    tbodyId:'courseAnalysisTbody',
    cardsId:'courseAnalysisCards',
    onChange:mode => { dashCourseViewMode = mode; renderDashboard(); },
  });
  setupDashboardViewToolbar({
    page:'dashboard_recent_entries',
    toolbarId:'dashEntriesViewToolbar',
    countId:'dashEntriesRecordCount',
    label:'Recent entries view',
    mode:dashEntriesViewMode,
    tbodyId:'recentEntriesTbody',
    cardsId:'recentEntriesCards',
    onChange:mode => { dashEntriesViewMode = mode; renderDashboard(); },
  });
  setupDashboardViewToolbar({
    page:'dashboard_recent_students',
    toolbarId:'dashStudentsViewToolbar',
    countId:'dashStudentsRecordCount',
    label:'Recent students view',
    mode:dashStudentsViewMode,
    tbodyId:'recentStudentsTbody',
    cardsId:'recentStudentsCards',
    onChange:mode => { dashStudentsViewMode = mode; renderDashboard(); },
  });

  const quickLinks = document.querySelector('.quick-links-grid');
  if (quickLinks && !document.getElementById('dashQuickLinksViewToolbar')) {
    quickLinks.insertAdjacentHTML('beforebegin', AcademyView.toolbarMarkup(
      'dashboard_quick_links',
      dashQuickLinksViewMode,
      'Quick links view',
      'dashQuickLinksRecordCount',
      `${quickLinks.querySelectorAll('.quick-link-card').length} links`
    ));
    const toolbar = document.querySelector('[data-view-toolbar="dashboard_quick_links"]');
    if (toolbar) toolbar.id = 'dashQuickLinksViewToolbar';
    AcademyView.bind(toolbar, 'dashboard_quick_links', mode => {
      dashQuickLinksViewMode = mode;
      renderQuickLinksView();
    });
  }
  renderQuickLinksView();
}

function setupDashboardViewToolbar({ page, toolbarId, countId, label, mode, tbodyId, cardsId, onChange }) {
  const tbody = document.getElementById(tbodyId);
  const tableContainer = tbody?.closest('.table-container');
  if (!tableContainer) return;
  if (!document.getElementById(toolbarId)) {
    tableContainer.insertAdjacentHTML('beforebegin', AcademyView.toolbarMarkup(page, mode, label, countId, '0 records'));
    const toolbar = document.querySelector(`[data-view-toolbar="${page}"]`);
    if (toolbar) toolbar.id = toolbarId;
    AcademyView.bind(toolbar, page, onChange);
  }
  if (!document.getElementById(cardsId)) {
    tableContainer.insertAdjacentHTML('afterend', `<div id="${cardsId}" class="dashboard-card-grid" style="display:none"></div>`);
  }
}

function setDashboardView({ mode, tbodyId, cardsId }) {
  const tbody = document.getElementById(tbodyId);
  const tableContainer = tbody?.closest('.table-container');
  const cards = document.getElementById(cardsId);
  if (tableContainer) tableContainer.style.display = mode === 'grid' ? 'none' : '';
  if (cards) cards.style.display = mode === 'grid' ? 'grid' : 'none';
}

function renderQuickLinksView() {
  const quickLinks = document.querySelector('.quick-links-grid');
  if (!quickLinks) return;
  quickLinks.classList.toggle('is-list-view', dashQuickLinksViewMode === 'list');
  const count = document.getElementById('dashQuickLinksRecordCount');
  if (count) count.textContent = `${quickLinks.querySelectorAll('.quick-link-card').length} links`;
}

function renderDashboard() {
  const dashFilters = getDashboardFilters();
  const students = DB.filterStudents({ status:dashFilters.status, gender:dashFilters.gender });
  const teachers = DB.getTeachers();
  const courses  = DB.getCourses();
  const month    = new Date().toISOString().slice(0,7);

  // Student stats by course status
  const pending   = students.filter(s=>s.courseStatus==='Pending').length;
  const cont      = students.filter(s=>s.courseStatus==='Continue').length;
  const complete  = students.filter(s=>s.courseStatus==='Complete').length;
  const leave     = students.filter(s=>s.courseStatus==='Leave').length;
  const left      = students.filter(s=>s.courseStatus==='Left').length;
  const total     = students.length;

  // Fee stats
  let totalFees=0, paidFees=0;
  students.forEach(s=>{
    totalFees += s.totalFees||0;
    paidFees  += DB.paidFees(s.id);
  });
  const pendingFees = totalFees - paidFees;

  setEl('statTotalStudents', total);
  setEl('statTotalTeachers', teachers.length);
  setEl('statTotalCourses',  courses.length);
  setEl('statPending',       pending);
  setEl('statContinue',      cont);
  setEl('statComplete',      complete);
  setEl('statLeave',         leave);
  setEl('statLeft',          left);
  setEl('statTotalFees',     Fmt.currency(totalFees));
  setEl('statPaidFees',      Fmt.currency(paidFees));
  setEl('statPendingFees',   Fmt.currency(pendingFees));
  setEl('statRevenue',       Fmt.currency(paidFees));

  // Attendance for current month
  let totalP=0,totalA=0,totalL=0;
  students.forEach(s=>{
    const sum = DB.attendanceSummary(s.id, month);
    totalP += sum.present; totalA += sum.absent; totalL += sum.leave;
  });
  setEl('statAttPresent', totalP);
  setEl('statAttAbsent',  totalA);
  setEl('statAttLeave',   totalL);

  // Charts
  renderCourseStatusChart(pending,cont,complete,leave,left);
  renderFeesChart(paidFees, pendingFees);
  renderCourseDistChart(students, courses);
  renderMonthlyChart();
  renderFullAnalysisDashboard(students, dashFilters);

  // Recent students table
  renderRecentStudents(students);
}

function setEl(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

function renderCourseStatusChart(p,c,cp,l,lt) {
  const ctx = document.getElementById('courseStatusChart');
  if (!ctx || !window.Chart) return;
  if (ctx._chart) ctx._chart.destroy();
  ctx._chart = new Chart(ctx, ChartDefaults.doughnutOptions(
    ['Pending','Continue','Complete','Leave','Left'],
    [p,c,cp,l,lt]
  ));
}

function renderFeesChart(paid, pending) {
  const ctx = document.getElementById('feesChart');
  if (!ctx || !window.Chart) return;
  if (ctx._chart) ctx._chart.destroy();
  ctx._chart = new Chart(ctx, ChartDefaults.doughnutOptions(['Paid','Pending'],[paid,pending]));
}

function renderCourseDistChart(students, courses) {
  const ctx = document.getElementById('courseDistChart');
  if (!ctx || !window.Chart) return;
  if (ctx._chart) ctx._chart.destroy();
  const labels=[], data=[];
  courses.forEach(c=>{
    const count = students.filter(s=>s.courseId===c.id).length;
    if(count>0){ labels.push(c.name.split(' ').slice(0,2).join(' ')); data.push(count); }
  });
  ctx._chart = new Chart(ctx, ChartDefaults.barOptions(labels, [{ label:'Students', data }]));
}

function renderMonthlyChart() {
  const ctx = document.getElementById('monthlyChart');
  if (!ctx || !window.Chart) return;
  if (ctx._chart) ctx._chart.destroy();
  const months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  // Aggregate fees paid per month
  const data = Array(12).fill(0);
  const allFees = DB.getFeesAll();
  Object.values(allFees).forEach(sf=>{
    (sf.payments||[]).forEach(p=>{
      const d = new Date(p.date||'');
      if(!isNaN(d)) data[d.getMonth()] += Number(p.amount)||0;
    });
  });
  ctx._chart = new Chart(ctx, ChartDefaults.lineOptions('Monthly Revenue', months, data));
}

function getDashboardFilters() {
  return {
    period: document.getElementById('dashPeriodFilter')?.value || 'month',
    status: document.getElementById('dashStatusFilter')?.value || 'All',
    gender: document.getElementById('dashGenderFilter')?.value || 'All',
  };
}

function bindDashboardFilters() {
  populateCourseStatusSelect('dashStatusFilter', 'All', true);
  ['dashPeriodFilter','dashStatusFilter','dashGenderFilter'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('change', () => {
      renderDashboard();
      renderAcademyProgress();
    });
  });
}

function getPeriodRange(period) {
  const now = new Date();
  const start = new Date(now);
  if (period === 'day') start.setHours(0,0,0,0);
  else if (period === 'week') {
    start.setDate(now.getDate() - 6);
    start.setHours(0,0,0,0);
  } else if (period === 'year') {
    start.setMonth(0,1);
    start.setHours(0,0,0,0);
  } else {
    start.setDate(1);
    start.setHours(0,0,0,0);
  }
  const end = new Date(now);
  end.setHours(23,59,59,999);
  return { start, end };
}

function dateInRange(dateValue, range) {
  if (!dateValue) return false;
  const d = new Date(dateValue);
  if (isNaN(d)) return false;
  return d >= range.start && d <= range.end;
}

function renderFullAnalysisDashboard(students, filters) {
  const range = getPeriodRange(filters.period);
  const studentIds = new Set(students.map(s => s.id));
  const admissions = students.filter(s => dateInRange(s.admissionDate, range));
  let periodPaid = 0;
  let paymentCount = 0;
  const paymentEntries = [];
  const allFees = DB.getFeesAll();
  Object.entries(allFees).forEach(([studentId, record]) => {
    if (!studentIds.has(studentId)) return;
    const student = DB.getStudent(studentId);
    ((record && record.payments) || []).forEach(p => {
      if (dateInRange(p.date, range)) {
        periodPaid += Number(p.amount) || 0;
        paymentCount++;
        paymentEntries.push({ type:'Payment', date:p.date, student:student?.name || studentId, amount:p.amount || 0, detail:p.mode || 'Cash' });
      }
    });
  });

  let attendanceMarks = 0, presentMarks = 0;
  Object.entries(DB.getAttendanceAll()).forEach(([month, people]) => {
    Object.entries(people || {}).forEach(([personId, days]) => {
      if (!studentIds.has(personId)) return;
      Object.entries(days || {}).forEach(([day, status]) => {
        const dateValue = `${month}-${String(day).padStart(2, '0')}`;
        if (status && dateInRange(dateValue, range)) {
          attendanceMarks++;
          if (status === 'P') presentMarks++;
        }
      });
    });
  });

  const totalPending = students.reduce((sum, s) => sum + Math.max(0, DB.pendingFees(s.id)), 0);
  const boys = students.filter(s => DB.personMatchesGender(s, 'Male')).length;
  const girls = students.filter(s => DB.personMatchesGender(s, 'Female')).length;

  setEl('dashNewStudents', admissions.length);
  setEl('dashPeriodPayments', Fmt.currency(periodPaid));
  setEl('dashPaymentEntries', paymentCount);
  setEl('dashAttendanceEntries', attendanceMarks);
  setEl('dashPresenceRate', attendanceMarks ? Math.round((presentMarks / attendanceMarks) * 100) + '%' : '0%');
  setEl('dashFilteredPending', Fmt.currency(totalPending));
  setEl('dashBoys', boys);
  setEl('dashGirls', girls);

  renderAnalysisPeriodChart(students, filters);
  renderGenderChart(boys, girls, Math.max(0, students.length - boys - girls));
  renderCourseAnalysisTable(students);
  renderRecentEntries(admissions, paymentEntries);
}

function renderAnalysisPeriodChart(students, filters) {
  const ctx = document.getElementById('analysisPeriodChart');
  if (!ctx || !window.Chart) return;
  if (ctx._chart) ctx._chart.destroy();
  const now = new Date();
  let labels = [];
  let keys = [];
  if (filters.period === 'year') {
    labels = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    keys = labels.map((_, i) => `${now.getFullYear()}-${String(i + 1).padStart(2,'0')}`);
  } else {
    const count = filters.period === 'day' ? 1 : (filters.period === 'week' ? 7 : new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate());
    const start = filters.period === 'month'
      ? new Date(now.getFullYear(), now.getMonth(), 1)
      : new Date(now.getFullYear(), now.getMonth(), now.getDate() - count + 1);
    labels = Array.from({ length:count }, (_, i) => {
      const d = new Date(start); d.setDate(start.getDate() + i);
      return d.toLocaleDateString('en-IN', { day:'2-digit', month:'short' });
    });
    keys = Array.from({ length:count }, (_, i) => {
      const d = new Date(start); d.setDate(start.getDate() + i);
      return d.toISOString().slice(0,10);
    });
  }
  const studentIds = new Set(students.map(s => s.id));
  const data = keys.map(() => 0);
  Object.entries(DB.getFeesAll()).forEach(([studentId, record]) => {
    if (!studentIds.has(studentId)) return;
    ((record && record.payments) || []).forEach(p => {
      const key = filters.period === 'year' ? String(p.date || '').slice(0,7) : String(p.date || '').slice(0,10);
      const idx = keys.indexOf(key);
      if (idx >= 0) data[idx] += Number(p.amount) || 0;
    });
  });
  ctx._chart = new Chart(ctx, ChartDefaults.lineOptions('Revenue', labels, data, '#5eead4'));
}

function renderGenderChart(boys, girls, other) {
  const ctx = document.getElementById('genderChart');
  if (!ctx || !window.Chart) return;
  if (ctx._chart) ctx._chart.destroy();
  ctx._chart = new Chart(ctx, ChartDefaults.doughnutOptions(['Boys','Girls','Other'], [boys, girls, other]));
}

function renderCourseAnalysisTable(students) {
  const tbody = document.getElementById('courseAnalysisTbody');
  if (!tbody) return;
  const courses = DB.getCourses();
  const rows = courses.map(c => {
    const list = students.filter(s => s.courseId === c.id || s.course === c.name);
    if (!list.length) return null;
    const paid = list.reduce((sum, s) => sum + DB.paidFees(s.id), 0);
    const pending = list.reduce((sum, s) => sum + Math.max(0, DB.pendingFees(s.id)), 0);
    const boys = list.filter(s => DB.personMatchesGender(s, 'Male')).length;
    const girls = list.filter(s => DB.personMatchesGender(s, 'Female')).length;
    return { name:c.name, total:list.length, boys, girls, paid, pending };
  }).filter(Boolean);
  const count = document.getElementById('dashCourseRecordCount');
  if (count) count.textContent = `${rows.length} course${rows.length === 1 ? '' : 's'}`;
  setDashboardView({ mode:dashCourseViewMode, tbodyId:'courseAnalysisTbody', cardsId:'courseAnalysisCards' });
  tbody.innerHTML = rows.length
    ? rows.map(r => `<tr><td>${Fmt.escape(r.name)}</td><td>${r.total}</td><td>${r.boys}</td><td>${r.girls}</td><td>${Fmt.currency(r.paid)}</td><td>${Fmt.currency(r.pending)}</td></tr>`).join('')
    : '<tr><td colspan="6" class="text-center text-muted" style="padding:24px">No course analysis for current filters</td></tr>';
  const cards = document.getElementById('courseAnalysisCards');
  if (cards) cards.innerHTML = rows.length ? rows.map(r => {
    const totalFees = r.paid + r.pending;
    const paidPct = totalFees ? Math.round((r.paid / totalFees) * 100) : 0;
    return `<article class="dashboard-info-card">
      <div class="person-card-top">
        <div><div class="person-title">${Fmt.escape(r.name)}</div><div class="card-meta-line"><span>${r.total} students</span><span>${r.boys} boys / ${r.girls} girls</span></div></div>
        <span class="badge badge-primary">${paidPct}% paid</span>
      </div>
      <div class="detail-row"><span>Paid</span><strong>${Fmt.currency(r.paid)}</strong></div>
      <div class="detail-row"><span>Pending</span><strong>${Fmt.currency(r.pending)}</strong></div>
      <div class="progress-mini"><span style="width:${paidPct}%"></span></div>
    </article>`;
  }).join('') : '<div class="empty-state"><p>No course analysis for current filters</p></div>';
}

function renderRecentEntries(admissions, payments) {
  const tbody = document.getElementById('recentEntriesTbody');
  if (!tbody) return;
  const entries = [
    ...admissions.map(s => ({ type:'Admission', date:s.admissionDate, student:s.name, amount:'', detail:s.course || '' })),
    ...payments,
  ].sort((a,b) => new Date(b.date || 0) - new Date(a.date || 0)).slice(0, 10);
  const count = document.getElementById('dashEntriesRecordCount');
  if (count) count.textContent = `${entries.length} entr${entries.length === 1 ? 'y' : 'ies'}`;
  setDashboardView({ mode:dashEntriesViewMode, tbodyId:'recentEntriesTbody', cardsId:'recentEntriesCards' });
  tbody.innerHTML = entries.length ? entries.map(e => `<tr>
    <td style="white-space:nowrap"><span class="badge ${e.type === 'Payment' ? 'badge-success' : 'badge-primary'}">${e.type}</span></td>
    <td style="white-space:nowrap">${Fmt.date(e.date)}</td>
    <td style="white-space:nowrap;min-width:120px">${e.student}</td>
    <td style="white-space:nowrap">${e.amount ? Fmt.currency(e.amount) : '-'}</td>
    <td style="white-space:nowrap;max-width:160px;overflow:hidden;text-overflow:ellipsis">${e.detail || '-'}</td>
  </tr>`).join('') : '<tr><td colspan="5" class="text-center text-muted" style="padding:24px">No entries in selected period</td></tr>';
  const cards = document.getElementById('recentEntriesCards');
  if (cards) cards.innerHTML = entries.length ? entries.map(e => `<article class="dashboard-info-card">
    <div class="person-card-top">
      <div><div class="person-title">${Fmt.escape(e.student || '-')}</div><div class="card-meta-line"><span>${Fmt.date(e.date)}</span><span>${Fmt.escape(e.detail || '-')}</span></div></div>
      <span class="badge ${e.type === 'Payment' ? 'badge-success' : 'badge-primary'}">${Fmt.escape(e.type)}</span>
    </div>
    <div class="detail-row"><span>Amount</span><strong>${e.amount ? Fmt.currency(e.amount) : '-'}</strong></div>
  </article>`).join('') : '<div class="empty-state"><p>No entries in selected period</p></div>';
}

function renderRecentStudents(students) {
  const tbody = document.getElementById('recentStudentsTbody');
  if (!tbody) return;
  const recent = [...students].slice(0,8);
  const count = document.getElementById('dashStudentsRecordCount');
  if (count) count.textContent = `${recent.length} student${recent.length === 1 ? '' : 's'}`;
  setDashboardView({ mode:dashStudentsViewMode, tbodyId:'recentStudentsTbody', cardsId:'recentStudentsCards' });
  tbody.innerHTML = recent.length ? recent.map(s=>{
    const paid = DB.paidFees(s.id);
    const pending = (s.totalFees||0)-paid;
    const statusBadge = {
      'Continue':'badge-primary','Complete':'badge-success',
      'Pending':'badge-warning','Leave':'badge-warning','Left':'badge-danger'
    }[s.courseStatus]||'badge-info';
    return `<tr>
      <td style="min-width:150px"><div style="display:flex;align-items:center;gap:10px">
        ${ProfileImage.avatar(s, '', 'width:32px;height:32px;font-size:0.75rem;flex-shrink:0')}
        <div><div style="font-weight:600;font-size:0.88rem;white-space:nowrap">${s.name}</div>
        <div style="font-size:0.72rem;color:var(--text-muted);white-space:nowrap">${s.course||'—'}</div></div></div></td>
      <td><span class="badge ${statusBadge}">${s.courseStatus||'—'}</span></td>
      <td style="font-size:0.82rem;white-space:nowrap">${s.batchNo||'—'}</td>
      <td style="color:var(--success);font-size:0.85rem;font-weight:600;white-space:nowrap">${Fmt.currency(paid)}</td>
      <td style="color:${pending>0?'var(--danger)':'var(--success)'};font-size:0.85rem;font-weight:600;white-space:nowrap">${Fmt.currency(pending)}</td>
      <td style="white-space:nowrap"><a href="students.html?id=${s.id}" class="btn btn-sm btn-ghost">View</a></td>
    </tr>`;
  }).join('') : '<tr><td colspan="6" class="text-center text-muted" style="padding:30px">No students yet</td></tr>';
  const cards = document.getElementById('recentStudentsCards');
  if (cards) cards.innerHTML = recent.length ? recent.map(s => {
    const paid = DB.paidFees(s.id);
    const pending = (s.totalFees || 0) - paid;
    const statusBadge = {
      Continue:'badge-primary', Complete:'badge-success',
      Pending:'badge-warning', Leave:'badge-warning', Left:'badge-danger',
    }[s.courseStatus] || 'badge-info';
    return `<article class="dashboard-info-card">
      <div class="person-card-top">
        <div style="display:flex;gap:10px;align-items:center;min-width:0">
          ${ProfileImage.avatar(s, '', 'width:42px;height:42px;font-size:0.82rem;flex-shrink:0')}
          <div style="min-width:0"><div class="person-title">${Fmt.escape(s.name)}</div><div class="card-meta-line"><span>${Fmt.escape(s.course || '-')}</span><span>${Fmt.escape(s.batchNo || '-')}</span></div></div>
        </div>
        <span class="badge ${statusBadge}">${Fmt.escape(s.courseStatus || '-')}</span>
      </div>
      <div class="detail-row"><span>Paid</span><strong>${Fmt.currency(paid)}</strong></div>
      <div class="detail-row"><span>Balance</span><strong>${Fmt.currency(pending)}</strong></div>
      <div class="card-actions"><a href="students.html?id=${s.id}" class="btn btn-sm btn-secondary">View</a></div>
    </article>`;
  }).join('') : '<div class="empty-state"><p>No students yet</p></div>';
}

// Academy progress bars
function renderAcademyProgress() {
  const filters = getDashboardFilters();
  const students = DB.filterStudents({ status:filters.status, gender:filters.gender });
  const total = students.length || 1;
  function pct(count) { return Math.round((count/total)*100); }
  const complete = students.filter(s=>s.courseStatus==='Complete').length;
  const cont     = students.filter(s=>s.courseStatus==='Continue').length;
  const el = id => document.getElementById(id);
  const setBar = (barId, pctId, val) => {
    const bar=el(barId), pctEl=el(pctId);
    if(bar) bar.style.width = val+'%';
    if(pctEl) pctEl.textContent = val+'%';
  };
  setBar('progressComplete','pctComplete', pct(complete));
  setBar('progressContinue','pctContinue', pct(cont));
  setBar('progressFees','pctFees', (() => {
    let t=0,p=0; students.forEach(s=>{t+=s.totalFees||0;p+=DB.paidFees(s.id);}); return t?Math.round((p/t)*100):0;
  })());
}

document.addEventListener('DOMContentLoaded', () => {
  const session = Auth.requireAuth(['admin','teacher']);
  if (!session) return;
  initDashboardViewControls();
  bindDashboardFilters();
  renderDashboard();
  renderAcademyProgress();
  // Auto-refresh every 30 seconds
  setInterval(()=>{ renderDashboard(); renderAcademyProgress(); }, 30000);
});

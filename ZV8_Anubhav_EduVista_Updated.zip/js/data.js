/* ==========================================================================
   DATA.JS — LocalStorage Data Layer
   Computer Care (Anubhav EduVista) Academy Management System
   ========================================================================== */

const DB = {
  /* ---------- KEYS ---------- */
  KEYS: {
    students:      'cc_students',
    teachers:      'cc_teachers',
    fees:          'cc_fees',
    attendance:    'cc_attendance',
    timetable:     'cc_timetable',
    topics:        'cc_topics',
    gallery:       'cc_gallery',
    courses:       'cc_courses',
    settings:      'cc_settings',
    users:         'cc_users',
    session:       'cc_session',
    tasks:         'cc_tasks',
    salary:        'cc_salary',
    resumes:       'cc_resumes',
    notifications: 'cc_notifications',
    blog:          'cc_blog',
    notepads:      'cc_notepads',
    teacherNotes:  'cc_teacher_notes',
    internships:   'cc_internships',
    inquiries:      'cc_inquiries',
    syllabusTopics:'cc_syllabus_topics',
    syllabusReviews:'cc_syllabus_reviews',
    syllabusSeed:   'cc_syllabus_seed_version',
    receiptCounter:'cc_receipt_counter',
    updatedAt:     'cc_updated_at',
  },

  COURSE_STATUSES: [
    { value:'All', label:'All Course Students List' },
    { value:'Pending', label:'Pending Course Students List' },
    { value:'Leave', label:'Leave Course Students List' },
    { value:'Continue', label:'Continuing Course Students List' },
    { value:'Left', label:'Left Course Students List' },
    { value:'Complete', label:'Completed Course Students List' },
  ],

  DEFAULT_NOTIFICATIONS: [
    { id:'n1', title:'Republic Day Holiday', message:'Academy will remain closed on 26th January 2024 for Republic Day. Classes resume on 29th January. Happy Republic Day!', type:'Holiday', target:'all', date:'2024-01-26', createdBy:'admin', createdAt:'2024-01-20T10:00:00', priority:'High', icon:'🏖️' },
    { id:'n2', title:'Diwali Vacation', message:'Academy will be closed from 1st Nov to 5th Nov 2024 for Diwali celebrations. Wishing everyone a Happy Diwali!', type:'Holiday', target:'all', date:'2024-11-01', createdBy:'admin', createdAt:'2024-10-25T10:00:00', priority:'High', icon:'🪔' },
    { id:'n3', title:'Monthly Test Scheduled', message:'Monthly computer skills test will be held on 15th of every month. All students must be present. 10 marks will be awarded.', type:'Announcement', target:'students', date:'2024-02-15', createdBy:'admin', createdAt:'2024-02-10T09:00:00', priority:'Medium', icon:'📝' },
    { id:'n4', title:'Staff Meeting', message:'All teaching staff are requested to attend the monthly staff meeting this Saturday at 11:00 AM. Attendance is mandatory.', type:'Meeting', target:'teachers', date:'2024-02-10', createdBy:'admin', createdAt:'2024-02-08T10:00:00', priority:'High', icon:'👔' },
    { id:'n5', title:'Fee Reminder', message:'Last date for February fee submission is 10th February. Students with pending fees are requested to clear dues immediately.', type:'Fee', target:'students', date:'2024-02-10', createdBy:'admin', createdAt:'2024-02-05T08:00:00', priority:'High', icon:'💰' },
  ],

  DEFAULT_BLOG: [
    { id:'bl1', title:'Welcome to Computer Care (Anubhav EduVista)', slug:'welcome-computer-care', excerpt:'Join Punjab\'s leading computer education academy and build a career in technology. We offer 12+ professional courses designed for the modern world.', content:'Computer Care (Anubhav EduVista) is a premier computer education institute located in Kapurthala, Punjab. We are dedicated to providing quality computer education that empowers students with practical skills for today\'s digital world.\n\nOur academy offers over 12 professional courses ranging from Basic Computer to Advanced Programming, Graphic Designing, Web Development, Digital Marketing, and much more. Each course is designed by industry experts to ensure students get real-world skills.\n\nOur state-of-the-art computer lab is equipped with modern PCs and licensed software. Our experienced faculty members provide personalized attention to every student.\n\nWhether you are a student looking to boost your career, a homemaker wanting to learn computer basics, or a professional seeking to upgrade your skills — Computer Care is the right place for you!', category:'About Us', author:'Anubhav', authorRole:'Principal', publishedAt:'2024-01-01', image:'', tags:['welcome','about','computer education'], featured:true, views:245 },
    { id:'bl2', title:'Top 5 Computer Courses for Career Growth in 2024', slug:'top-computer-courses-2024', excerpt:'Discover which computer courses are most in-demand for job seekers and entrepreneurs in 2024. From coding to graphic design, we cover it all.', content:'The technology industry is growing at an unprecedented rate and the demand for computer-skilled professionals has never been higher. Here are the top 5 computer courses that can transform your career in 2024:\n\n1. **Web Designing & Development** — Every business needs a website. Learning HTML, CSS, JavaScript and PHP opens doors to freelancing and employment.\n\n2. **Graphic Designing** — Canva, Photoshop and CorelDraw skills are highly sought after by businesses for their marketing needs.\n\n3. **Digital Marketing** — SEO, Social Media Marketing and Google Ads are essential skills for modern businesses.\n\n4. **Programming Languages** — Python, Java and C++ knowledge makes you eligible for software development roles.\n\n5. **Tally with GST** — Essential for accounting professionals in every business across India.\n\nAt Computer Care, we offer all these courses with practical training and placement assistance. Contact us today to enroll!', category:'Career Tips', author:'Anubhav', authorRole:'Principal', publishedAt:'2024-01-15', image:'', tags:['courses','career','2024'], featured:true, views:180 },
    { id:'bl3', title:'How Our Students Are Succeeding in the Digital World', slug:'student-success-stories', excerpt:'Read inspiring stories of Computer Care students who turned their computer education into successful careers and businesses.', content:'We are proud of our students who have gone on to achieve great things after completing their courses at Computer Care.\n\nMany of our Graphic Designing graduates are now running successful freelancing businesses on platforms like Fiverr and Upwork, earning lakhs annually. Our Web Designing students have built websites for local businesses across Punjab.\n\nSeveral students who completed our Programming courses have secured jobs in reputed IT companies in Chandigarh, Amritsar, and even Bangalore.\n\nOur Digital Marketing graduates are helping local businesses grow their online presence and generate more revenue.\n\nThese success stories inspire us every day to continue providing quality education. Your success is our success! Come join our family and write your own success story.', category:'Success Stories', author:'Anubhav', authorRole:'Principal', publishedAt:'2024-02-01', image:'', tags:['students','success','career'], featured:false, views:132 },
    { id:'bl4', title:'Importance of Computer Education for Rural Youth', slug:'computer-education-rural-youth', excerpt:'Computer literacy is transforming the lives of youth in rural Punjab. Here\'s why every young person should learn computer skills today.', content:'In today\'s digital India, computer literacy is no longer a luxury — it is a necessity. Youth in rural areas often lack access to quality computer education, which puts them at a disadvantage in the job market.\n\nAt Computer Care, located conveniently in Kapurthala, we bridge this gap by providing affordable, high-quality computer education to students from all backgrounds.\n\nWith government initiatives like Digital India and increasing internet penetration in villages, rural youth who learn computer skills can access remote work opportunities, start their own online businesses, and compete with urban counterparts.\n\nWe offer special fee concessions for students from economically weaker sections. Our EMI-friendly fee structure makes quality education accessible to everyone.\n\nDon\'t let your location limit your dreams. Computer Care is here to help you take the leap into the digital world!', category:'Education', author:'Anubhav', authorRole:'Principal', publishedAt:'2024-02-10', image:'', tags:['rural','education','digital india'], featured:false, views:98 },
    { id:'bl5', title:'Computer Care Academy Celebrates 5th Anniversary', slug:'5th-anniversary-celebration', excerpt:'Computer Care (Anubhav EduVista) celebrates 5 glorious years of computer education in Kapurthala with grand celebrations and student felicitation.', content:'We are thrilled to announce that Computer Care (Anubhav EduVista) has completed 5 wonderful years of serving the educational needs of students in Kapurthala and surrounding areas.\n\nDuring these 5 years, we have:\n✅ Trained over 500+ students\n✅ Achieved 95% placement rate\n✅ Launched 12+ professional courses\n✅ Built state-of-the-art computer lab\n✅ Received Best Computer Institute Award from District Education Board\n\nThe anniversary was celebrated with a grand function where top-performing students were felicitated with certificates, medals, and cash prizes.\n\nWe thank all our students, parents, teachers, and well-wishers for their continued trust and support. Here\'s to many more years of excellence in education!\n\nContact us: +91 78371-96514 | Anubhav.EduVista@gmail.com', category:'Events', author:'Anubhav', authorRole:'Principal', publishedAt:'2024-03-01', image:'', tags:['anniversary','celebration','achievement'], featured:true, views:312 },
  ],

  /* ---------- COURSES ---------- */
  DEFAULT_COURSES: [
    { id:'c1', name:'Basic Computer Course',  subcategories:['Computer Fundamentals','Typing','Microsoft Word','Microsoft Excel','Microsoft PowerPoint'], duration:'3 Months', fees:3000 },
    { id:'c2', name:'Graphic Designing',      subcategories:['Canva','CorelDraw','Photoshop'], duration:'4 Months', fees:5000 },
    { id:'c3', name:'Web Designing',          subcategories:['HTML','CSS','JavaScript','PHP','MySQL'], duration:'6 Months', fees:8000 },
    { id:'c4', name:'Programming Languages',  subcategories:['C','C++','Python','Java','Ruby','Dart'], duration:'6 Months', fees:10000 },
    { id:'c5', name:'Tally Course',           subcategories:['Tally Prime','GST','Accounting'], duration:'2 Months', fees:4000 },
    { id:'c6', name:'Digital Marketing',      subcategories:['SEO','Social Media','Google Ads','Content Writing'], duration:'3 Months', fees:6000 },
    { id:'c7', name:'Freelancing',            subcategories:['Fiverr','Upwork','Portfolio Building'], duration:'2 Months', fees:3500 },
    { id:'c8', name:'Hardware & Software',    subcategories:['PC Assembly','OS Installation','Troubleshooting'], duration:'3 Months', fees:5000 },
    { id:'c9', name:'Internship',             subcategories:['Project Work','Industry Training'], duration:'2 Months', fees:2000 },
    { id:'c10', name:'MS Job Oriented',       subcategories:['MS Office Suite','Email Management'], duration:'2 Months', fees:3000 },
    { id:'c11', name:'Spoken English',        subcategories:['Grammar','Conversation','Pronunciation'], duration:'3 Months', fees:4000 },
    { id:'c12', name:'Tuition Classes',       subcategories:['Maths','Science','English'], duration:'Ongoing', fees:1500 },
  ],

  /* ---------- DEFAULT TEACHERS ---------- */
  DEFAULT_TEACHERS: [
    { id:'t1', name:'Manjinder Singh',  qualification:'MCA', mobile:'9876543210', email:'manjinder@computercare.in', gender:'Male',   joinDate:'2023-01-01', subject:'Programming', dob:'1990-05-15', address:'Kapurthala', role:'teacher', active:true, username:'manjinder', password:'teacher123', profileImage:'', attendance:{}, performance:'Excellent', salary:15000 },
    { id:'t2', name:'Vishu Sharma',     qualification:'BCA', mobile:'9876543211', email:'vishu@computercare.in',     gender:'Female', joinDate:'2023-02-01', subject:'Graphics',     dob:'1992-08-20', address:'Kapurthala', role:'teacher', active:true, username:'vishu',     password:'teacher123', profileImage:'', attendance:{}, performance:'Good', salary:12000 },
    { id:'t3', name:'Anmol Kaur',       qualification:'B.Tech', mobile:'9876543212', email:'anmol@computercare.in', gender:'Female', joinDate:'2023-03-01', subject:'Web Design',  dob:'1993-12-10', address:'Kapurthala', role:'teacher', active:true, username:'anmol',     password:'teacher123', profileImage:'', attendance:{}, performance:'Excellent', salary:13000 },
    { id:'t4', name:'Harpreet Kaur',    qualification:'MSc IT', mobile:'9876543213', email:'harpreet@computercare.in', gender:'Female', joinDate:'2023-04-01', subject:'Digital Mkt',dob:'1991-03-25', address:'Kapurthala', role:'teacher', active:true, username:'harpreet', password:'teacher123', profileImage:'', attendance:{}, performance:'Good', salary:12500 },
  ],

  /* ---------- DEFAULT STUDENTS ---------- */
  DEFAULT_STUDENTS: [
    {
      id:'s1', name:'Rahul Kumar', fatherName:'Suresh Kumar', motherName:'Priya Kumar',
      gender:'Male', dob:'2003-06-14', mobile:'8765432100', altMobile:'', email:'rahul@email.com',
      aadhaar:'1234 5678 9012', qualification:'12th', religion:'Hindu', caste:'General',
      maritalStatus:'Single', familyMembers:4, annualIncome:'200000',
      fatherOccupation:'Farmer', motherOccupation:'Housewife',
      address:'123 Main Street', landmark:'Near Temple', village:'Kapurthala',
      district:'Kapurthala', pincode:'144601', state:'Punjab',
      course:'Basic Computer Course', courseId:'c1', subcategories:['Computer Fundamentals','Typing'],
      batchNo:'Batch 1', pcNo:'PC 1', timings:'9:00 AM - 10:00 AM', day:'Mon-Fri',
      totalFees:3000, monthlyFees:1000, duration:'3 Months',
      admissionDate:'2024-01-10', startDate:'2024-01-10',
      reference:'Walk-in', grade:'', percentage:0, rank:0,
      username:'rahul123', password:'student123',
      active:true, courseStatus:'Continue', profileImage:'',
      attendance:{}, marks:{}, topics:[], feedback:'', experience:0,
      occupation:'Student', resignNo:'', signature:'',
    },
    {
      id:'s2', name:'Priya Sharma', fatherName:'Rajesh Sharma', motherName:'Sunita Sharma',
      gender:'Female', dob:'2004-03-22', mobile:'8765432101', altMobile:'', email:'priya@email.com',
      aadhaar:'2345 6789 0123', qualification:'Graduation', religion:'Hindu', caste:'OBC',
      maritalStatus:'Single', familyMembers:5, annualIncome:'150000',
      fatherOccupation:'Shopkeeper', motherOccupation:'Teacher',
      address:'456 Market Road', landmark:'Near School', village:'Kapurthala',
      district:'Kapurthala', pincode:'144601', state:'Punjab',
      course:'Graphic Designing', courseId:'c2', subcategories:['Canva','Photoshop'],
      batchNo:'Batch 2', pcNo:'PC 3', timings:'10:00 AM - 11:00 AM', day:'Mon-Fri',
      totalFees:5000, monthlyFees:1500, duration:'4 Months',
      admissionDate:'2024-01-15', startDate:'2024-01-15',
      reference:'Friend', grade:'A', percentage:85, rank:1,
      username:'priya123', password:'student123',
      active:true, courseStatus:'Complete', profileImage:'',
      attendance:{}, marks:{}, topics:[], feedback:'Excellent student', experience:0,
      occupation:'Student', resignNo:'', signature:'',
    },
    {
      id:'s3', name:'Amit Singh', fatherName:'Gurpreet Singh', motherName:'Manpreet Kaur',
      gender:'Male', dob:'2002-11-05', mobile:'8765432102', altMobile:'', email:'amit@email.com',
      aadhaar:'3456 7890 1234', qualification:'10th', religion:'Sikh', caste:'General',
      maritalStatus:'Single', familyMembers:3, annualIncome:'300000',
      fatherOccupation:'Government Job', motherOccupation:'Housewife',
      address:'789 Civil Lines', landmark:'Near Bank', village:'Kapurthala',
      district:'Kapurthala', pincode:'144601', state:'Punjab',
      course:'Web Designing', courseId:'c3', subcategories:['HTML','CSS','JavaScript'],
      batchNo:'Batch 1', pcNo:'PC 5', timings:'11:00 AM - 12:00 PM', day:'Mon-Fri',
      totalFees:8000, monthlyFees:1500, duration:'6 Months',
      admissionDate:'2024-02-01', startDate:'2024-02-01',
      reference:'Online', grade:'B', percentage:72, rank:2,
      username:'amit123', password:'student123',
      active:true, courseStatus:'Continue', profileImage:'',
      attendance:{}, marks:{}, topics:[], feedback:'Good progress', experience:0,
      occupation:'Student', resignNo:'', signature:'',
    },
  ],

  /* ---------- DEFAULT SETTINGS ---------- */
  DEFAULT_SETTINGS: {
    academyName: 'Computer Care (Anubhav EduVista)',
    address: 'Near Landon Hotel, Behind Jain Petrol Pump, Kapurthala, Punjab',
    mobile: '+91 78371-96514',
    email: 'Anubhav.EduVista@gmail.com',
    website: 'Computercareskpt.in',
    principalName: 'Anubhav',
    theme: 'dark',
    uiDesignMode: 'modern',
    uiSurfaceStyle: 'glass',
    uiDensity: 'comfortable',
    uiBottomNav: true,
    uiReduceMotion: false,
    uiWideTables: true,
    uiPalette: 'teal',
    uiBackgroundStyle: 'aurora',
    uiContrast: 'normal',
    uiFontFamily: 'inter',
    uiFontSize: 15,
    uiSidebarSize: 'normal',
    uiNavStyle: 'iconText',
    uiIconStyle: 'badge',
    uiCornerStyle: 'soft',
    uiShadowLevel: 2,
    uiBorderLevel: 1,
    uiOutlineLevel: 2,
    uiBrightness: 100,
    uiSaturation: 115,
    uiHighlightLevel: 2,
    uiPanelOpacity: 78,
    uiBlurLevel: 18,
    uiScrollStyle: 'color',
    autoSave: true,
    currency: '₹',
  },

  DEFAULT_INTERNSHIPS: [
    {
      id:'int1',
      studentId:'s1',
      studentName:'Rahul Kumar',
      batchNo:'Batch 1',
      program:'Web Development Internship',
      company:'Computer Care Lab',
      mentor:'Manjinder Singh',
      startDate:'2024-03-01',
      endDate:'2024-04-30',
      duration:'2 Months',
      hours:120,
      stipend:0,
      status:'Active',
      skills:['HTML','CSS','JavaScript'],
      projectTitle:'Academy Website Practice',
      projectUrl:'',
      certificateNo:'',
      evaluation:'Good',
      remarks:'Demo internship record. Edit or delete as needed.',
      createdAt:'2024-03-01T09:00:00',
      updatedAt:'2024-03-01T09:00:00',
    },
  ],

  DEFAULT_INQUIRIES: [
    {
      id:'inq1',
      name:'Simran Kaur',
      gender:'Female',
      mobile:'9876501001',
      altMobile:'',
      email:'simran@example.com',
      guardianName:'Gurmeet Singh',
      courseId:'c3',
      course:'Web Designing',
      batchNo:'Batch 1',
      preferredTime:'11:00 AM - 12:00 PM',
      preferredDays:'Mon-Fri',
      source:'Walk-in',
      status:'Open',
      priority:'High',
      inquiryDate:'2026-06-01',
      followUpDate:'2026-06-10',
      expectedJoinDate:'2026-06-15',
      quotedFees:8000,
      address:'Kapurthala',
      notes:'Interested in HTML, CSS, and JavaScript batch.',
      assignedTo:'admin',
      convertedStudentId:'',
      createdAt:'2026-06-01T10:00:00',
      updatedAt:'2026-06-01T10:00:00',
    },
    {
      id:'inq2',
      name:'Arjun Sharma',
      gender:'Male',
      mobile:'9876501002',
      altMobile:'',
      email:'arjun@example.com',
      guardianName:'Rakesh Sharma',
      courseId:'c5',
      course:'Tally Course',
      batchNo:'Batch 2',
      preferredTime:'10:00 AM - 11:00 AM',
      preferredDays:'Mon-Sat',
      source:'Friend',
      status:'Follow Up',
      priority:'Medium',
      inquiryDate:'2026-06-03',
      followUpDate:'2026-06-11',
      expectedJoinDate:'2026-06-20',
      quotedFees:4000,
      address:'Kapurthala',
      notes:'Asked for fee installment option.',
      assignedTo:'admin',
      convertedStudentId:'',
      createdAt:'2026-06-03T12:30:00',
      updatedAt:'2026-06-03T12:30:00',
    },
  ],

  /* ---------- READ ---------- */
  get(key) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : null;
    } catch(e) { return null; }
  },

  /* ---------- WRITE ---------- */
  set(key, val) {
    try {
      const next = JSON.stringify(val);
      const prev = localStorage.getItem(key);
      localStorage.setItem(key, next);
      if (prev !== next && key !== this.KEYS.session && key !== this.KEYS.updatedAt) {
        localStorage.setItem(this.KEYS.updatedAt, JSON.stringify(new Date().toISOString()));
        if (!this._suspendSync) this.queueServerSync();
      }
      return true;
    } catch(e) { return false; }
  },

  cloneDefault(value) {
    return JSON.parse(JSON.stringify(value));
  },

  defaultStorageSeed({ keepSettings=false } = {}) {
    const seed = {};
    seed[this.KEYS.students] = this.cloneDefault(this.DEFAULT_STUDENTS);
    seed[this.KEYS.teachers] = this.cloneDefault(this.DEFAULT_TEACHERS);
    seed[this.KEYS.fees] = {};
    seed[this.KEYS.attendance] = {};
    seed[this.KEYS.timetable] = this.DEFAULT_TIMETABLE();
    seed[this.KEYS.topics] = [];
    seed[this.KEYS.gallery] = [];
    seed[this.KEYS.courses] = this.cloneDefault(this.DEFAULT_COURSES);
    seed[this.KEYS.settings] = keepSettings ? { ...this.DEFAULT_SETTINGS, ...(this.getSettings() || {}) } : this.cloneDefault(this.DEFAULT_SETTINGS);
    seed[this.KEYS.tasks] = [];
    seed[this.KEYS.salary] = {};
    seed[this.KEYS.resumes] = {};
    seed[this.KEYS.notifications] = this.cloneDefault(this.DEFAULT_NOTIFICATIONS);
    seed[this.KEYS.blog] = this.cloneDefault(this.DEFAULT_BLOG);
    seed[this.KEYS.notepads] = {};
    seed[this.KEYS.teacherNotes] = [];
    seed[this.KEYS.internships] = this.cloneDefault(this.DEFAULT_INTERNSHIPS);
    seed[this.KEYS.inquiries] = this.cloneDefault(this.DEFAULT_INQUIRIES);
    seed[this.KEYS.syllabusTopics] = this.get(this.KEYS.syllabusTopics) || [];
    seed[this.KEYS.syllabusReviews] = this.get(this.KEYS.syllabusReviews) || [];
    seed[this.KEYS.syllabusSeed] = this.get(this.KEYS.syllabusSeed) || '';
    seed[this.KEYS.receiptCounter] = 1000;
    return seed;
  },

  writeStorageSeed(seed, { keepSession=false } = {}) {
    const session = keepSession ? this.getSession() : null;
    this._suspendSync = true;
    try {
      Object.values(this.KEYS).forEach(key => {
        if (key !== this.KEYS.session) localStorage.removeItem(key);
      });
      Object.entries(seed).forEach(([key, value]) => localStorage.setItem(key, JSON.stringify(value)));
      localStorage.setItem(this.KEYS.updatedAt, JSON.stringify(new Date().toISOString()));
      if (session) this.setSession(session);
      this.normalizeLegacyData();
      this.rebuildUsers();
      this.generateMonthlyFeeReminders();
    } finally {
      this._suspendSync = false;
    }
    this.queueServerSync(150);
    return true;
  },

  resetDemoData(options = {}) {
    return this.writeStorageSeed(this.defaultStorageSeed(options), {
      keepSession: !!options.keepSession,
    });
  },

  mergeDemoRecords(current, defaults, matchers) {
    const list = Array.isArray(current) ? this.cloneDefault(current) : [];
    defaults.forEach(item => {
      const exists = list.some(existing => matchers.some(match => match(existing, item)));
      if (!exists) list.push(this.cloneDefault(item));
    });
    return list;
  },

  ensureDemoReady() {
    const students = this.mergeDemoRecords(this.getStudents(), this.DEFAULT_STUDENTS, [
      (a, b) => a.id === b.id,
      (a, b) => a.username && b.username && a.username === b.username,
    ]);
    const teachers = this.mergeDemoRecords(this.getTeachers(), this.DEFAULT_TEACHERS, [
      (a, b) => a.id === b.id,
      (a, b) => a.username && b.username && a.username === b.username,
    ]);
    const courses = this.mergeDemoRecords(this.getCourses(), this.DEFAULT_COURSES, [
      (a, b) => a.id === b.id,
      (a, b) => a.name && b.name && String(a.name).toLowerCase() === String(b.name).toLowerCase(),
    ]);
    const changed =
      students.length !== this.getStudents().length ||
      teachers.length !== this.getTeachers().length ||
      courses.length !== this.getCourses().length;
    if (changed) {
      this._suspendSync = true;
      try {
        this.set(this.KEYS.students, students);
        this.set(this.KEYS.teachers, teachers);
        this.set(this.KEYS.courses, courses);
        if (!this.get(this.KEYS.settings)) this.set(this.KEYS.settings, this.cloneDefault(this.DEFAULT_SETTINGS));
        if (!this.get(this.KEYS.internships)) this.set(this.KEYS.internships, this.cloneDefault(this.DEFAULT_INTERNSHIPS));
        if (!this.get(this.KEYS.inquiries)) this.set(this.KEYS.inquiries, this.cloneDefault(this.DEFAULT_INQUIRIES));
        this.rebuildUsers();
      } finally {
        this._suspendSync = false;
      }
      this.queueServerSync(150);
    } else {
      this.rebuildUsers();
    }
    return changed;
  },

  /* ---------- INITIALIZE (run once) ---------- */
  init() {
    if (!this.get(this.KEYS.students))      this.set(this.KEYS.students,      this.DEFAULT_STUDENTS);
    if (!this.get(this.KEYS.teachers))      this.set(this.KEYS.teachers,      this.DEFAULT_TEACHERS);
    if (!this.get(this.KEYS.courses))       this.set(this.KEYS.courses,       this.DEFAULT_COURSES);
    if (!this.get(this.KEYS.settings))      this.set(this.KEYS.settings,      this.DEFAULT_SETTINGS);
    if (!this.get(this.KEYS.fees))          this.set(this.KEYS.fees,          {});
    if (!this.get(this.KEYS.attendance))    this.set(this.KEYS.attendance,    {});
    if (!this.get(this.KEYS.timetable))     this.set(this.KEYS.timetable,     this.DEFAULT_TIMETABLE());
    if (!this.get(this.KEYS.topics))        this.set(this.KEYS.topics,        []);
    if (!this.get(this.KEYS.gallery))       this.set(this.KEYS.gallery,       []);
    if (!this.get(this.KEYS.tasks))         this.set(this.KEYS.tasks,         []);
    if (!this.get(this.KEYS.salary))        this.set(this.KEYS.salary,        {});
    if (!this.get(this.KEYS.resumes))       this.set(this.KEYS.resumes,       {});
    if (!this.get(this.KEYS.notifications)) this.set(this.KEYS.notifications, this.DEFAULT_NOTIFICATIONS);
    if (!this.get(this.KEYS.blog))          this.set(this.KEYS.blog,          this.DEFAULT_BLOG);
    if (!this.get(this.KEYS.notepads))      this.set(this.KEYS.notepads,      {});
    if (!this.get(this.KEYS.teacherNotes))  this.set(this.KEYS.teacherNotes,  []);
    if (!this.get(this.KEYS.internships))   this.set(this.KEYS.internships,   this.DEFAULT_INTERNSHIPS);
    if (!this.get(this.KEYS.inquiries))      this.set(this.KEYS.inquiries,     this.DEFAULT_INQUIRIES);
    if (!this.get(this.KEYS.receiptCounter)) this.set(this.KEYS.receiptCounter, 1000);
    if (!this.get(this.KEYS.updatedAt))      this.set(this.KEYS.updatedAt,      new Date().toISOString());

    this.normalizeLegacyData();

    // Build users list from teachers + students
    this.rebuildUsers();
    this.generateMonthlyFeeReminders();
    this.hydrateFromServer();
  },

  normalizeLegacyData() {
    const fees = this.get(this.KEYS.fees) || {};
    let feesChanged = false;
    Object.keys(fees).forEach(studentId => {
      if (Array.isArray(fees[studentId])) {
        fees[studentId] = {
          payments: fees[studentId].map(p => ({ ...p, note: p.note || p.remark || '' })),
          totalFees: 0,
          notes: '',
        };
        feesChanged = true;
      }
    });
    if (feesChanged) this.set(this.KEYS.fees, fees);

    const tt = this.get(this.KEYS.timetable);
    if (tt) this.saveTimetable(this.normalizeTimetable(tt));
  },

  rebuildUsers() {
    const teachers = this.get(this.KEYS.teachers) || [];
    const students = this.get(this.KEYS.students) || [];
    const users = [
      { username:'admin', password:'admin123', role:'admin', name:'Administrator', id:'admin' },
      ...teachers.map(t => ({ username:t.username||t.name.toLowerCase().split(' ')[0], password:t.password||'teacher123', role:'teacher', name:t.name, id:t.id })),
      ...students.filter(s=>s.username).map(s => ({ username:s.username, password:s.password||'student123', role:'student', name:s.name, id:s.id })),
    ];
    this.set(this.KEYS.users, users);
  },

  /* ---------- STUDENTS ---------- */
  getStudents()       { return this.get(this.KEYS.students) || []; },
  saveStudents(arr)   { this.set(this.KEYS.students, arr); this.rebuildUsers(); },
  addStudent(s)       { const arr=this.getStudents(); arr.push({...s, id:'s'+Date.now()}); this.saveStudents(arr); },
  updateStudent(id,data) {
    const arr=this.getStudents();
    const i=arr.findIndex(x=>x.id===id);
    if(i>=0){arr[i]={...arr[i],...data}; this.saveStudents(arr); return true;}
    return false;
  },
  deleteStudent(id)   { this.saveStudents(this.getStudents().filter(x=>x.id!==id)); },
  getStudent(id)      { return this.getStudents().find(x=>x.id===id)||null; },

  getCourseStatuses() { return this.COURSE_STATUSES; },
  normalizeCourseStatus(status) {
    const raw = String(status || '').trim().toLowerCase();
    if (!raw || raw === 'all') return 'All';
    if (['continue','continuing','active','countinue','couniting'].includes(raw)) return 'Continue';
    if (['complete','completed','done'].includes(raw)) return 'Complete';
    if (['pending','pending course'].includes(raw)) return 'Pending';
    if (['leave','on leave'].includes(raw)) return 'Leave';
    if (['left','left course'].includes(raw)) return 'Left';
    return status;
  },
  studentMatchesCourseStatus(student, status='All') {
    const normalized = this.normalizeCourseStatus(status);
    if (!normalized || normalized === 'All') return true;
    return this.normalizeCourseStatus(student && student.courseStatus) === normalized;
  },
  getStudentsByCourseStatus(status='All') {
    return this.getStudents().filter(s => this.studentMatchesCourseStatus(s, status));
  },
  personMatchesGender(person, gender='All') {
    const normalized = String(gender || 'All').toLowerCase();
    if (normalized === 'all' || normalized === '') return true;
    const personGender = String(person && person.gender || '').toLowerCase();
    if (normalized === 'boys' || normalized === 'male') return personGender === 'male';
    if (normalized === 'girls' || normalized === 'female') return personGender === 'female';
    return personGender === normalized;
  },
  filterStudents({ status='All', gender='All', batch='All', courseId='All', feesStatus='All', day='All', dateFrom='', dateTo='', query='' } = {}) {
    const q = String(query || '').trim().toLowerCase();
    return this.getStudents().filter(s =>
      this.studentMatchesCourseStatus(s, status) &&
      this.personMatchesGender(s, gender) &&
      (!batch || batch === 'All' || s.batchNo === batch) &&
      (!courseId || courseId === 'All' || s.courseId === courseId || s.course === courseId) &&
      this.studentMatchesFeesStatus(s, feesStatus) &&
      this.studentMatchesDay(s, day) &&
      this.dateInRange(s.admissionDate || s.startDate, dateFrom, dateTo) &&
      (!q || [s.name, s.fatherName, s.mobile, s.email, s.course, s.batchNo, s.pcNo, s.courseStatus, s.gender, s.day, s.reference]
        .join(' ').toLowerCase().includes(q))
    );
  },

  getBatches() {
    return [...new Set(this.getStudents().map(s => s.batchNo).filter(Boolean))]
      .sort((a, b) => String(a).localeCompare(String(b), undefined, { numeric:true }));
  },
  getStudentDays() {
    return [...new Set(this.getStudents().map(s => s.day).filter(Boolean))]
      .sort((a, b) => String(a).localeCompare(String(b)));
  },
  studentFeeSummary(student) {
    const total = Number(student && student.totalFees) || 0;
    const paid = student && student.id ? this.paidFees(student.id) : 0;
    const balance = Math.max(0, total - paid);
    const percent = total ? Math.min(100, Math.round((paid / total) * 100)) : 0;
    let status = 'No Fee';
    if (total > 0 && balance <= 0) status = 'Cleared';
    else if (paid > 0) status = 'Partial';
    else if (total > 0) status = 'Pending';
    return { total, paid, balance, percent, status };
  },
  studentMatchesFeesStatus(student, feesStatus='All') {
    const normalized = String(feesStatus || 'All').toLowerCase();
    if (normalized === 'all' || normalized === '') return true;
    const summary = this.studentFeeSummary(student);
    if (normalized === 'due' || normalized === 'pending') return summary.balance > 0 && summary.paid <= 0;
    if (normalized === 'partial') return summary.balance > 0 && summary.paid > 0;
    if (normalized === 'cleared' || normalized === 'paid') return summary.total > 0 && summary.balance <= 0;
    if (normalized === 'no fee' || normalized === 'nofee') return summary.total <= 0;
    return summary.status.toLowerCase() === normalized;
  },
  studentMatchesDay(student, day='All') {
    if (!day || day === 'All') return true;
    return String(student && student.day || '').toLowerCase() === String(day).toLowerCase();
  },
  dateInRange(value, from='', to='') {
    if (!from && !to) return true;
    if (!value) return false;
    const time = Date.parse(value);
    if (Number.isNaN(time)) return false;
    if (from && time < Date.parse(from)) return false;
    if (to && time > Date.parse(to + 'T23:59:59')) return false;
    return true;
  },

  /* ---------- TEACHERS ---------- */
  getTeachers()       { return this.get(this.KEYS.teachers) || []; },
  saveTeachers(arr)   { this.set(this.KEYS.teachers, arr); this.rebuildUsers(); },
  addTeacher(t)       { const arr=this.getTeachers(); arr.push({...t, id:'t'+Date.now()}); this.saveTeachers(arr); },
  updateTeacher(id,data) {
    const arr=this.getTeachers();
    const i=arr.findIndex(x=>x.id===id);
    if(i>=0){arr[i]={...arr[i],...data}; this.saveTeachers(arr); return true;}
    return false;
  },
  deleteTeacher(id)   { this.saveTeachers(this.getTeachers().filter(x=>x.id!==id)); },
  getTeacher(id)      { return this.getTeachers().find(x=>x.id===id)||null; },

  filterTeachers({ gender='All', active='All' } = {}) {
    return this.getTeachers().filter(t =>
      this.personMatchesGender(t, gender) &&
      (active === 'All' || active === '' || String(!!t.active) === String(active))
    );
  },

  /* ---------- FEES ---------- */
  getFeesAll()        { return this.get(this.KEYS.fees) || {}; },
  getFees(studentId)  {
    const record = this.getFeesAll()[studentId];
    if (Array.isArray(record)) return { payments: record.map(p => ({ ...p, note: p.note || p.remark || '' })), totalFees:0, notes:'' };
    return record || { payments:[], totalFees:0, notes:'' };
  },
  getStudentFees(studentId) { return this.getFees(studentId).payments || []; },
  saveFees(studentId, data) {
    const all = this.getFeesAll();
    all[studentId] = data;
    this.set(this.KEYS.fees, all);
  },
  addPayment(studentId, payment) {
    const data = this.getFees(studentId);
    data.payments = data.payments || [];
    data.payments.push({ ...payment, id:'pay'+Date.now(), date: payment.date||new Date().toISOString().slice(0,10) });
    this.saveFees(studentId, data);
  },

  /* ---------- ATTENDANCE ---------- */
  getAttendanceAll()  { return this.get(this.KEYS.attendance) || {}; },
  getAttendance(month){ return this.getAttendanceAll()[month] || {}; },
  saveAttendance(month, data) {
    const all = this.getAttendanceAll();
    all[month] = data;
    this.set(this.KEYS.attendance, all);
  },
  markAttendance(month, personId, day, status) {
    const data = this.getAttendance(month);
    if (!data[personId]) data[personId] = {};
    data[personId][day] = status;
    this.saveAttendance(month, data);
  },

  /* ---------- TIMETABLE ---------- */
  DEFAULT_TIMETABLE() {
    const devices = this.DEFAULT_DEVICES();
    return {
      timeSlots: ['9:00-10:00','10:00-11:00','11:00-12:00','12:00-1:00','1:00-2:00','2:00-3:00','3:00-4:00','4:00-5:00'],
      devices,
      days: devices,
      entries: {},
    };
  },
  DEFAULT_DEVICES() {
    return [
      ...Array.from({ length:10 }, (_, i) => `PC ${i + 1}`),
      ...Array.from({ length:7 }, (_, i) => `Laptop ${i + 1}`),
    ];
  },
  normalizeTimetable(tt) {
    const base = this.DEFAULT_TIMETABLE();
    const currentDays = Array.isArray(tt && tt.days) ? tt.days : [];
    const currentDevices = Array.isArray(tt && tt.devices) ? tt.devices : [];
    const hasDeviceDays = currentDays.some(name => /^(PC|Laptop)\s*\d+/i.test(String(name)));
    const devices = currentDevices.length ? currentDevices : (hasDeviceDays ? currentDays : base.devices);
    return {
      ...base,
      ...(tt || {}),
      devices,
      days: devices,
      entries: (tt && tt.entries) || {},
    };
  },
  getTimetable()     { return this.normalizeTimetable(this.get(this.KEYS.timetable) || this.DEFAULT_TIMETABLE()); },
  saveTimetable(tt)  { this.set(this.KEYS.timetable, this.normalizeTimetable(tt)); },
  getTimetableDevices() { return this.getTimetable().devices || this.DEFAULT_DEVICES(); },

  /* ---------- TOPICS ---------- */
  getTopics()        { return this.get(this.KEYS.topics) || []; },
  addTopic(t)        { const arr=this.getTopics(); arr.unshift({...t, id:'tp'+Date.now(), createdAt:new Date().toISOString()}); this.set(this.KEYS.topics, arr); },
  updateTopic(id,data) {
    const arr=this.getTopics();
    const i=arr.findIndex(x=>x.id===id);
    if(i>=0){arr[i]={...arr[i],...data}; this.set(this.KEYS.topics, arr);}
  },
  deleteTopic(id)    { this.set(this.KEYS.topics, this.getTopics().filter(x=>x.id!==id)); },

  /* ---------- GALLERY ---------- */
  getGallery()       { return this.get(this.KEYS.gallery) || []; },
  addGalleryItem(g)  { const arr=this.getGallery(); arr.unshift({...g, id:'g'+Date.now(), uploadedAt:new Date().toISOString()}); this.set(this.KEYS.gallery, arr); },
  updateGalleryItem(id,data) {
    const arr=this.getGallery();
    const i=arr.findIndex(x=>x.id===id);
    if(i>=0){arr[i]={...arr[i],...data}; this.set(this.KEYS.gallery, arr);}
  },
  deleteGalleryItem(id) { this.set(this.KEYS.gallery, this.getGallery().filter(x=>x.id!==id)); },

  /* ---------- COURSES ---------- */
  getCourses()       { return this.get(this.KEYS.courses) || this.DEFAULT_COURSES; },
  addCourse(c)       { const arr=this.getCourses(); arr.push({...c, id:'c'+Date.now()}); this.set(this.KEYS.courses, arr); },
  updateCourse(id,data) {
    const arr=this.getCourses();
    const i=arr.findIndex(x=>x.id===id);
    if(i>=0){arr[i]={...arr[i],...data}; this.set(this.KEYS.courses, arr);}
  },
  deleteCourse(id)   { this.set(this.KEYS.courses, this.getCourses().filter(x=>x.id!==id)); },

  /* ---------- TASKS ---------- */
  getTasks()         { return this.get(this.KEYS.tasks) || []; },
  saveTasks(arr)     { this.set(this.KEYS.tasks, arr); },
  addTask(t) {
    const arr = this.getTasks();
    arr.unshift({ ...t, id:'task'+Date.now(), createdAt:new Date().toISOString(), status:'Pending' });
    this.saveTasks(arr);
  },
  updateTask(id, data) {
    const arr = this.getTasks();
    const i = arr.findIndex(x=>x.id===id);
    if(i>=0){ arr[i]={...arr[i],...data}; this.saveTasks(arr); return true; }
    return false;
  },
  deleteTask(id)     { this.saveTasks(this.getTasks().filter(x=>x.id!==id)); },
  getTasksForUser(userId, role) {
    return this.getTasks().filter(t =>
      t.assignedTo === userId || t.assignedTo === role || t.createdBy === userId
    );
  },

  /* ---------- SALARY ---------- */
  getSalaryAll()     { return this.get(this.KEYS.salary) || {}; },
  getSalary(teacherId) { return this.getSalaryAll()[teacherId] || { records:[], baseSalary:0 }; },
  saveSalaryRecord(teacherId, data) {
    const all = this.getSalaryAll();
    all[teacherId] = data;
    this.set(this.KEYS.salary, all);
  },
  addSalaryPayment(teacherId, record) {
    const data = this.getSalary(teacherId);
    data.records = data.records || [];
    data.records.unshift({ ...record, id:'sal'+Date.now(), paidAt:new Date().toISOString() });
    this.saveSalaryRecord(teacherId, data);
  },

  /* ---------- RESUMES ---------- */
  getResumesAll()    { return this.get(this.KEYS.resumes) || {}; },
  getResume(studentId) { return this.getResumesAll()[studentId] || null; },
  saveResume(studentId, data) {
    const all = this.getResumesAll();
    all[studentId] = { ...data, updatedAt: new Date().toISOString() };
    this.set(this.KEYS.resumes, all);
  },

  /* ---------- SETTINGS ---------- */
  getSettings()      { return { ...this.DEFAULT_SETTINGS, ...(this.get(this.KEYS.settings) || {}) }; },
  saveSettings(s)    { this.set(this.KEYS.settings, {...this.getSettings(),...s}); },

  /* ---------- SESSION ---------- */
  getSession()       { return this.get(this.KEYS.session); },
  setSession(s)      { this.set(this.KEYS.session, s); },
  clearSession()     { localStorage.removeItem(this.KEYS.session); },

  /* ---------- AUTH ---------- */
  login(username, password) {
    const users = this.get(this.KEYS.users) || [];
    return users.find(u => u.username===username && u.password===password) || null;
  },

  /* ---------- HELPERS ---------- */
  generateId(prefix) { return prefix + Date.now() + Math.random().toString(36).slice(2,7); },

  paidFees(studentId) {
    const fees = this.getFees(studentId);
    return (fees.payments||[]).reduce((sum,p)=>sum+(Number(p.amount)||0), 0);
  },
  pendingFees(studentId) {
    const student = this.getStudent(studentId);
    if(!student) return 0;
    return (student.totalFees||0) - this.paidFees(studentId);
  },

  /* Attendance summary for a student in a given month */
  attendanceSummary(personId, month) {
    const data = this.getAttendance(month);
    const days = data[personId] || {};
    const vals = Object.values(days);
    return {
      present: vals.filter(v=>v==='P').length,
      absent:  vals.filter(v=>v==='A').length,
      leave:   vals.filter(v=>v==='L').length,
      total:   vals.filter(v=>v!=='').length,
    };
  },

  /* Birthday check: returns people with birthday today */
  getTodayBirthdays() {
    const today = new Date();
    const mm = String(today.getMonth()+1).padStart(2,'0');
    const dd = String(today.getDate()).padStart(2,'0');
    const bdays = [];
    const students = this.getStudents();
    const teachers = this.getTeachers();
    [...students, ...teachers].forEach(p => {
      if (p.dob) {
        const parts = p.dob.split('-');
        if (parts.length === 3 && parts[1] === mm && parts[2] === dd) {
          bdays.push({ name: p.name, role: p.role||'student', dob: p.dob });
        }
      }
    });
    return bdays;
  },

  /* ---------- NOTIFICATIONS ---------- */
  getNotifications()    { return this.get(this.KEYS.notifications) || []; },
  addNotification(n) {
    const arr = this.getNotifications();
    arr.unshift({ ...n, id:'notif'+Date.now(), createdAt: new Date().toISOString() });
    this.set(this.KEYS.notifications, arr);
  },
  saveNotifications(arr) { this.set(this.KEYS.notifications, arr || []); },
  upsertNotification(n) {
    const arr = this.getNotifications();
    const i = arr.findIndex(x => x.id === n.id);
    const payload = { ...n, createdAt: n.createdAt || new Date().toISOString() };
    if (i >= 0) arr[i] = { ...arr[i], ...n, createdAt: arr[i].createdAt || payload.createdAt };
    else arr.unshift(payload);
    this.saveNotifications(arr);
  },
  deleteNotification(id) { this.set(this.KEYS.notifications, this.getNotifications().filter(x=>x.id!==id)); },
  notificationAppliesToSession(n, sessionOrRole) {
    const session = typeof sessionOrRole === 'string' ? { role:sessionOrRole } : (sessionOrRole || {});
    const role = session.role || '';
    if (role === 'admin') return true;
    const targetOk = n.target === 'all' || n.target === (role === 'teacher' ? 'teachers' : 'students');
    if (!targetOk) return false;
    if (role === 'student' && n.studentId) return n.studentId === session.id;
    return true;
  },
  getUnreadCount(sessionOrRole) {
    const all = this.getNotifications().filter(n => this.notificationAppliesToSession(n, sessionOrRole));
    const read = JSON.parse(localStorage.getItem('cc_notif_read')||'[]');
    return all.filter(n=>!read.includes(n.id)).length;
  },
  getPendingFeeStudents() {
    return this.getStudents().filter(s => this.pendingFees(s.id) > 0 && this.studentMatchesCourseStatus(s, 'Continue'));
  },
  generateMonthlyFeeReminders(date = new Date(), { force=false } = {}) {
    const month = date.toISOString().slice(0, 7);
    const dueDate = `${month}-10`;
    // Only auto-fire from the 10th of the month onward. Before that, make sure no
    // reminder for the current month is showing yet (covers month-to-month rollover).
    if (!force && date.getDate() < 10) {
      this.getNotifications().filter(n => n.reminderMonth === month).forEach(n => this.deleteNotification(n.id));
      return { created:0, totalPending:0, skipped:'before-10th' };
    }
    const pending = this.getPendingFeeStudents();
    if (!pending.length) return { created:0, totalPending:0 };

    const totalPending = pending.reduce((sum, s) => sum + this.pendingFees(s.id), 0);
    const teacherList = pending.slice(0, 8).map(s => `${s.name} (${this.pendingFees(s.id)})`).join(', ');
    const currency = this.getSettings().currency || '₹';
    this.upsertNotification({
      id:`fee-reminder-teachers-${month}`,
      title:`Monthly Pending Fees Reminder - ${month}`,
      message:`Pending fees reminder for due date ${dueDate}. ${pending.length} continuing student(s) have pending dues. Total pending: ${currency}${totalPending.toLocaleString('en-IN')}. Students: ${teacherList}${pending.length > 8 ? '...' : ''}`,
      type:'Fee',
      target:'teachers',
      date:dueDate,
      priority:'High',
      icon:'💰',
      createdBy:'System',
      createdByRole:'system',
      reminderMonth:month,
    });

    pending.forEach(student => {
      const balance = this.pendingFees(student.id);
      this.upsertNotification({
        id:`fee-reminder-student-${student.id}-${month}`,
        title:`Monthly Fee Reminder - ${month}`,
        message:`Dear ${student.name}, your pending fee balance is ${currency}${balance.toLocaleString('en-IN')}. Please clear it by ${dueDate}.`,
        type:'Fee',
        target:'students',
        studentId:student.id,
        date:dueDate,
        priority:'High',
        icon:'💰',
        createdBy:'System',
        createdByRole:'system',
        reminderMonth:month,
      });
    });
    return { created:pending.length + 1, totalPending };
  },

  /* ---------- BLOG ---------- */
  getBlogPosts()       { return this.get(this.KEYS.blog) || []; },
  addBlogPost(post) {
    const arr = this.getBlogPosts();
    arr.unshift({ ...post, id:'bl'+Date.now(), publishedAt: new Date().toISOString().slice(0,10), views:0 });
    this.set(this.KEYS.blog, arr);
  },
  updateBlogPost(id, data) {
    const arr = this.getBlogPosts();
    const i = arr.findIndex(x=>x.id===id);
    if(i>=0){ arr[i]={...arr[i],...data}; this.set(this.KEYS.blog, arr); }
  },
  deleteBlogPost(id)   { this.set(this.KEYS.blog, this.getBlogPosts().filter(x=>x.id!==id)); },

  /* ---------- NOTEPADS ---------- */
  getNotepad(userId)   { return (this.get(this.KEYS.notepads)||{})[userId] || ''; },
  saveNotepad(userId, text) {
    const all = this.get(this.KEYS.notepads) || {};
    all[userId] = text;
    this.set(this.KEYS.notepads, all);
  },

  /* ---------- TEACHER NOTES ---------- */
  getTeacherNotes()    { return this.get(this.KEYS.teacherNotes) || []; },
  addTeacherNote(n) {
    const arr = this.getTeacherNotes();
    arr.unshift({ ...n, id:'tn'+Date.now(), createdAt: new Date().toISOString() });
    this.set(this.KEYS.teacherNotes, arr);
  },
  deleteTeacherNote(id) { this.set(this.KEYS.teacherNotes, this.getTeacherNotes().filter(x=>x.id!==id)); },

  /* ---------- INTERNSHIPS ---------- */
  getInternships()    { return this.get(this.KEYS.internships) || []; },
  saveInternships(arr){ this.set(this.KEYS.internships, arr); },
  addInternship(item) {
    const arr = this.getInternships();
    const now = new Date().toISOString();
    arr.unshift({ ...item, id:this.generateId('int'), createdAt:now, updatedAt:now });
    this.saveInternships(arr);
  },
  updateInternship(id, data) {
    const arr = this.getInternships();
    const i = arr.findIndex(x=>x.id===id);
    if (i >= 0) {
      arr[i] = { ...arr[i], ...data, updatedAt:new Date().toISOString() };
      this.saveInternships(arr);
      return true;
    }
    return false;
  },
  deleteInternship(id) {
    this.saveInternships(this.getInternships().filter(x=>x.id!==id));
  },
  getInternship(id) {
    return this.getInternships().find(x=>x.id===id) || null;
  },

  /* ---------- INQUIRIES ---------- */
  getInquiries()     { return this.get(this.KEYS.inquiries) || []; },
  saveInquiries(arr) { this.set(this.KEYS.inquiries, arr || []); },
  addInquiry(item) {
    const arr = this.getInquiries();
    const now = new Date().toISOString();
    arr.unshift({
      ...item,
      id:this.generateId('inq'),
      status:item.status || 'Open',
      priority:item.priority || 'Medium',
      inquiryDate:item.inquiryDate || now.slice(0,10),
      createdAt:now,
      updatedAt:now,
    });
    this.saveInquiries(arr);
  },
  updateInquiry(id, data) {
    const arr = this.getInquiries();
    const i = arr.findIndex(x => x.id === id);
    if (i >= 0) {
      arr[i] = { ...arr[i], ...data, updatedAt:new Date().toISOString() };
      this.saveInquiries(arr);
      return true;
    }
    return false;
  },
  deleteInquiry(id) {
    this.saveInquiries(this.getInquiries().filter(x => x.id !== id));
  },
  getInquiry(id) {
    return this.getInquiries().find(x => x.id === id) || null;
  },
  convertInquiryToStudent(id, overrides={}) {
    const inquiry = this.getInquiry(id);
    if (!inquiry) return null;
    const course = this.getCourses().find(c => c.id === inquiry.courseId || c.name === inquiry.course) || {};
    const student = {
      name: inquiry.name,
      fatherName: inquiry.guardianName || '',
      motherName: '',
      gender: inquiry.gender || 'Male',
      dob: '',
      mobile: inquiry.mobile || '',
      altMobile: inquiry.altMobile || '',
      email: inquiry.email || '',
      aadhaar: '',
      qualification: '',
      religion: '',
      caste: '',
      maritalStatus: 'Single',
      familyMembers: '',
      annualIncome: '',
      fatherOccupation: '',
      motherOccupation: '',
      address: inquiry.address || '',
      landmark: '',
      village: '',
      district: 'Kapurthala',
      pincode: '144601',
      state: 'Punjab',
      courseId: course.id || inquiry.courseId || '',
      course: course.name || inquiry.course || '',
      subcategories: [],
      batchNo: inquiry.batchNo || 'Batch 1',
      pcNo: '',
      timings: inquiry.preferredTime || '',
      day: inquiry.preferredDays || '',
      totalFees: Number(inquiry.quotedFees || course.fees || 0),
      monthlyFees: 0,
      duration: course.duration || '',
      admissionDate: new Date().toISOString().slice(0,10),
      startDate: new Date().toISOString().slice(0,10),
      reference: inquiry.source || 'Inquiry',
      grade: '',
      percentage: 0,
      rank: 0,
      username: String(inquiry.mobile || inquiry.name || '').replace(/\s+/g,'').toLowerCase().slice(0,18),
      password: 'student123',
      active: true,
      courseStatus: 'Pending',
      profileImage: '',
      attendance: {},
      marks: {},
      topics: [],
      feedback: inquiry.notes || '',
      experience: 0,
      occupation: 'Student',
      resignNo: '',
      signature: '',
      ...overrides,
    };
    this.addStudent(student);
    const created = this.getStudents().slice(-1)[0];
    this.updateInquiry(id, { status:'Converted', convertedStudentId: created && created.id });
    return created || student;
  },
  filterInquiries({ status='All', gender='All', courseId='All', batch='All', source='All', priority='All', dateFrom='', dateTo='', followFrom='', followTo='', query='' } = {}) {
    const q = String(query || '').trim().toLowerCase();
    return this.getInquiries().filter(item =>
      (!status || status === 'All' || item.status === status) &&
      this.personMatchesGender(item, gender) &&
      (!courseId || courseId === 'All' || item.courseId === courseId || item.course === courseId) &&
      (!batch || batch === 'All' || item.batchNo === batch) &&
      (!source || source === 'All' || item.source === source) &&
      (!priority || priority === 'All' || item.priority === priority) &&
      this.dateInRange(item.inquiryDate || item.createdAt, dateFrom, dateTo) &&
      this.dateInRange(item.followUpDate, followFrom, followTo) &&
      (!q || [item.name, item.mobile, item.email, item.guardianName, item.course, item.batchNo, item.source, item.status, item.priority, item.notes]
        .join(' ').toLowerCase().includes(q))
    );
  },

  /* ---------- FEE RECEIPTS ---------- */
  getSyllabusTopics() { return this.get(this.KEYS.syllabusTopics) || []; },
  saveSyllabusTopics(rows) { return this.set(this.KEYS.syllabusTopics, rows || []); },
  getSyllabusReviews() { return this.get(this.KEYS.syllabusReviews) || []; },
  saveSyllabusReviews(rows) { return this.set(this.KEYS.syllabusReviews, rows || []); },

  nextReceiptNo() {
    const n = (this.get(this.KEYS.receiptCounter) || 1000) + 1;
    this.set(this.KEYS.receiptCounter, n);
    return n;
  },

  /* ---------- SERVER SYNC (optional backend) ---------- */
  canUseServerSync() {
    return typeof window !== 'undefined' && window.location.protocol.startsWith('http') && typeof fetch === 'function';
  },
  exportStorage() {
    const snapshot = {
      _schema: 'computer-care-localstorage-v2',
      _updatedAt: this.get(this.KEYS.updatedAt) || new Date().toISOString(),
    };
    Object.values(this.KEYS).forEach(key => {
      if (key === this.KEYS.session) return;
      snapshot[key] = this.get(key);
    });
    return snapshot;
  },
  applyStorageSnapshot(snapshot) {
    const data = snapshot && snapshot.data ? snapshot.data : snapshot;
    if (!data || typeof data !== 'object') return false;
    Object.values(this.KEYS).forEach(key => {
      if (key === this.KEYS.session) return;
      if (Object.prototype.hasOwnProperty.call(data, key)) {
        localStorage.setItem(key, JSON.stringify(data[key]));
      }
    });
    if (data._updatedAt) localStorage.setItem(this.KEYS.updatedAt, JSON.stringify(data._updatedAt));
    this.normalizeLegacyData();
    this.rebuildUsers();
    return true;
  },
  hydrateFromServer() {
    if (!this.canUseServerSync() || this._hydrating) return;
    this._hydrating = true;
    fetch('api/db', { cache:'no-store' })
      .then(res => res.ok ? res.json() : null)
      .then(remote => {
        this._hydrating = false;
        if (!remote) return;
        const hasRemoteData = Object.values(this.KEYS).some(key => Object.prototype.hasOwnProperty.call(remote, key));
        const remoteTime = Date.parse(remote._updatedAt || 0) || 0;
        const localTime = Date.parse(this.get(this.KEYS.updatedAt) || 0) || 0;
        if (hasRemoteData && remoteTime > localTime + 1000) {
          this.applyStorageSnapshot(remote);
          if (!sessionStorage.getItem('cc_server_hydrated')) {
            sessionStorage.setItem('cc_server_hydrated', '1');
            window.location.reload();
          }
        } else {
          this.queueServerSync(800);
        }
      })
      .catch(() => { this._hydrating = false; });
  },
  queueServerSync(delay = 500) {
    if (!this.canUseServerSync() || this._applyingRemote) return;
    clearTimeout(this._syncTimer);
    this._syncTimer = setTimeout(() => this.syncToServer(), delay);
  },
  syncToServer() {
    if (!this.canUseServerSync() || this._syncing) return;
    this._syncing = true;
    fetch('api/db', {
      method: 'POST',
      headers: { 'Content-Type':'application/json' },
      body: JSON.stringify(this.exportStorage()),
    }).catch(() => null).finally(() => { this._syncing = false; });
  },

  /* Export all data as JSON */
  exportAll() {
    return {
      students:      this.getStudents(),
      teachers:      this.getTeachers(),
      fees:          this.getFeesAll(),
      attendance:    this.getAttendanceAll(),
      timetable:     this.getTimetable(),
      topics:        this.getTopics(),
      gallery:       this.getGallery(),
      courses:       this.getCourses(),
      tasks:         this.getTasks(),
      salary:        this.getSalaryAll(),
      notifications: this.getNotifications(),
      blog:          this.getBlogPosts(),
      teacherNotes:  this.getTeacherNotes(),
      internships:   this.getInternships(),
      inquiries:      this.getInquiries(),
      syllabusTopics: this.getSyllabusTopics ? this.getSyllabusTopics() : (this.get(this.KEYS.syllabusTopics) || []),
      syllabusReviews:this.getSyllabusReviews ? this.getSyllabusReviews() : (this.get(this.KEYS.syllabusReviews) || []),
      settings:      this.getSettings(),
      exportedAt:    new Date().toISOString(),
    };
  },
};

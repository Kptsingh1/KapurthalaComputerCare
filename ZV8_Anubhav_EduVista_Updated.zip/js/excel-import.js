/* ==========================================================================
   EXCEL IMPORT ENGINE
   Import data from Excel (.xlsx/.xls) into academy database.
   Supports: Students, Teachers, Fees, Attendance, Topics, Courses, Tasks,
             Internships, Notifications, Gallery, Salary sheets.
   ========================================================================== */

const ExcelImport = (() => {

  // ---- Sheet column mappings ----
  const SHEET_MAPS = {
    'Students': {
      target: 'students',
      columns: {
        'Name': 'name', 'Father Name': 'fatherName', 'Mother Name': 'motherName',
        'Gender': 'gender', 'DOB': 'dob', 'Mobile': 'mobile', 'Alt Mobile': 'altMobile',
        'Email': 'email', 'Aadhaar': 'aadhaar', 'Qualification': 'qualification',
        'Religion': 'religion', 'Caste': 'caste', 'Marital Status': 'maritalStatus',
        'Family Members': 'familyMembers', 'Annual Income': 'annualIncome',
        'Father Occupation': 'fatherOccupation', 'Mother Occupation': 'motherOccupation',
        'Address': 'address', 'Landmark': 'landmark', 'Village': 'village',
        'District': 'district', 'Pincode': 'pincode', 'State': 'state',
        'Course': 'course', 'Course ID': 'courseId', 'Batch': 'batchNo',
        'Device': 'pcNo', 'Timings': 'timings', 'Day': 'day',
        'Total Fees': 'totalFees', 'Monthly Fees': 'monthlyFees', 'Duration': 'duration',
        'Admission Date': 'admissionDate', 'Status': 'courseStatus',
        'Username': 'username', 'Password': 'password',
        'Grade': 'grade', 'Percentage': 'percentage', 'Rank': 'rank',
        'Reference': 'reference', 'Occupation': 'occupation', 'Experience': 'experience',
        'Feedback': 'feedback', 'Resign No': 'resignNo',
      },
      defaults: { active: true, courseStatus: 'Continue', profileImage: '', attendance: {}, marks: {}, topics: [] },
      idPrefix: 'si',
    },
    'Teachers': {
      target: 'teachers',
      columns: {
        'Name': 'name', 'Qualification': 'qualification', 'Subject': 'subject',
        'Mobile': 'mobile', 'Email': 'email', 'Gender': 'gender',
        'DOB': 'dob', 'Join Date': 'joinDate', 'Salary': 'salary',
        'Performance': 'performance', 'Active': 'active',
        'Address': 'address', 'Username': 'username', 'Password': 'password',
      },
      defaults: { active: true, role: 'teacher', profileImage: '', attendance: {} },
      idPrefix: 'ti',
    },
    'Fees': {
      target: 'fees',
      columns: {
        'Student ID': 'studentId', 'Student': 'studentName',
        'Date': 'date', 'Amount': 'amount', 'Mode': 'mode',
        'Receipt No': 'receiptNo', 'Note': 'note',
      },
      special: 'fees',
    },
    'Attendance': {
      target: 'attendance',
      columns: {
        'Month': 'month', 'Person ID': 'personId', 'Name': 'name',
        'Role': 'role', 'Present': 'present', 'Absent': 'absent', 'Leave': 'leave',
      },
      special: 'attendance',
    },
    'Topics': {
      target: 'topics',
      columns: {
        'Title': 'title', 'Course': 'course', 'Teacher': 'teacher',
        'Date': 'date', 'Time': 'time', 'Description': 'description', 'Status': 'status',
        'Student': 'studentName', 'Student ID': 'studentId',
      },
      idPrefix: 'tpi',
    },
    'Tasks': {
      target: 'tasks',
      columns: {
        'Title': 'title', 'Assigned To': 'assignedTo', 'Status': 'status',
        'Priority': 'priority', 'Due Date': 'dueDate', 'Description': 'description',
      },
      defaults: { status: 'Pending', priority: 'Medium' },
      idPrefix: 'tki',
    },
    'Internships': {
      target: 'internships',
      columns: {
        'Student': 'studentName', 'Student ID': 'studentId', 'Program': 'program',
        'Company': 'company', 'Mentor': 'mentor',
        'Start Date': 'startDate', 'End Date': 'endDate', 'Hours': 'hours',
        'Status': 'status', 'Project': 'projectTitle', 'Description': 'description',
      },
      defaults: { status: 'Active' },
      idPrefix: 'ini',
    },
    'Courses': {
      target: 'courses',
      columns: {
        'Name': 'name', 'Duration': 'duration', 'Fees': 'fees', 'Subcategories': 'subcategories',
      },
      idPrefix: 'ci',
    },
    'Notifications': {
      target: 'notifications',
      columns: {
        'Title': 'title', 'Type': 'type', 'Target': 'target',
        'Date': 'date', 'Priority': 'priority', 'Message': 'message',
      },
      defaults: { priority: 'Medium', target: 'all' },
      idPrefix: 'ni',
    },
    'Salary': {
      target: 'salary',
      columns: {
        'Teacher ID': 'teacherId', 'Teacher': 'teacherName',
        'Base Salary': 'baseSalary', 'Date': 'date', 'Amount': 'amount',
        'Mode': 'mode', 'Note': 'note',
      },
      special: 'salary',
    },
  };

  // ---- Parse date from Excel ----
  function parseDate(val) {
    if (!val) return '';
    if (typeof val === 'number') {
      // Excel serial date
      const date = new Date(Math.round((val - 25569) * 86400 * 1000));
      return date.toISOString().slice(0, 10);
    }
    if (val instanceof Date) return val.toISOString().slice(0, 10);
    const s = String(val);
    // Try ISO or common formats
    const m = s.match(/(\d{1,4})[\/\-\.](\d{1,2})[\/\-\.](\d{2,4})/);
    if (m) {
      const parts = m.slice(1).map(Number);
      // Determine year position
      if (parts[0] > 31) return `${parts[0]}-${String(parts[1]).padStart(2,'0')}-${String(parts[2]).padStart(2,'0')}`;
      if (parts[2] > 31) return `${parts[2]}-${String(parts[1]).padStart(2,'0')}-${String(parts[0]).padStart(2,'0')}`;
    }
    return s;
  }

  function generateId(prefix, existing, index) {
    return `${prefix}${Date.now()}_${index}`;
  }

  // ---- Build header map from row ----
  function buildHeaderMap(headerRow, columnDefs) {
    const map = {};
    headerRow.forEach((cell, ci) => {
      const header = String(cell || '').trim();
      if (columnDefs[header] !== undefined) map[columnDefs[header]] = ci;
    });
    return map;
  }

  // ---- Extract value from row ----
  function getVal(row, colIndex) {
    if (colIndex === undefined || colIndex === -1) return '';
    const v = row[colIndex];
    if (v === undefined || v === null) return '';
    if (v instanceof Date) return parseDate(v);
    return v;
  }

  // ---- Import Students sheet ----
  function importStudents(rows, headerRow) {
    const config = SHEET_MAPS['Students'];
    const hmap = buildHeaderMap(headerRow, config.columns);
    const existing = DB.getStudents();
    const existingMobiles = new Set(existing.map(s => String(s.mobile)));
    const added = [], skipped = [], updated = [];

    rows.forEach((row, i) => {
      const name = String(getVal(row, hmap.name) || '').trim();
      const mobile = String(getVal(row, hmap.mobile) || '').trim();
      if (!name) { skipped.push({ row: i + 2, reason: 'No name' }); return; }

      const record = { ...config.defaults };
      Object.entries(hmap).forEach(([field, ci]) => {
        let val = getVal(row, ci);
        if (['dob', 'admissionDate'].includes(field) && val) val = parseDate(val);
        if (['totalFees', 'monthlyFees', 'familyMembers', 'percentage', 'rank', 'experience'].includes(field)) val = Number(val) || 0;
        record[field] = val;
      });

      // Update existing by mobile
      const existingStudent = mobile ? existing.find(s => String(s.mobile) === mobile) : null;
      if (existingStudent) {
        const merged = { ...existingStudent, ...record, id: existingStudent.id };
        DB.saveStudent(merged);
        updated.push(name);
      } else {
        record.id = generateId(config.idPrefix, existing, i);
        if (!record.username) record.username = mobile || `student_${i}`;
        if (!record.password) record.password = 'student123';
        DB.saveStudent(record);
        added.push(name);
      }
    });
    return { sheet: 'Students', added: added.length, updated: updated.length, skipped: skipped.length, details: skipped };
  }

  // ---- Import Teachers sheet ----
  function importTeachers(rows, headerRow) {
    const config = SHEET_MAPS['Teachers'];
    const hmap = buildHeaderMap(headerRow, config.columns);
    const existing = DB.getTeachers();
    const added = [], updated = [], skipped = [];

    rows.forEach((row, i) => {
      const name = String(getVal(row, hmap.name) || '').trim();
      if (!name) { skipped.push({ row: i + 2, reason: 'No name' }); return; }

      const record = { ...config.defaults, role: 'teacher' };
      Object.entries(hmap).forEach(([field, ci]) => {
        let val = getVal(row, ci);
        if (['dob', 'joinDate'].includes(field) && val) val = parseDate(val);
        if (['salary'].includes(field)) val = Number(val) || 0;
        if (field === 'active') val = String(val).toLowerCase() !== 'false';
        record[field] = val;
      });

      const existingTeacher = existing.find(t => t.name === name || t.mobile === record.mobile);
      if (existingTeacher) {
        const merged = { ...existingTeacher, ...record, id: existingTeacher.id };
        DB.saveTeacher(merged);
        updated.push(name);
      } else {
        record.id = generateId(config.idPrefix, existing, i);
        if (!record.username) record.username = name.toLowerCase().replace(/\s+/, '');
        if (!record.password) record.password = 'teacher123';
        DB.saveTeacher(record);
        added.push(name);
      }
    });
    return { sheet: 'Teachers', added: added.length, updated: updated.length, skipped: skipped.length, details: skipped };
  }

  // ---- Import Generic (Topics, Tasks, etc.) ----
  function importGeneric(sheetName, rows, headerRow) {
    const config = SHEET_MAPS[sheetName];
    if (!config) return { sheet: sheetName, added: 0, updated: 0, skipped: 1, details: [{reason:'Unknown sheet'}] };
    const hmap = buildHeaderMap(headerRow, config.columns);
    const added = [], skipped = [];

    rows.forEach((row, i) => {
      const record = { ...(config.defaults || {}) };
      Object.entries(hmap).forEach(([field, ci]) => {
        let val = getVal(row, ci);
        if (['date', 'dueDate', 'startDate', 'endDate'].includes(field) && val) val = parseDate(val);
        if (['amount', 'hours', 'fees'].includes(field)) val = Number(val) || 0;
        if (field === 'subcategories' && typeof val === 'string') {
          val = val.split(/[,;|]/).map(s => s.trim()).filter(Boolean);
        }
        record[field] = val;
      });

      const titleKey = Object.keys(hmap).find(f => ['title', 'name', 'studentName', 'teacherName'].includes(f));
      if (!titleKey || !record[titleKey]) { skipped.push({ row: i + 2, reason: 'Empty row' }); return; }
      record.id = generateId(config.idPrefix || 'xi', [], i);
      record.createdAt = record.createdAt || new Date().toISOString();

      // Save to correct store
      const key = 'cc_' + config.target;
      const arr = JSON.parse(localStorage.getItem(key) || '[]');
      arr.push(record);
      localStorage.setItem(key, JSON.stringify(arr));
      added.push(record[titleKey]);
    });
    return { sheet: sheetName, added: added.length, updated: 0, skipped: skipped.length, details: skipped };
  }

  // ---- Import Fees sheet ----
  function importFees(rows, headerRow) {
    const hmap = buildHeaderMap(headerRow, SHEET_MAPS['Fees'].columns);
    const added = [], skipped = [];

    rows.forEach((row, i) => {
      const studentId = String(getVal(row, hmap.studentId) || '').trim();
      const amount = Number(getVal(row, hmap.amount)) || 0;
      if (!studentId || !amount) { skipped.push({ row: i + 2, reason: 'Missing student ID or amount' }); return; }

      const payment = {
        date: parseDate(getVal(row, hmap.date)) || new Date().toISOString().slice(0, 10),
        amount,
        mode: getVal(row, hmap.mode) || 'Cash',
        receiptNo: getVal(row, hmap.receiptNo) || '',
        note: getVal(row, hmap.note) || '',
        importedAt: new Date().toISOString(),
      };

      const feesRaw = JSON.parse(localStorage.getItem('cc_fees') || '{}');
      if (!feesRaw[studentId]) feesRaw[studentId] = { payments: [] };
      if (!feesRaw[studentId].payments) feesRaw[studentId].payments = [];
      feesRaw[studentId].payments.push(payment);
      localStorage.setItem('cc_fees', JSON.stringify(feesRaw));
      added.push(`${studentId} - ₹${amount}`);
    });
    return { sheet: 'Fees', added: added.length, updated: 0, skipped: skipped.length, details: skipped };
  }

  // ---- Import Salary sheet ----
  function importSalary(rows, headerRow) {
    const hmap = buildHeaderMap(headerRow, SHEET_MAPS['Salary'].columns);
    const added = [], skipped = [];

    rows.forEach((row, i) => {
      const teacherId = String(getVal(row, hmap.teacherId) || '').trim();
      const amount = Number(getVal(row, hmap.amount)) || 0;
      if (!teacherId || !amount) { skipped.push({ row: i + 2, reason: 'Missing teacher ID or amount' }); return; }

      const payment = {
        date: parseDate(getVal(row, hmap.date)) || new Date().toISOString().slice(0, 10),
        amount,
        mode: getVal(row, hmap.mode) || 'Cash',
        note: getVal(row, hmap.note) || '',
        importedAt: new Date().toISOString(),
      };

      const salaryRaw = JSON.parse(localStorage.getItem('cc_salary') || '{}');
      if (!salaryRaw[teacherId]) salaryRaw[teacherId] = { records: [], baseSalary: Number(getVal(row, hmap.baseSalary)) || 0 };
      if (!salaryRaw[teacherId].records) salaryRaw[teacherId].records = [];
      salaryRaw[teacherId].records.push(payment);
      localStorage.setItem('cc_salary', JSON.stringify(salaryRaw));
      added.push(teacherId);
    });
    return { sheet: 'Salary', added: added.length, updated: 0, skipped: skipped.length, details: skipped };
  }

  // ---- Detect which row is the actual header ----
  function findHeaderRow(allRows) {
    for (let i = 0; i < Math.min(6, allRows.length); i++) {
      const row = allRows[i];
      if (!row) continue;
      const nonEmpty = row.filter(c => c !== null && c !== undefined && String(c).trim() !== '').length;
      const hasKeyword = row.some(c => {
        const s = String(c || '').toLowerCase();
        return ['name','id','date','mobile','title','amount','status','teacher','student'].some(k => s.includes(k));
      });
      if (nonEmpty >= 3 && hasKeyword) return i;
    }
    return 0;
  }

  // ---- Process a single worksheet ----
  function processSheet(sheetName, allRows) {
    if (!allRows || allRows.length < 2) return { sheet: sheetName, added: 0, updated: 0, skipped: 0 };

    const headerIdx = findHeaderRow(allRows);
    const headerRow = allRows[headerIdx];
    const dataRows = allRows.slice(headerIdx + 1).filter(r => r && r.some(c => c !== null && c !== undefined && String(c).trim() !== ''));

    if (!dataRows.length) return { sheet: sheetName, added: 0, updated: 0, skipped: 0, details: [{reason:'No data rows'}] };

    const normalized = sheetName.trim();
    if (normalized === 'Students') return importStudents(dataRows, headerRow);
    if (normalized === 'Teachers') return importTeachers(dataRows, headerRow);
    if (normalized === 'Fees') return importFees(dataRows, headerRow);
    if (normalized === 'Salary') return importSalary(dataRows, headerRow);
    if (SHEET_MAPS[normalized]) return importGeneric(normalized, dataRows, headerRow);

    return { sheet: sheetName, added: 0, updated: 0, skipped: dataRows.length, details: [{reason:'Unrecognised sheet name'}] };
  }

  // ---- Read file via SheetJS (XLSX) ----
  async function readFile(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = e => {
        try {
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: 'array', cellDates: true, dateNF: 'yyyy-mm-dd' });
          const results = [];
          workbook.SheetNames.forEach(name => {
            const ws = workbook.Sheets[name];
            const rows = XLSX.utils.sheet_to_json(ws, { header: 1, defval: null, raw: false });
            results.push(processSheet(name, rows));
          });
          resolve({ success: true, sheets: workbook.SheetNames, results });
        } catch (err) {
          reject(err);
        }
      };
      reader.onerror = () => reject(new Error('File read error'));
      reader.readAsArrayBuffer(file);
    });
  }

  // ---- UI: Open import modal ----
  function openImportModal() {
    if (!document.getElementById('excelImportModal')) buildImportModal();
    Modal.open('excelImportModal');
    document.getElementById('importResultArea').innerHTML = '';
    document.getElementById('importFileInput').value = '';
    document.getElementById('importProgressWrap').style.display = 'none';
  }

  function buildImportModal() {
    const el = document.createElement('div');
    el.innerHTML = `
    <div class="modal-overlay" id="excelImportModal">
      <div class="modal" style="max-width:640px">
        <div class="modal-header">
          <h3 class="modal-title">📥 Import from Excel</h3>
          <button class="modal-close" onclick="Modal.close('excelImportModal')">✕</button>
        </div>
        <div class="modal-body" style="max-height:70vh;overflow-y:auto">
          <!-- Drop zone -->
          <div id="importDropZone" style="border:2px dashed var(--primary);border-radius:var(--radius-md);padding:36px;text-align:center;cursor:pointer;transition:all 0.2s;background:var(--glass-bg-ultra-light)" 
               onclick="document.getElementById('importFileInput').click()"
               ondragover="ExcelImport._dragOver(event)" ondrop="ExcelImport._drop(event)">
            <div style="font-size:2.5rem;margin-bottom:8px">📊</div>
            <div style="font-weight:700;color:var(--text-main);margin-bottom:6px">Drop Excel file here or click to browse</div>
            <div style="font-size:0.8rem;color:var(--text-muted)">.xlsx / .xls supported — Sheet names must match:<br>
              <span style="color:var(--primary);font-weight:600">Students, Teachers, Fees, Salary, Topics, Tasks, Internships, Courses, Notifications</span>
            </div>
            <input type="file" id="importFileInput" accept=".xlsx,.xls" style="display:none" onchange="ExcelImport._handleFileSelect(this.files[0])">
          </div>

          <!-- Template download -->
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
            <button class="btn btn-sm btn-secondary" onclick="ExcelImport.downloadTemplate('Students')">📥 Students Template</button>
            <button class="btn btn-sm btn-secondary" onclick="ExcelImport.downloadTemplate('Teachers')">📥 Teachers Template</button>
            <button class="btn btn-sm btn-secondary" onclick="ExcelImport.downloadTemplate('Fees')">📥 Fees Template</button>
            <button class="btn btn-sm btn-ghost" onclick="ExcelImport.downloadMasterTemplate()">📋 Full Master Template</button>
          </div>

          <!-- Instructions -->
          <div class="glass-panel" style="padding:12px 16px;margin-top:12px;font-size:0.8rem;color:var(--text-muted)">
            <strong style="color:var(--text-main)">📌 Import Rules:</strong>
            <ul style="margin-top:6px;padding-left:18px;line-height:1.8">
              <li>Row 1 must be the header row with exact column names</li>
              <li>Students: matched by Mobile — duplicates will update existing</li>
              <li>Teachers: matched by Name or Mobile — duplicates will update</li>
              <li>Fees/Salary: always appended (no duplicate check)</li>
              <li>Topics/Tasks/Internships: always appended as new records</li>
            </ul>
          </div>

          <!-- Progress -->
          <div id="importProgressWrap" style="display:none;margin-top:16px">
            <div style="font-size:0.85rem;color:var(--text-muted);margin-bottom:8px" id="importProgressLabel">Reading file...</div>
            <div style="background:var(--glass-bg-ultra-light);border-radius:999px;height:8px;overflow:hidden">
              <div id="importProgressBar" style="height:100%;background:var(--primary);width:0%;transition:width 0.4s;border-radius:999px"></div>
            </div>
          </div>

          <!-- Results -->
          <div id="importResultArea" style="margin-top:16px"></div>
        </div>
      </div>
    </div>`;
    document.body.appendChild(el.firstElementChild);
  }

  function _dragOver(e) {
    e.preventDefault();
    document.getElementById('importDropZone').style.borderColor = 'var(--accent)';
  }

  function _drop(e) {
    e.preventDefault();
    document.getElementById('importDropZone').style.borderColor = 'var(--primary)';
    const file = e.dataTransfer.files[0];
    if (file) _handleFileSelect(file);
  }

  async function _handleFileSelect(file) {
    if (!file) return;
    if (!window.XLSX) {
      Toast.error('SheetJS not loaded. Please refresh.');
      return;
    }

    const prog = document.getElementById('importProgressWrap');
    const bar = document.getElementById('importProgressBar');
    const label = document.getElementById('importProgressLabel');
    prog.style.display = 'block';
    label.textContent = `Reading "${file.name}"...`;
    bar.style.width = '20%';

    try {
      const result = await readFile(file);
      bar.style.width = '100%';
      label.textContent = 'Import complete!';
      renderResults(result);
      DB.save && DB.save();
      if (typeof renderStudentList === 'function') renderStudentList();
      if (typeof renderTeacherList === 'function') renderTeacherList();
    } catch (err) {
      label.textContent = 'Error: ' + err.message;
      bar.style.background = 'var(--danger)';
      Toast.error('Import failed: ' + err.message);
    }
  }

  function renderResults(result) {
    const area = document.getElementById('importResultArea');
    if (!result.results || !result.results.length) {
      area.innerHTML = `<div style="color:var(--warning);padding:12px">No recognised sheets found in the workbook.</div>`;
      return;
    }

    const totalAdded = result.results.reduce((s, r) => s + r.added, 0);
    const totalUpdated = result.results.reduce((s, r) => s + r.updated, 0);

    area.innerHTML = `
    <div class="glass-panel" style="padding:12px 16px;margin-bottom:12px;background:var(--glass-bg-ultra-light)">
      <div style="font-weight:700;color:var(--text-main);margin-bottom:8px">✅ Import Complete — ${result.sheets.length} sheet(s) processed</div>
      <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:0.82rem">
        <span style="color:var(--success)">➕ ${totalAdded} records added</span>
        <span style="color:var(--primary)">✏️ ${totalUpdated} records updated</span>
      </div>
    </div>
    ${result.results.map(r => `
    <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border-radius:var(--radius-sm);margin-bottom:6px;background:var(--glass-bg-ultra-light);border:1px solid var(--glass-border)">
      <span style="font-weight:600;font-size:0.88rem">${r.sheet}</span>
      <div style="display:flex;gap:12px;font-size:0.8rem">
        ${r.added ? `<span style="color:var(--success)">+${r.added} added</span>` : ''}
        ${r.updated ? `<span style="color:var(--primary)">↺ ${r.updated} updated</span>` : ''}
        ${r.skipped ? `<span style="color:var(--warning)">⚠ ${r.skipped} skipped</span>` : ''}
      </div>
    </div>`).join('')}
    <button class="btn btn-sm btn-ghost w-full" style="margin-top:8px" onclick="Modal.close('excelImportModal');location.reload()">🔄 Reload Page to See Changes</button>
    `;
  }

  // ---- Download template workbooks ----
  function downloadTemplate(sheetName) {
    if (!window.XLSX) { Toast.error('SheetJS not loaded'); return; }
    const config = SHEET_MAPS[sheetName];
    if (!config) return;
    const headers = Object.keys(config.columns);
    const ws = XLSX.utils.aoa_to_sheet([headers]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, sheetName);
    XLSX.writeFile(wb, `CC_${sheetName}_Import_Template.xlsx`);
    Toast.success(`${sheetName} template downloaded`);
  }

  function downloadMasterTemplate() {
    if (!window.XLSX) { Toast.error('SheetJS not loaded'); return; }
    const wb = XLSX.utils.book_new();
    Object.entries(SHEET_MAPS).forEach(([sheetName, config]) => {
      const headers = Object.keys(config.columns);
      const ws = XLSX.utils.aoa_to_sheet([headers]);
      XLSX.utils.book_append_sheet(wb, ws, sheetName);
    });
    XLSX.writeFile(wb, `CC_Master_Import_Template.xlsx`);
    Toast.success('Master import template downloaded (all sheets)');
  }

  return {
    openImportModal,
    downloadTemplate,
    downloadMasterTemplate,
    _dragOver,
    _drop,
    _handleFileSelect,
  };
})();

window.ExcelImport = ExcelImport;

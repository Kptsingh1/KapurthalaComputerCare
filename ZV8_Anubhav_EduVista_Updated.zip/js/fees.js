/* ==========================================================================
   FEES.JS — Fees Management
   ========================================================================== */

let currentStudentId = null;
let currentFeeCourseStatus = 'Continue';
let feeViewMode = AcademyView ? AcademyView.get('fees_students', 'list') : 'list';

function initFeesPage() {
  const session = Auth.requireAuth(['admin','teacher']);
  if (!session) return;
  populateCourseStatusSelect('feeCourseStatusFilter', currentFeeCourseStatus, true);
  enhanceFeesControls();
  const statusFilter = document.getElementById('feeCourseStatusFilter');
  if (statusFilter) {
    statusFilter.value = currentFeeCourseStatus;
    statusFilter.addEventListener('change', () => {
      currentFeeCourseStatus = statusFilter.value || 'All';
      currentStudentId = null;
      clearFeesPanel();
      renderStudentSelector();
    });
  }
  renderStudentSelector();
  bindPaymentForm();
}

function enhanceFeesControls() {
  const tablePanel = document.getElementById('allFeesTableBody')?.closest('.glass-panel');
  if (tablePanel) tablePanel.classList.add('fee-view-panel');
  const header = tablePanel?.querySelector('.section-header');
  if (header && !document.getElementById('feeAdvancedFilters')) {
    header.insertAdjacentHTML('afterend', `
      <div class="academy-filter-panel" id="feeAdvancedFilters" style="margin:14px 0 0" data-no-auto-enhance="true">
        <div class="academy-filter-grid">
          <div class="search-wrapper">
            <span class="search-icon">&#128269;</span>
            <input type="search" id="feeSearch" class="form-control" placeholder="Search student, mobile, course, batch">
          </div>
          <select id="feeGenderFilter" class="form-control">
            <option value="All">All Boys & Girls</option>
            <option value="Male">Boys / Male</option>
            <option value="Female">Girls / Female</option>
          </select>
          <select id="feeBatchFilter" class="form-control">${AcademyFilters.batchOptions()}</select>
          <select id="feeCourseFilter" class="form-control">${AcademyFilters.coursesOptions()}</select>
          <select id="feeStatusFilter" class="form-control">${AcademyFilters.feeStatusOptions()}</select>
          <select id="feeDayFilter" class="form-control">${AcademyFilters.dayOptions()}</select>
          <input type="date" id="feeDateFrom" class="form-control" title="Admission from">
          <input type="date" id="feeDateTo" class="form-control" title="Admission to">
          <button type="button" class="btn btn-secondary filter-clear-btn" onclick="clearFeeFilters()">Clear Filters</button>
        </div>
      </div>
    `);
  }
  const tableContainer = tablePanel?.querySelector('.table-container');
  if (tableContainer) tableContainer.classList.add('fee-table-scroll');
  if (tableContainer && !document.getElementById('feeViewToolbar')) {
    tableContainer.insertAdjacentHTML('beforebegin', AcademyView.toolbarMarkup('fees_students', feeViewMode, 'Fees view', 'feeRecordCount', '0 students'));
    const toolbar = document.querySelector('[data-view-toolbar="fees_students"]');
    if (toolbar) toolbar.id = 'feeViewToolbar';
    AcademyView.bind(toolbar, 'fees_students', mode => {
      feeViewMode = mode;
      renderStudentSelector();
    });
  }
  if (tableContainer && !document.getElementById('feeCardsGrid')) {
    tableContainer.insertAdjacentHTML('afterend', '<div id="feeCardsGrid" class="fee-card-grid fee-view-grid" style="display:none"></div>');
  }
  ['feeSearch','feeGenderFilter','feeBatchFilter','feeCourseFilter','feeStatusFilter','feeDayFilter','feeDateFrom','feeDateTo'].forEach(id => {
    const el = document.getElementById(id);
    if (!el || el.dataset.boundFeeFilter === '1') return;
    el.dataset.boundFeeFilter = '1';
    const refresh = () => { currentStudentId = null; clearFeesPanel(); renderStudentSelector(); };
    el.addEventListener('input', refresh);
    el.addEventListener('change', refresh);
  });
}

function getFilteredFeeStudents() {
  return DB.filterStudents({
    status: currentFeeCourseStatus,
    gender: document.getElementById('feeGenderFilter')?.value || 'All',
    batch: document.getElementById('feeBatchFilter')?.value || 'All',
    courseId: document.getElementById('feeCourseFilter')?.value || 'All',
    feesStatus: document.getElementById('feeStatusFilter')?.value || 'All',
    day: document.getElementById('feeDayFilter')?.value || 'All',
    dateFrom: document.getElementById('feeDateFrom')?.value || '',
    dateTo: document.getElementById('feeDateTo')?.value || '',
    query: document.getElementById('feeSearch')?.value || '',
  });
}

function clearFeeFilters() {
  ['feeSearch','feeDateFrom','feeDateTo'].forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
  [['feeGenderFilter','All'],['feeBatchFilter','All'],['feeCourseFilter','All'],['feeStatusFilter','All'],['feeDayFilter','All'],['feeCourseStatusFilter','All']].forEach(([id, value]) => {
    const el = document.getElementById(id);
    if (el) el.value = value;
  });
  currentFeeCourseStatus = 'All';
  currentStudentId = null;
  clearFeesPanel();
  renderStudentSelector();
}

function renderStudentSelector() {
  enhanceFeesControls();
  const students = getFilteredFeeStudents();

  // Summary cards
  renderFeesSummary(students);
  renderAllStudentsFees(students);

  const select = document.getElementById('feeStudentSelect');
  if (!select) return;

  select.innerHTML = `<option value="">-- Select a Student --</option>` +
    students.map(s=>`<option value="${s.id}">${s.name} — ${s.course||'No Course'} — ${s.courseStatus||'Status'}</option>`).join('');

  select.onchange = ()=>{
    currentStudentId = select.value || null;
    if (currentStudentId) renderStudentFees(currentStudentId);
    else clearFeesPanel();
  };

}

function renderFeesSummary(students) {
  let totalFees=0, paidFees=0;
  students.forEach(s=>{
    totalFees += s.totalFees||0;
    paidFees  += DB.paidFees(s.id);
  });
  const pending = totalFees - paidFees;
  const el = id => document.getElementById(id);
  const setTxt = (id,v) => { const e=el(id); if(e) e.textContent=v; };
  setTxt('feesTotalAll',    Fmt.currency(totalFees));
  setTxt('feesPaidAll',     Fmt.currency(paidFees));
  setTxt('feesPendingAll',  Fmt.currency(pending));
  setTxt('feesBalanceAll',  Fmt.currency(pending));
  const rate = totalFees ? Math.round((paidFees/totalFees)*100) : 0;
  setTxt('feesCollectionRate', rate+'%');
  const bar = el('feesCollectionBar');
  if(bar) bar.style.width = rate+'%';
}

function renderAllStudentsFees(students) {
  const tbody = document.getElementById('allFeesTableBody');
  if (!tbody) return;
  const tablePanel = tbody.closest('.glass-panel');
  const tableContainer = tbody.closest('.table-container');
  let cardsGrid = document.getElementById('feeCardsGrid');
  if (!cardsGrid) {
    enhanceFeesControls();
    cardsGrid = document.getElementById('feeCardsGrid');
  }
  const countEl = document.getElementById('feeRecordCount');
  if (countEl) countEl.textContent = `${students.length} student${students.length === 1 ? '' : 's'}`;
  if (tableContainer) tableContainer.style.display = feeViewMode === 'grid' ? 'none' : '';
  if (cardsGrid) {
    cardsGrid.style.display = feeViewMode === 'grid' ? 'grid' : 'none';
    if (feeViewMode === 'grid') renderAllStudentsFeesCards(students, cardsGrid);
  }
  tbody.innerHTML = students.map(s=>{
    const paid = DB.paidFees(s.id);
    const balance = (s.totalFees||0)-paid;
    const pct = s.totalFees ? Math.round((paid/s.totalFees)*100) : 0;
    const statusClass = balance<=0?'badge-success':balance<(s.totalFees*0.5)?'badge-warning':'badge-danger';
    const statusText = balance<=0?'Cleared':balance<(s.totalFees*0.5)?'Partial':'Pending';
    return `<tr>
      <td style="min-width:160px"><div style="display:flex;align-items:center;gap:8px">
        ${ProfileImage.avatar(s, '', 'width:28px;height:28px;font-size:0.7rem;flex-shrink:0')}
        <span style="font-size:0.88rem;font-weight:600;white-space:nowrap">${s.name}</span></div></td>
      <td style="font-size:0.82rem;min-width:130px;white-space:nowrap">${s.course||'—'}</td>
      <td style="font-weight:600;white-space:nowrap">${Fmt.currency(s.totalFees||0)}</td>
      <td style="color:var(--success);font-weight:600;white-space:nowrap">${Fmt.currency(paid)}</td>
      <td style="color:${balance>0?'var(--danger)':'var(--success)'};font-weight:600;white-space:nowrap">${Fmt.currency(balance)}</td>
      <td style="min-width:120px">
        <div style="display:flex;align-items:center;gap:6px">
          <div class="progress-bar-wrap" style="flex:1;min-width:60px"><div class="progress-bar-fill" style="width:${pct}%"></div></div>
          <span style="font-size:0.75rem;white-space:nowrap">${pct}%</span>
        </div>
      </td>
      <td><span class="badge ${statusClass}">${statusText}</span></td>
      <td style="white-space:nowrap">
        <button class="btn btn-sm btn-primary" onclick="selectStudentFees('${s.id}')">💳 Pay</button>
        <button class="btn btn-sm btn-ghost" onclick="printReceipt('${s.id}')">🖨 Receipt</button>
      </td>
    </tr>`;
  }).join('') || '<tr><td colspan="8" class="text-center text-muted" style="padding:30px">No students</td></tr>';
}

function renderAllStudentsFeesCards(students, container) {
  container.innerHTML = students.length ? students.map(s => {
    const fee = DB.studentFeeSummary(s);
    const statusClass = fee.balance <= 0 && fee.total > 0 ? 'badge-success' : fee.paid > 0 ? 'badge-warning' : 'badge-danger';
    return `<article class="fee-student-card">
      <div class="fee-card-top">
        <div style="display:flex;gap:10px;align-items:center;min-width:0">
          ${ProfileImage.avatar(s, '', 'width:42px;height:42px;font-size:0.82rem;flex-shrink:0')}
          <div style="min-width:0">
            <div class="person-title">${Fmt.escape(s.name)}</div>
            <div class="card-meta-line"><span>${Fmt.escape(s.course || '-')}</span><span>${Fmt.escape(s.batchNo || '-')}</span></div>
          </div>
        </div>
        <span class="badge ${statusClass}">${fee.status}</span>
      </div>
      <div class="detail-row"><span>Total</span><strong>${Fmt.currency(fee.total)}</strong></div>
      <div class="detail-row"><span>Paid</span><strong style="color:var(--success)">${Fmt.currency(fee.paid)}</strong></div>
      <div class="detail-row"><span>Balance</span><strong style="color:${fee.balance > 0 ? 'var(--danger)' : 'var(--success)'}">${Fmt.currency(fee.balance)}</strong></div>
      <div class="detail-row"><span>Days</span><strong>${Fmt.escape(s.day || '-')}</strong></div>
      <div class="progress-mini"><span style="width:${fee.percent}%"></span></div>
      <div class="card-actions">
        <button class="btn btn-sm btn-primary" onclick="selectStudentFees('${s.id}')">Pay</button>
        <button class="btn btn-sm btn-ghost" onclick="printReceipt('${s.id}')">Receipt</button>
      </div>
    </article>`;
  }).join('') : '<div class="empty-state"><p>No fee records found</p></div>';
}

function selectStudentFees(id) {
  currentStudentId = id;
  const select = document.getElementById('feeStudentSelect');
  if(select) select.value = id;
  renderStudentFees(id);
  document.getElementById('feesDetailPanel').scrollIntoView({behavior:'smooth'});
}

function renderStudentFees(studentId) {
  const student = DB.getStudent(studentId);
  if (!student) return;
  const feesData = DB.getFees(studentId);
  const paid = DB.paidFees(studentId);
  const balance = (student.totalFees||0)-paid;
  const pct = student.totalFees ? Math.round((paid/student.totalFees)*100) : 0;

  const panel = document.getElementById('feesDetailPanel');
  if (!panel) return;
  panel.style.display='';

  // Student info
  const el = id=>document.getElementById(id);
  const set = (id,v)=>{ const e=el(id); if(e) e.textContent=v; };
  set('feeStudentName', student.name);
  set('feeStudentCourse', student.course||'—');
  set('feeStudentBatch', student.batchNo||'—');
  set('feeTotalAmt',   Fmt.currency(student.totalFees||0));
  set('feePaidAmt',    Fmt.currency(paid));
  set('feeBalanceAmt', Fmt.currency(balance));
  set('feePendingAmt', Fmt.currency(balance));
  const bar=el('feeProgressBar'); if(bar) bar.style.width=pct+'%';
  set('feeProgressPct', pct+'%');

  // Pre-fill payment form
  const amtEl=el('payAmount');
  if(amtEl && balance>0) amtEl.value=balance;

  // Notes
  const notesEl=el('feeNotes');
  if(notesEl) notesEl.value=feesData.notes||'';

  // Ledger
  renderLedger(feesData.payments||[], student);
}

function renderLedger(payments, student) {
  const container = document.getElementById('ledgerContainer');
  if (!container) return;
  if(!payments.length){
    container.innerHTML='<div class="empty-state" style="padding:30px"><div class="empty-state-icon">💳</div><p>No payments recorded yet</p></div>';
    return;
  }
  let runningBalance = student.totalFees||0;
  container.innerHTML = `
    <div style="display:grid;grid-template-columns:auto auto 1fr auto auto auto;gap:0;font-size:0.82rem">
      <div style="display:contents"><div style="font-weight:700;color:var(--text-muted);padding:8px 12px;border-bottom:1px solid var(--glass-border)">#</div>
      <div style="font-weight:700;color:var(--text-muted);padding:8px 12px;border-bottom:1px solid var(--glass-border)">Date</div>
      <div style="font-weight:700;color:var(--text-muted);padding:8px 12px;border-bottom:1px solid var(--glass-border)">Mode</div>
      <div style="font-weight:700;color:var(--text-muted);padding:8px 12px;border-bottom:1px solid var(--glass-border)">Amount</div>
      <div style="font-weight:700;color:var(--text-muted);padding:8px 12px;border-bottom:1px solid var(--glass-border)">Balance</div>
      <div style="font-weight:700;color:var(--text-muted);padding:8px 12px;border-bottom:1px solid var(--glass-border)">Action</div>
      </div>
      ${[...payments].reverse().map((p,i)=>{
        runningBalance -= Number(p.amount)||0;
        return `<div style="display:contents">
          <div style="padding:10px 12px;border-bottom:1px solid var(--glass-border)">${payments.length-i}</div>
          <div style="padding:10px 12px;border-bottom:1px solid var(--glass-border)">${Fmt.date(p.date)}</div>
          <div style="padding:10px 12px;border-bottom:1px solid var(--glass-border)">${p.mode||'Cash'} ${p.note?`<span class="text-muted">(${p.note})</span>`:''}</div>
          <div style="padding:10px 12px;border-bottom:1px solid var(--glass-border);color:var(--success);font-weight:700">${Fmt.currency(p.amount)}</div>
          <div style="padding:10px 12px;border-bottom:1px solid var(--glass-border);color:${runningBalance>0?'var(--danger)':'var(--success)'}">${Fmt.currency(Math.max(0,runningBalance))}</div>
          <div style="padding:10px 12px;border-bottom:1px solid var(--glass-border)"><button class="btn btn-sm btn-danger" onclick="deletePayment('${p.id}')">🗑</button></div>
        </div>`;
      }).join('')}
    </div>`;
}

function deletePayment(payId) {
  if(!currentStudentId) return;
  if(!confirm('Delete this payment record?')) return;
  const data = DB.getFees(currentStudentId);
  data.payments = (data.payments||[]).filter(p=>p.id!==payId);
  DB.saveFees(currentStudentId, data);
  Toast.success('Payment deleted');
  renderStudentFees(currentStudentId);
  renderAllStudentsFees(getFilteredFeeStudents());
  renderFeesSummary(getFilteredFeeStudents());
}

function clearFeesPanel() {
  const panel = document.getElementById('feesDetailPanel');
  if(panel) panel.style.display='none';
}

function bindPaymentForm() {
  const form = document.getElementById('paymentForm');
  if (!form) return;
  form.addEventListener('submit', e=>{
    e.preventDefault();
    if (!currentStudentId){ Toast.warning('Please select a student'); return; }
    const amount = Number(document.getElementById('payAmount').value)||0;
    if (amount<=0){ Toast.warning('Enter a valid payment amount'); return; }
    const mode = document.getElementById('payMode').value;
    const note = document.getElementById('payNote').value;
    const date = document.getElementById('payDate').value || new Date().toISOString().slice(0,10);

    DB.addPayment(currentStudentId, { amount, mode, note, date });

    // Save notes
    const notesEl = document.getElementById('feeNotes');
    if(notesEl){
      const data = DB.getFees(currentStudentId);
      data.notes = notesEl.value;
      DB.saveFees(currentStudentId, data);
    }

    Toast.success(`Payment of ${Fmt.currency(amount)} recorded!`);
    renderStudentFees(currentStudentId);
    renderAllStudentsFees(getFilteredFeeStudents());
    renderFeesSummary(getFilteredFeeStudents());
    showAutoSave();
    form.reset();
  });
}

function printReceipt(studentId) {
  const sid = studentId || currentStudentId;
  if (!sid){ Toast.warning('Select a student first'); return; }
  const student = DB.getStudent(sid);
  if (!student) return;
  const feesData = DB.getFees(sid);
  const paid = DB.paidFees(sid);
  const balance = (student.totalFees||0)-paid;
  const settings = DB.getSettings();
  const lastPay = (feesData.payments||[]).slice(-1)[0];

  const html = `
    <div style="border:2px solid #047857;border-radius:8px;padding:24px;max-width:600px;margin:0 auto">
      <div style="text-align:center;border-bottom:2px dashed #047857;padding-bottom:16px;margin-bottom:16px">
        <h1 style="color:#047857;font-size:1.4rem;margin-bottom:4px">${settings.academyName}</h1>
        <p style="color:#666;font-size:11px">${settings.address}</p>
        <p style="color:#666;font-size:11px">${settings.mobile} | ${settings.email}</p>
        <h2 style="margin-top:12px;font-size:1rem;background:#047857;color:#fff;padding:6px;border-radius:4px">FEES RECEIPT</h2>
      </div>
      <table style="width:100%;font-size:13px">
        <tr><td><strong>Student Name:</strong></td><td>${student.name}</td><td><strong>Receipt No:</strong></td><td>#${Date.now().toString().slice(-6)}</td></tr>
        <tr><td><strong>Course:</strong></td><td>${student.course||'—'}</td><td><strong>Date:</strong></td><td>${Fmt.date(new Date().toISOString())}</td></tr>
        <tr><td><strong>Batch:</strong></td><td>${student.batchNo||'—'}</td><td><strong>Father's Name:</strong></td><td>${student.fatherName||'—'}</td></tr>
        <tr><td><strong>Mobile:</strong></td><td>${student.mobile||'—'}</td><td><strong>Duration:</strong></td><td>${student.duration||'—'}</td></tr>
      </table>
      <div style="margin-top:16px;border:1px solid #ccc;border-radius:4px;overflow:hidden">
        <table style="width:100%;font-size:13px;border-collapse:collapse">
          <thead><tr style="background:#047857;color:#fff"><th style="padding:8px">Description</th><th style="padding:8px">Amount</th></tr></thead>
          <tbody>
            <tr><td style="padding:8px;border:1px solid #eee">Total Course Fees</td><td style="padding:8px;border:1px solid #eee">${Fmt.currency(student.totalFees||0)}</td></tr>
            <tr><td style="padding:8px;border:1px solid #eee">Amount Paid</td><td style="padding:8px;border:1px solid #eee;color:green">${Fmt.currency(paid)}</td></tr>
            <tr style="background:#fff3cd"><td style="padding:8px;border:1px solid #eee"><strong>Balance Due</strong></td><td style="padding:8px;border:1px solid #eee;color:${balance>0?'red':'green'};font-weight:700">${Fmt.currency(balance)}</td></tr>
          </tbody>
        </table>
      </div>
      ${lastPay?`<p style="margin-top:12px;font-size:12px"><strong>Last Payment:</strong> ${Fmt.currency(lastPay.amount)} on ${Fmt.date(lastPay.date)} via ${lastPay.mode||'Cash'}</p>`:''}
      <div style="display:flex;justify-content:space-between;margin-top:24px;padding-top:16px;border-top:1px dashed #ccc">
        <div style="font-size:12px;color:#666">Student Signature<br><br><br>_______________</div>
        <div style="font-size:12px;color:#666">Authorized Signature<br><br><br>_______________</div>
      </div>
    </div>`;
  Exporter.toPDF_simple('Fees Receipt — '+student.name, html);
}

function saveNotes() {
  if(!currentStudentId) return;
  const notesEl = document.getElementById('feeNotes');
  if(!notesEl) return;
  const data = DB.getFees(currentStudentId);
  data.notes = notesEl.value;
  DB.saveFees(currentStudentId, data);
  Toast.success('Notes saved!');
}

document.addEventListener('DOMContentLoaded', initFeesPage);

/* ==========================================================================
   GALLERY.JS — Gallery Management
   ========================================================================== */

let lightboxIndex = 0;
let galleryItems = [];

function initGalleryPage() {
  const session = Auth.requireAuth(['admin','teacher']);
  if (!session) return;
  galleryItems = DB.getGallery();
  renderGallery();
  bindGalleryForms();
}

function renderGallery(filter='') {
  galleryItems = DB.getGallery();
  const container = document.getElementById('galleryGrid');
  if (!container) return;

  let items = galleryItems;
  if (filter) items = items.filter(g=> g.title.toLowerCase().includes(filter) || (g.tags||'').toLowerCase().includes(filter));

  if (!items.length) {
    container.innerHTML = `<div style="grid-column:1/-1" class="empty-state">
      <div class="empty-state-icon">🖼️</div>
      <h3>No images yet</h3>
      <p>Upload your first photo</p>
      <button class="btn btn-primary" onclick="Modal.open('uploadModal')" style="margin-top:12px">📸 Upload Image</button>
    </div>`;
    return;
  }

  container.innerHTML = items.map((g,i)=>`
    <div class="gallery-item" onclick="openLightbox(${galleryItems.indexOf(g)})">
      ${g.dataUrl
        ? `<img src="${g.dataUrl}" alt="${g.title}" loading="lazy">`
        : `<div class="gallery-item-placeholder"><div style="font-size:2.5rem">🖼️</div><span>${g.title}</span></div>`}
      <div class="gallery-overlay">
        <div class="item-title">${g.title}</div>
        ${g.category?`<div style="font-size:0.7rem;color:rgba(255,255,255,0.7)">${g.category}</div>`:''}
        <div class="item-actions">
          <button class="btn btn-sm btn-secondary" onclick="event.stopPropagation();editGalleryItem('${g.id}')">✏️</button>
          <button class="btn btn-sm btn-danger" onclick="event.stopPropagation();deleteGalleryItem('${g.id}')">🗑</button>
        </div>
      </div>
      ${g.uploadedAt?`<div style="position:absolute;top:8px;right:8px;background:rgba(0,0,0,0.6);border-radius:4px;padding:2px 6px;font-size:0.65rem;color:#fff">${Fmt.date(g.uploadedAt)}</div>`:''}
    </div>
  `).join('');
}

function bindGalleryForms() {
  const uploadForm = document.getElementById('uploadForm');
  if (uploadForm) {
    uploadForm.addEventListener('submit', e=>{
      e.preventDefault();
      const title    = document.getElementById('imgTitle').value.trim();
      const category = document.getElementById('imgCategory').value.trim();
      const tags     = document.getElementById('imgTags').value.trim();
      const desc     = document.getElementById('imgDesc').value.trim();
      if (!title) { Toast.warning('Title is required'); return; }

      const fileInput = document.getElementById('imgFile');
      if (fileInput && fileInput.files[0]) {
        const reader = new FileReader();
        reader.onload = ev=>{
          DB.addGalleryItem({ title, category, tags, desc, dataUrl:ev.target.result });
          renderGallery();
          Modal.close('uploadModal');
          uploadForm.reset();
          clearPreview();
          Toast.success('Image uploaded!');
          showAutoSave();
        };
        reader.readAsDataURL(fileInput.files[0]);
      } else {
        DB.addGalleryItem({ title, category, tags, desc, dataUrl:'' });
        renderGallery();
        Modal.close('uploadModal');
        uploadForm.reset();
        Toast.success('Gallery item added!');
        showAutoSave();
      }
    });
  }

  // File preview
  const fileInput = document.getElementById('imgFile');
  if (fileInput) {
    fileInput.addEventListener('change', ()=>{
      if(fileInput.files[0]){
        const reader=new FileReader();
        reader.onload=ev=>{ const prev=document.getElementById('imgPreview'); if(prev){prev.src=ev.target.result;prev.style.display='block';} };
        reader.readAsDataURL(fileInput.files[0]);
      }
    });
  }

  // Drag & Drop
  const dropArea = document.getElementById('dropArea');
  if (dropArea) {
    ['dragenter','dragover'].forEach(ev=>dropArea.addEventListener(ev,e=>{e.preventDefault();dropArea.classList.add('dragover');}));
    ['dragleave','drop'].forEach(ev=>dropArea.addEventListener(ev,e=>{e.preventDefault();dropArea.classList.remove('dragover');}));
    dropArea.addEventListener('drop',e=>{
      const files=e.dataTransfer.files;
      if(files[0]&&fileInput){ fileInput.files=files; fileInput.dispatchEvent(new Event('change')); }
    });
  }

  // Search
  const search = document.getElementById('gallerySearch');
  if(search) search.addEventListener('input', ()=>renderGallery(search.value.toLowerCase()));

  // Edit form
  const editForm = document.getElementById('editGalleryForm');
  if(editForm){
    editForm.addEventListener('submit', e=>{
      e.preventDefault();
      const id = document.getElementById('editGalleryId').value;
      DB.updateGalleryItem(id, {
        title:    document.getElementById('editImgTitle').value,
        category: document.getElementById('editImgCategory').value,
        tags:     document.getElementById('editImgTags').value,
        desc:     document.getElementById('editImgDesc').value,
      });
      renderGallery();
      Modal.close('editGalleryModal');
      Toast.success('Updated!');
    });
  }
}

function editGalleryItem(id) {
  const item = DB.getGallery().find(g=>g.id===id);
  if (!item) return;
  document.getElementById('editGalleryId').value = id;
  document.getElementById('editImgTitle').value = item.title||'';
  document.getElementById('editImgCategory').value = item.category||'';
  document.getElementById('editImgTags').value = item.tags||'';
  document.getElementById('editImgDesc').value = item.desc||'';
  Modal.open('editGalleryModal');
}

function deleteGalleryItem(id) {
  if (!confirm('Delete this image?')) return;
  DB.deleteGalleryItem(id);
  renderGallery();
  Toast.success('Deleted!');
}

function openLightbox(idx) {
  galleryItems = DB.getGallery();
  lightboxIndex = idx;
  const item = galleryItems[idx];
  if (!item) return;
  const lb = document.getElementById('lightbox');
  const img = document.getElementById('lightboxImg');
  const title = document.getElementById('lightboxTitle');
  const desc = document.getElementById('lightboxDesc');
  if(lb) lb.style.display='flex';
  if(img) { img.src=item.dataUrl||''; img.style.display=item.dataUrl?'block':'none'; }
  if(title) title.textContent = item.title||'';
  if(desc) desc.textContent = item.desc||'';
}

function closeLightbox() {
  const lb = document.getElementById('lightbox');
  if(lb) lb.style.display='none';
}

function lightboxPrev() {
  galleryItems = DB.getGallery();
  lightboxIndex = (lightboxIndex-1+galleryItems.length)%galleryItems.length;
  openLightbox(lightboxIndex);
}

function lightboxNext() {
  galleryItems = DB.getGallery();
  lightboxIndex = (lightboxIndex+1)%galleryItems.length;
  openLightbox(lightboxIndex);
}

function clearPreview() {
  const prev = document.getElementById('imgPreview');
  if(prev){prev.src='';prev.style.display='none';}
}

document.addEventListener('DOMContentLoaded', initGalleryPage);

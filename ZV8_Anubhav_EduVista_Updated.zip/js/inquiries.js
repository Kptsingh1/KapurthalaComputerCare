/* ==========================================================================
   INQUIRIES.JS - Admission inquiry and lead management
   ========================================================================== */

let editingInquiryId = null;
let inquiryViewMode = AcademyView ? AcademyView.get('inquiries_page', 'grid') : 'grid';

const INQUIRY_STATUSES = ['All','Open','Follow Up','Demo Scheduled','Joined','Converted','Closed','Lost'];
const INQUIRY_PRIORITIES = ['All','High','Medium','Low'];
const INQUIRY_TIMES = ['9:00 AM - 10:00 AM','10:00 AM - 11:00 AM','11:00 AM - 12:00 PM','12:00 PM - 1:00 PM','1:00 PM - 2:00 PM','2:00 PM - 3:00 PM','3:00 PM - 4:00 PM','4:00 PM - 5:00 PM'];
const INQUIRY_DAYS = ['Mon-Fri','Mon-Sat','Tue-Thu','Mon-Wed-Fri','Tue-Thu-Sat','Daily','Weekend'];

function initInquiriesPage() {
  const session = Auth.requireAuth(['admin','teacher']);
  if (!session) return;
  populateInquiryControls();
  bindInquiryFilters();
  bindInquiryForm();
  renderInquiries();
}

function populateInquiryControls() {
  const keep = (el, html, fallback='All') => {
    if (!el) return;
    const old = el.value || fallback;
    el.innerHTML = html;
    el.value = [...el.options].some(o => o.value === old) ? old : fallback;
  };
  const status = document.getElementById('inqStatusFilter');
  keep(status, INQUIRY_STATUSES.map(x => `<option value="${x}">${x === 'All' ? 'All Status' : x}</option>`).join(''));
  const course = document.getElementById('inqCourseFilter');
  keep(course, AcademyFilters.coursesOptions());
  const batch = document.getElementById('inqBatchFilter');
  keep(batch, AcademyFilters.batchOptions());
  const source = document.getElementById('inqSourceFilter');
  keep(source, AcademyFilters.optionList(DB.getInquiries().map(x => x.source), source?.value || 'All', 'All Sources'));
  const priority = document.getElementById('inqPriorityFilter');
  keep(priority, INQUIRY_PRIORITIES.map(x => `<option value="${x}">${x === 'All' ? 'All Priority' : x}</option>`).join(''));

  const modalCourse = document.getElementById('inq_courseId');
  if (modalCourse) {
    modalCourse.innerHTML = '<option value="">-- Select Course --</option>' + DB.getCourses().map(c => `<option value="${c.id}">${Fmt.escape(c.name)} (${Fmt.currency(c.fees || 0)})</option>`).join('');
    modalCourse.onchange = () => {
      const c = DB.getCourses().find(item => item.id === modalCourse.value);
      const fees = document.getElementById('inq_quotedFees');
      if (fees && c) fees.value = c.fees || 0;
    };
  }
  const modalBatch = document.getElementById('inq_batchNo');
  if (modalBatch) modalBatch.innerHTML = AcademyFilters.batchOptions('All', '-- Select Batch --').replace('value="All"', 'value=""');
  const time = document.getElementById('inq_preferredTime');
  if (time) time.innerHTML = INQUIRY_TIMES.map(x => `<option>${x}</option>`).join('');
  const days = document.getElementById('inq_preferredDays');
  if (days) days.innerHTML = INQUIRY_DAYS.map(x => `<option>${x}</option>`).join('');

  const toggle = document.getElementById('inqViewToggle');
  if (toggle && !toggle.dataset.boundView) {
    toggle.dataset.boundView = '1';
    toggle.innerHTML = AcademyView.toggleMarkup('inquiries_page', inquiryViewMode, 'Inquiry view');
    AcademyView.bind(toggle, 'inquiries_page', mode => {
      inquiryViewMode = mode;
      renderInquiries();
    });
  }
}

function bindInquiryFilters() {
  ['inqSearch','inqStatusFilter','inqGenderFilter','inqCourseFilter','inqBatchFilter','inqSourceFilter','inqPriorityFilter','inqDateFrom','inqDateTo','inqFollowFrom','inqFollowTo'].forEach(id => {
    const el = document.getElementById(id);
    if (!el || el.dataset.boundInquiry === '1') return;
    el.dataset.boundInquiry = '1';
    el.addEventListener('input', renderInquiries);
    el.addEventListener('change', renderInquiries);
  });
}

function inquiryFilters() {
  const val = id => document.getElementById(id)?.value || '';
  return {
    query: val('inqSearch'),
    status: val('inqStatusFilter') || 'All',
    gender: val('inqGenderFilter') || 'All',
    courseId: val('inqCourseFilter') || 'All',
    batch: val('inqBatchFilter') || 'All',
    source: val('inqSourceFilter') || 'All',
    priority: val('inqPriorityFilter') || 'All',
    dateFrom: val('inqDateFrom'),
    dateTo: val('inqDateTo'),
    followFrom: val('inqFollowFrom'),
    followTo: val('inqFollowTo'),
  };
}

function getFilteredInquiries() {
  return DB.filterInquiries(inquiryFilters());
}

function clearInquiryFilters() {
  ['inqSearch','inqDateFrom','inqDateTo','inqFollowFrom','inqFollowTo'].forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
  ['inqStatusFilter','inqGenderFilter','inqCourseFilter','inqBatchFilter','inqSourceFilter','inqPriorityFilter'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = 'All';
  });
  renderInquiries();
}

function renderInquiryStats(all) {
  const today = new Date().toISOString().slice(0,10);
  const set = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value; };
  set('inqTotal', all.length);
  set('inqOpen', all.filter(x => ['Open','Follow Up','Demo Scheduled'].includes(x.status)).length);
  set('inqDue', all.filter(x => x.followUpDate && x.followUpDate <= today && !['Converted','Closed','Lost'].includes(x.status)).length);
  set('inqConverted', all.filter(x => x.status === 'Converted').length);
}

function renderInquiries() {
  populateInquiryControls();
  const all = DB.getInquiries();
  const rows = getFilteredInquiries();
  renderInquiryStats(all);
  const count = document.getElementById('inqRecordCount');
  if (count) count.textContent = `${rows.length} record${rows.length === 1 ? '' : 's'}`;
  const grid = document.getElementById('inquiryGrid');
  const list = document.getElementById('inquiryListPanel');
  if (grid) grid.style.display = inquiryViewMode === 'grid' ? 'grid' : 'none';
  if (list) list.style.display = inquiryViewMode === 'list' ? '' : 'none';
  renderInquiryGrid(rows);
  renderInquiryTable(rows);
}

function statusBadge(status) {
  return {
    Open:'badge-info',
    'Follow Up':'badge-warning',
    'Demo Scheduled':'badge-primary',
    Joined:'badge-success',
    Converted:'badge-success',
    Closed:'badge-secondary',
    Lost:'badge-danger',
  }[status] || 'badge-info';
}

function priorityBadge(priority) {
  return { High:'badge-danger', Medium:'badge-warning', Low:'badge-success' }[priority] || 'badge-info';
}

function isFollowUpDue(item) {
  const today = new Date().toISOString().slice(0,10);
  return item.followUpDate && item.followUpDate <= today && !['Converted','Closed','Lost'].includes(item.status);
}

function renderInquiryGrid(rows) {
  const grid = document.getElementById('inquiryGrid');
  if (!grid) return;
  grid.innerHTML = rows.length ? rows.map(item => `
    <article class="inquiry-card ${isFollowUpDue(item) ? 'follow-up-due' : ''} ${item.status === 'Converted' ? 'converted-inquiry' : ''}">
      <div class="inquiry-card-top">
        <div style="display:flex;gap:10px;align-items:center;min-width:0">
          <div class="inquiry-icon">${item.gender === 'Female' ? '&#128103;' : '&#128102;'}</div>
          <div style="min-width:0">
            <div class="inquiry-title">${Fmt.escape(item.name)}</div>
            <div class="card-meta-line"><span>${Fmt.escape(item.mobile || '-')}</span><span>${Fmt.escape(item.source || '-')}</span></div>
          </div>
        </div>
        <span class="badge ${priorityBadge(item.priority)}">${Fmt.escape(item.priority || 'Medium')}</span>
      </div>
      <div class="inquiry-status-strip">
        <span class="badge ${statusBadge(item.status)}">${Fmt.escape(item.status || 'Open')}</span>
        ${isFollowUpDue(item) ? '<span class="badge badge-danger">Follow-up due</span>' : ''}
      </div>
      <div class="detail-row"><span>Course</span><strong>${Fmt.escape(item.course || '-')}</strong></div>
      <div class="detail-row"><span>Batch / Time</span><strong>${Fmt.escape((item.batchNo || '-') + ' / ' + (item.preferredTime || '-'))}</strong></div>
      <div class="detail-row"><span>Inquiry</span><strong>${Fmt.date(item.inquiryDate)}</strong></div>
      <div class="detail-row"><span>Follow Up</span><strong>${Fmt.date(item.followUpDate)}</strong></div>
      <div class="detail-row"><span>Fees</span><strong>${Fmt.currency(item.quotedFees || 0)}</strong></div>
      ${item.notes ? `<div class="detail-row"><span>Notes</span><strong>${Fmt.escape(item.notes)}</strong></div>` : ''}
      <div class="card-actions">
        <button class="btn btn-sm btn-primary" onclick="editInquiry('${item.id}')">Edit</button>
        <button class="btn btn-sm btn-secondary" onclick="quickInquiryStatus('${item.id}','Follow Up')">Follow Up</button>
        ${item.status !== 'Converted' ? `<button class="btn btn-sm btn-success" onclick="convertInquiry('${item.id}')">Convert</button>` : ''}
        <button class="btn btn-sm btn-danger" onclick="deleteInquiry('${item.id}')">Delete</button>
      </div>
    </article>`).join('') : '<div class="empty-state"><div class="empty-state-icon">&#128222;</div><p>No inquiries match filters</p></div>';
}

function renderInquiryTable(rows) {
  const tbody = document.getElementById('inquiryTableBody');
  if (!tbody) return;
  tbody.innerHTML = rows.length ? rows.map(item => `
    <tr>
      <td><div style="font-weight:700">${Fmt.escape(item.name)}</div><div class="text-muted">${Fmt.escape(item.mobile || '-')} | ${Fmt.escape(item.gender || '-')}</div></td>
      <td>${Fmt.escape(item.course || '-')}<div class="text-muted">${Fmt.escape(item.batchNo || '-')}</div></td>
      <td>${Fmt.date(item.followUpDate)}${isFollowUpDue(item) ? '<div><span class="badge badge-danger">Due</span></div>' : ''}</td>
      <td>${Fmt.escape(item.source || '-')}</td>
      <td><span class="badge ${statusBadge(item.status)}">${Fmt.escape(item.status || 'Open')}</span></td>
      <td style="white-space:nowrap">
        <button class="btn btn-sm btn-primary" onclick="editInquiry('${item.id}')">Edit</button>
        ${item.status !== 'Converted' ? `<button class="btn btn-sm btn-success" onclick="convertInquiry('${item.id}')">Convert</button>` : ''}
        <button class="btn btn-sm btn-danger" onclick="deleteInquiry('${item.id}')">Delete</button>
      </td>
    </tr>`).join('') : '<tr><td colspan="6" class="text-center text-muted" style="padding:30px">No inquiries found</td></tr>';
}

function openInquiryModal() {
  editingInquiryId = null;
  document.getElementById('inquiryModalTitle').textContent = 'Add Inquiry';
  document.getElementById('inquiryForm').reset();
  document.getElementById('inq_inquiryDate').value = new Date().toISOString().slice(0,10);
  Modal.open('inquiryModal');
}

function editInquiry(id) {
  const item = DB.getInquiry(id);
  if (!item) return;
  editingInquiryId = id;
  document.getElementById('inquiryModalTitle').textContent = 'Edit Inquiry - ' + item.name;
  ['name','gender','mobile','altMobile','email','guardianName','courseId','batchNo','preferredTime','preferredDays','source','status','priority','inquiryDate','followUpDate','expectedJoinDate','quotedFees','address','notes'].forEach(field => {
    const el = document.getElementById('inq_' + field);
    if (el) el.value = item[field] || '';
  });
  Modal.open('inquiryModal');
}

function bindInquiryForm() {
  const form = document.getElementById('inquiryForm');
  if (!form) return;
  form.addEventListener('submit', e => {
    e.preventDefault();
    const get = id => document.getElementById('inq_' + id)?.value || '';
    const course = DB.getCourses().find(c => c.id === get('courseId')) || {};
    const item = {
      name:get('name').trim(),
      gender:get('gender'),
      mobile:get('mobile').trim(),
      altMobile:get('altMobile'),
      email:get('email'),
      guardianName:get('guardianName'),
      courseId:get('courseId'),
      course:course.name || '',
      batchNo:get('batchNo'),
      preferredTime:get('preferredTime'),
      preferredDays:get('preferredDays'),
      source:get('source'),
      status:get('status') || 'Open',
      priority:get('priority') || 'Medium',
      inquiryDate:get('inquiryDate') || new Date().toISOString().slice(0,10),
      followUpDate:get('followUpDate'),
      expectedJoinDate:get('expectedJoinDate'),
      quotedFees:Number(get('quotedFees')) || 0,
      address:get('address'),
      notes:get('notes'),
      assignedTo:(Auth.getSession() || {}).id || 'admin',
    };
    if (!item.name || !item.mobile) {
      Toast.warning('Name and mobile are required');
      return;
    }
    if (editingInquiryId) {
      DB.updateInquiry(editingInquiryId, item);
      Toast.success('Inquiry updated');
    } else {
      DB.addInquiry(item);
      Toast.success('Inquiry added');
    }
    Modal.close('inquiryModal');
    showAutoSave();
    renderInquiries();
  });
}

function quickInquiryStatus(id, status) {
  const followUpDate = new Date(Date.now() + 24 * 3600 * 1000).toISOString().slice(0,10);
  DB.updateInquiry(id, { status, followUpDate });
  Toast.info('Follow-up set for tomorrow');
  renderInquiries();
}

function convertInquiry(id) {
  if (!confirm('Convert this inquiry to a student record?')) return;
  const student = DB.convertInquiryToStudent(id);
  if (student) {
    Toast.success('Inquiry converted to student');
    renderInquiries();
  }
}

function deleteInquiry(id) {
  const item = DB.getInquiry(id);
  if (!item || !confirm(`Delete inquiry "${item.name}"?`)) return;
  DB.deleteInquiry(id);
  Toast.success('Inquiry deleted');
  renderInquiries();
}

function exportInquiries(format) {
  const rows = getFilteredInquiries();
  if (format === 'csv') {
    Exporter.toCSV(
      ['Name','Gender','Mobile','Course','Batch','Source','Status','Priority','Inquiry Date','Follow Up','Expected Join','Quoted Fees','Notes'],
      rows.map(x => [x.name,x.gender,x.mobile,x.course,x.batchNo,x.source,x.status,x.priority,x.inquiryDate,x.followUpDate,x.expectedJoinDate,x.quotedFees,x.notes]),
      'inquiries.csv'
    );
    Toast.success('Inquiries CSV exported');
    return;
  }
  const htmlRows = rows.map(x => `<tr><td>${Fmt.escape(x.name)}</td><td>${Fmt.escape(x.mobile || '-')}</td><td>${Fmt.escape(x.course || '-')}</td><td>${Fmt.escape(x.status || '-')}</td><td>${Fmt.date(x.followUpDate)}</td><td>${Fmt.escape(x.source || '-')}</td></tr>`).join('');
  Exporter.toPDF_simple('Inquiries Report', `<h2>Inquiries Report</h2><table><thead><tr><th>Name</th><th>Mobile</th><th>Course</th><th>Status</th><th>Follow Up</th><th>Source</th></tr></thead><tbody>${htmlRows}</tbody></table>`);
}

document.addEventListener('DOMContentLoaded', initInquiriesPage);

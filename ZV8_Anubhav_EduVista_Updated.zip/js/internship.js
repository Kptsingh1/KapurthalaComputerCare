/* Internship management page. */

let editingInternshipId = null;
let internshipViewMode = AcademyView ? AcademyView.get('internship_page', 'list') : 'list';

function initInternshipPage() {
  const session = Auth.requireAuth(['admin','teacher']);
  if (!session) return;
  populateInternshipLookups();
  bindInternshipForm();
  bindInternshipFilters();
  bindInternshipImport();
  enhanceInternshipViews();
  renderInternships();
}

function enhanceInternshipViews() {
  const tbody = document.getElementById('internshipTableBody');
  const tablePanel = tbody?.closest('.glass-panel');
  if (!tablePanel) return;
  tablePanel.classList.add('internship-table-panel');
  const tableContainer = tbody.closest('.table-container');
  if (tableContainer) tableContainer.classList.add('internship-table-scroll');
  if (!document.getElementById('internshipViewToolbar')) {
    tablePanel.insertAdjacentHTML('beforebegin', AcademyView.toolbarMarkup('internship_page', internshipViewMode, 'Internship view', 'internshipRecordCount', '0 records'));
    const toolbar = document.querySelector('[data-view-toolbar="internship_page"]');
    if (toolbar) toolbar.id = 'internshipViewToolbar';
    AcademyView.bind(toolbar, 'internship_page', mode => {
      internshipViewMode = mode;
      renderInternships();
    });
  }
  if (!document.getElementById('internshipCardGrid')) {
    tablePanel.insertAdjacentHTML('afterend', '<div id="internshipCardGrid" class="internship-card-grid" style="display:none"></div>');
  }
}

function populateInternshipLookups() {
  const students = DB.getStudents();
  const teachers = DB.getTeachers();
  const studentSel = document.getElementById('if_studentId');
  const mentorSel = document.getElementById('if_mentor');
  if (studentSel) {
    studentSel.innerHTML = '<option value="">-- Select Student --</option>' +
      students.map(s => `<option value="${s.id}">${s.name} - ${s.batchNo || 'No Batch'} - ${s.course || 'No Course'}</option>`).join('');
  }
  if (mentorSel) {
    mentorSel.innerHTML = '<option value="">-- Select Mentor --</option>' +
      teachers.map(t => `<option value="${t.name}">${t.name} - ${t.subject || 'Teacher'}</option>`).join('');
  }
}

function bindInternshipFilters() {
  ['internshipSearch','internshipStatusFilter'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('input', renderInternships);
    el.addEventListener('change', renderInternships);
  });
}

function getFilteredInternships() {
  const q = (document.getElementById('internshipSearch')?.value || '').trim().toLowerCase();
  const status = document.getElementById('internshipStatusFilter')?.value || 'All';
  return DB.getInternships().filter(item => {
    const statusOk = status === 'All' || item.status === status;
    const text = [
      item.studentName, item.batchNo, item.program, item.company, item.mentor,
      item.projectTitle, item.status, (item.skills || []).join(' ')
    ].join(' ').toLowerCase();
    return statusOk && (!q || text.includes(q));
  });
}

function renderInternships() {
  const records = getFilteredInternships();
  renderInternshipStats();
  const tbody = document.getElementById('internshipTableBody');
  if (!tbody) return;
  const tablePanel = tbody.closest('.glass-panel');
  const cardsGrid = document.getElementById('internshipCardGrid');
  const count = document.getElementById('internshipRecordCount');
  if (count) count.textContent = `${records.length} record${records.length === 1 ? '' : 's'}`;
  if (tablePanel) tablePanel.style.display = internshipViewMode === 'grid' ? 'none' : '';
  if (cardsGrid) {
    cardsGrid.style.display = internshipViewMode === 'grid' ? 'grid' : 'none';
    if (internshipViewMode === 'grid') renderInternshipCards(records, cardsGrid);
  }
  tbody.innerHTML = records.length ? records.map(item => {
    const badge = {
      Planned:'badge-warning', Active:'badge-primary', Completed:'badge-success',
      'On Hold':'badge-warning', Cancelled:'badge-danger'
    }[item.status] || 'badge-info';
    return `<tr>
      <td>
        <div style="font-weight:700;font-size:0.88rem">${item.studentName || 'Not Assigned'}</div>
        <div style="font-size:0.72rem;color:var(--text-muted)">${item.batchNo || 'No Batch'}</div>
      </td>
      <td>
        <div style="font-weight:600">${item.program || '-'}</div>
        <div style="font-size:0.72rem;color:var(--text-muted)">${(item.skills || []).join(', ') || 'No skills'}</div>
      </td>
      <td style="font-size:0.84rem">${item.mentor || '-'}<br><span class="text-muted">${item.company || ''}</span></td>
      <td style="font-size:0.8rem">${Fmt.date(item.startDate)}<br>${Fmt.date(item.endDate)}</td>
      <td style="font-size:0.84rem">${item.projectTitle || '-'}${item.projectUrl ? `<br><a href="${item.projectUrl}" target="_blank" style="color:var(--primary);font-size:0.72rem">Open Project</a>` : ''}</td>
      <td><span class="badge ${badge}">${item.status || '-'}</span></td>
      <td style="font-size:0.82rem">${item.certificateNo || '-'}<br><span class="text-muted">${item.evaluation || ''}</span></td>
      <td>
        <div style="display:flex;gap:6px;flex-wrap:wrap">
          <button class="btn btn-sm btn-ghost" onclick="editInternship('${item.id}')">✏️ Edit</button>
          <button class="btn btn-sm btn-secondary" onclick="printInternship('${item.id}')">🖨 PDF</button>
          <button class="btn btn-sm btn-danger" onclick="deleteInternship('${item.id}')">🗑</button>
        </div>
      </td>
    </tr>`;
  }).join('') : '<tr><td colspan="8" style="text-align:center;padding:40px;color:var(--text-muted)">No internship records found.</td></tr>';
}

function renderInternshipCards(records, container) {
  container.innerHTML = records.length ? records.map(item => {
    const badge = {
      Planned:'badge-warning', Active:'badge-primary', Completed:'badge-success',
      'On Hold':'badge-warning', Cancelled:'badge-danger'
    }[item.status] || 'badge-info';
    return `<article class="internship-card">
      <div class="person-card-top">
        <div>
          <div class="person-title">${Fmt.escape(item.studentName || 'Not Assigned')}</div>
          <div class="card-meta-line"><span>${Fmt.escape(item.batchNo || 'No Batch')}</span><span>${Fmt.escape(item.program || '-')}</span></div>
        </div>
        <span class="badge ${badge}">${Fmt.escape(item.status || '-')}</span>
      </div>
      <div class="detail-row"><span>Mentor</span><strong>${Fmt.escape(item.mentor || '-')}</strong></div>
      <div class="detail-row"><span>Company</span><strong>${Fmt.escape(item.company || '-')}</strong></div>
      <div class="detail-row"><span>Dates</span><strong>${Fmt.date(item.startDate)} - ${Fmt.date(item.endDate)}</strong></div>
      <div class="detail-row"><span>Project</span><strong>${Fmt.escape(item.projectTitle || '-')}</strong></div>
      <div class="detail-row"><span>Skills</span><strong>${Fmt.escape((item.skills || []).join(', ') || '-')}</strong></div>
      <div class="detail-row"><span>Certificate</span><strong>${Fmt.escape(item.certificateNo || '-')} ${item.evaluation ? '(' + Fmt.escape(item.evaluation) + ')' : ''}</strong></div>
      <div class="card-actions">
        <button class="btn btn-sm btn-ghost" onclick="editInternship('${item.id}')">Edit</button>
        <button class="btn btn-sm btn-secondary" onclick="printInternship('${item.id}')">PDF</button>
        <button class="btn btn-sm btn-danger" onclick="deleteInternship('${item.id}')">Delete</button>
      </div>
    </article>`;
  }).join('') : '<div class="empty-state"><p>No internship records found.</p></div>';
}

function renderInternshipStats() {
  const all = DB.getInternships();
  const set = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value; };
  set('intTotal', all.length);
  set('intActive', all.filter(x => x.status === 'Active').length);
  set('intCompleted', all.filter(x => x.status === 'Completed').length);
  set('intCertified', all.filter(x => x.certificateNo).length);
}

function openInternshipModal() {
  editingInternshipId = null;
  populateInternshipLookups();
  document.getElementById('internshipModalTitle').textContent = '➕ Add Internship';
  document.getElementById('internshipForm').reset();
  document.getElementById('if_status').value = 'Active';
  Modal.open('internshipModal');
}

function editInternship(id) {
  const item = DB.getInternship(id);
  if (!item) return;
  editingInternshipId = id;
  populateInternshipLookups();
  document.getElementById('internshipModalTitle').textContent = '✏️ Edit Internship - ' + (item.studentName || item.program);
  const set = (id, value) => { const el = document.getElementById('if_' + id); if (el) el.value = value || ''; };
  set('studentId', item.studentId);
  set('program', item.program);
  set('company', item.company);
  set('mentor', item.mentor);
  set('startDate', item.startDate);
  set('endDate', item.endDate);
  set('duration', item.duration);
  set('hours', item.hours);
  set('stipend', item.stipend);
  set('status', item.status);
  set('skills', (item.skills || []).join(', '));
  set('projectTitle', item.projectTitle);
  set('projectUrl', item.projectUrl);
  set('certificateNo', item.certificateNo);
  set('evaluation', item.evaluation);
  set('remarks', item.remarks);
  Modal.open('internshipModal');
}

function bindInternshipForm() {
  const form = document.getElementById('internshipForm');
  if (!form) return;
  form.addEventListener('submit', e => {
    e.preventDefault();
    const data = getInternshipFormData();
    if (!data.program.trim()) { Toast.warning('Program is required'); return; }
    if (editingInternshipId) {
      DB.updateInternship(editingInternshipId, data);
      Toast.success('Internship updated');
    } else {
      DB.addInternship(data);
      Toast.success('Internship added');
    }
    Modal.close('internshipModal');
    renderInternships();
    showAutoSave();
  });
}

function getInternshipFormData() {
  const get = id => document.getElementById('if_' + id)?.value || '';
  const student = DB.getStudent(get('studentId'));
  return {
    studentId:get('studentId'),
    studentName:student ? student.name : '',
    batchNo:student ? (student.batchNo || '') : '',
    program:get('program'),
    company:get('company'),
    mentor:get('mentor'),
    startDate:get('startDate'),
    endDate:get('endDate'),
    duration:get('duration'),
    hours:Number(get('hours')) || 0,
    stipend:Number(get('stipend')) || 0,
    status:get('status') || 'Active',
    skills:get('skills').split(',').map(s => s.trim()).filter(Boolean),
    projectTitle:get('projectTitle'),
    projectUrl:get('projectUrl'),
    certificateNo:get('certificateNo'),
    evaluation:get('evaluation'),
    remarks:get('remarks'),
  };
}

function deleteInternship(id) {
  if (!confirm('Delete this internship record?')) return;
  DB.deleteInternship(id);
  renderInternships();
  Toast.info('Internship deleted');
}

function internshipRows(records = DB.getInternships()) {
  return records.map(item => ({
    ID:item.id,
    Student:item.studentName || '',
    StudentId:item.studentId || '',
    Batch:item.batchNo || '',
    Program:item.program || '',
    Company:item.company || '',
    Mentor:item.mentor || '',
    StartDate:item.startDate || '',
    EndDate:item.endDate || '',
    Duration:item.duration || '',
    Hours:item.hours || 0,
    Stipend:item.stipend || 0,
    Status:item.status || '',
    Skills:(item.skills || []).join(', '),
    ProjectTitle:item.projectTitle || '',
    ProjectUrl:item.projectUrl || '',
    CertificateNo:item.certificateNo || '',
    Evaluation:item.evaluation || '',
    Remarks:item.remarks || '',
  }));
}

function exportInternships(format) {
  const records = getFilteredInternships();
  const rows = internshipRows(records);
  if (format === 'json') {
    Exporter.toJSON(records, 'internships.json');
  } else if (format === 'pdf') {
    const tableRows = records.map(item => `<tr><td>${item.studentName || '-'}</td><td>${item.program || '-'}</td><td>${item.mentor || '-'}</td><td>${Fmt.date(item.startDate)} - ${Fmt.date(item.endDate)}</td><td>${item.status || '-'}</td><td>${item.certificateNo || '-'}</td></tr>`).join('');
    Exporter.toPDF_simple('Internship Report', `<h2>Internship Report</h2><table><thead><tr><th>Student</th><th>Program</th><th>Mentor</th><th>Dates</th><th>Status</th><th>Certificate</th></tr></thead><tbody>${tableRows}</tbody></table>`);
  } else if (format === 'xlsx') {
    if (!window.XLSX) { Toast.error('Excel library not loaded'); return; }
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Internships');
    XLSX.writeFile(wb, 'internships.xlsx');
  } else {
    const headers = Object.keys(rows[0] || { Student:'', Program:'', Status:'' });
    Exporter.toCSV(headers, rows.map(r => headers.map(h => r[h])), 'internships.csv');
  }
  Toast.success('Internships exported');
}

function printInternship(id) {
  const item = DB.getInternship(id);
  if (!item) return;
  const rows = Object.entries({
    Student:item.studentName || '-',
    Batch:item.batchNo || '-',
    Program:item.program || '-',
    Company:item.company || '-',
    Mentor:item.mentor || '-',
    Dates:`${Fmt.date(item.startDate)} - ${Fmt.date(item.endDate)}`,
    Duration:item.duration || '-',
    Hours:item.hours || 0,
    Stipend:Fmt.currency(item.stipend || 0),
    Status:item.status || '-',
    Skills:(item.skills || []).join(', ') || '-',
    Project:item.projectTitle || '-',
    Certificate:item.certificateNo || '-',
    Evaluation:item.evaluation || '-',
    Remarks:item.remarks || '-',
  }).map(([k,v]) => `<tr><td style="font-weight:700;width:35%">${k}</td><td>${v}</td></tr>`).join('');
  Exporter.toPDF_simple('Internship Details', `<h2>Internship Details</h2><table><tbody>${rows}</tbody></table>`);
}

function bindInternshipImport() {
  const input = document.getElementById('internshipImportFile');
  if (!input) return;
  input.addEventListener('change', () => {
    const file = input.files && input.files[0];
    if (!file) return;
    const ext = file.name.split('.').pop().toLowerCase();
    const reader = new FileReader();
    reader.onload = e => {
      try {
        if (ext === 'json') importInternshipRows(JSON.parse(e.target.result));
        else if (ext === 'csv') importInternshipRows(parseCSV(e.target.result));
        else importInternshipXlsx(e.target.result);
        input.value = '';
      } catch (err) {
        Toast.error('Import failed: ' + err.message);
      }
    };
    if (ext === 'xlsx' || ext === 'xls') reader.readAsBinaryString(file);
    else reader.readAsText(file);
  });
}

function importInternshipXlsx(binary) {
  if (!window.XLSX) throw new Error('Excel library not loaded');
  const wb = XLSX.read(binary, { type:'binary' });
  const ws = wb.Sheets[wb.SheetNames[0]];
  importInternshipRows(XLSX.utils.sheet_to_json(ws));
}

function importInternshipRows(rows) {
  const inputRows = Array.isArray(rows) ? rows : (rows.internships || []);
  const existing = DB.getInternships();
  let added = 0;
  inputRows.forEach(row => {
    const normalized = normalizeInternshipRow(row);
    if (!normalized.program) return;
    existing.unshift({
      ...normalized,
      id: normalized.id || DB.generateId('int'),
      createdAt: normalized.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
    added++;
  });
  DB.saveInternships(existing);
  renderInternships();
  Toast.success(`Imported ${added} internship record(s)`);
}

function normalizeInternshipRow(row) {
  const pick = (...names) => {
    for (const name of names) {
      if (row[name] !== undefined && row[name] !== null) return row[name];
    }
    return '';
  };
  const studentId = pick('StudentId','studentId');
  const student = studentId ? DB.getStudent(studentId) : DB.getStudents().find(s => s.name === pick('Student','studentName'));
  return {
    id:pick('ID','id'),
    studentId:student ? student.id : studentId,
    studentName:student ? student.name : pick('Student','studentName'),
    batchNo:student ? (student.batchNo || '') : pick('Batch','batchNo'),
    program:pick('Program','program'),
    company:pick('Company','company'),
    mentor:pick('Mentor','mentor'),
    startDate:pick('StartDate','startDate'),
    endDate:pick('EndDate','endDate'),
    duration:pick('Duration','duration'),
    hours:Number(pick('Hours','hours')) || 0,
    stipend:Number(pick('Stipend','stipend')) || 0,
    status:pick('Status','status') || 'Active',
    skills:String(pick('Skills','skills')).split(',').map(s => s.trim()).filter(Boolean),
    projectTitle:pick('ProjectTitle','projectTitle'),
    projectUrl:pick('ProjectUrl','projectUrl'),
    certificateNo:pick('CertificateNo','certificateNo'),
    evaluation:pick('Evaluation','evaluation'),
    remarks:pick('Remarks','remarks'),
  };
}

function parseCSV(text) {
  const rows = [];
  let row = [], value = '', quoted = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i], next = text[i + 1];
    if (ch === '"' && quoted && next === '"') { value += '"'; i++; continue; }
    if (ch === '"') { quoted = !quoted; continue; }
    if (ch === ',' && !quoted) { row.push(value); value = ''; continue; }
    if ((ch === '\n' || ch === '\r') && !quoted) {
      if (ch === '\r' && next === '\n') i++;
      row.push(value); rows.push(row); row = []; value = ''; continue;
    }
    value += ch;
  }
  if (value || row.length) { row.push(value); rows.push(row); }
  const headers = rows.shift() || [];
  return rows.filter(r => r.some(Boolean)).map(r => Object.fromEntries(headers.map((h, i) => [h, r[i] || ''])));
}

document.addEventListener('DOMContentLoaded', initInternshipPage);

/* ==========================================================================
   MASTER EXCEL EXPORT
   Creates one formatted workbook for all academy data using ExcelJS.
   ========================================================================== */

const MasterExcel = (() => {
  const colors = {
    title: 'FF0F172A',
    primary: 'FF0F766E',
    secondary: 'FF2563EB',
    accent: 'FFF59E0B',
    danger: 'FFDC2626',
    header: 'FF164E63',
    soft: 'FFF8FAFC',
    softGreen: 'FFDCFCE7',
    softBlue: 'FFDBEAFE',
    softAmber: 'FFFEF3C7',
    border: 'FFE2E8F0',
    white: 'FFFFFFFF',
  };

  const thinBorder = {
    top: { style:'thin', color:{ argb:colors.border } },
    left: { style:'thin', color:{ argb:colors.border } },
    bottom: { style:'thin', color:{ argb:colors.border } },
    right: { style:'thin', color:{ argb:colors.border } },
  };

  function cleanSheetName(name) {
    return String(name).replace(/[\\/?*\[\]:]/g, ' ').slice(0, 31);
  }

  function todayName() {
    return new Date().toISOString().slice(0, 10);
  }

  function cellValue(value) {
    if (value === undefined || value === null) return '';
    if (Array.isArray(value)) return value.join(', ');
    if (value instanceof Date) return value;
    if (typeof value === 'object') return JSON.stringify(value);
    return value;
  }

  function num(value) {
    const n = Number(value);
    return Number.isFinite(n) ? n : 0;
  }

  function getSnapshot() {
    return DB.exportAll ? DB.exportAll() : {};
  }

  function paymentRows(data) {
    const students = data.students || [];
    const byId = new Map(students.map(s => [s.id, s]));
    const rows = [];
    Object.entries(data.fees || {}).forEach(([studentId, record]) => {
      const student = byId.get(studentId) || {};
      const payments = Array.isArray(record) ? record : ((record && record.payments) || []);
      if (!payments.length) {
        rows.push({
          studentId,
          studentName: student.name || studentId,
          course: student.course || '',
          date: '',
          amount: 0,
          mode: '',
          note: 'No payments recorded',
        });
        return;
      }
      payments.forEach(payment => rows.push({
        studentId,
        studentName: student.name || studentId,
        course: student.course || '',
        date: payment.date || '',
        amount: num(payment.amount),
        mode: payment.mode || payment.method || 'Cash',
        note: payment.note || payment.remark || '',
        receiptNo: payment.receiptNo || payment.receipt || '',
      }));
    });
    return rows;
  }

  function attendanceRows(data) {
    const people = new Map([
      ...(data.students || []).map(s => [s.id, { name:s.name, role:'Student', course:s.course || '' }]),
      ...(data.teachers || []).map(t => [t.id, { name:t.name, role:'Teacher', course:t.subject || '' }]),
    ]);
    const rows = [];
    Object.entries(data.attendance || {}).forEach(([month, monthData]) => {
      Object.entries(monthData || {}).forEach(([personId, days]) => {
        const info = people.get(personId) || { name:personId, role:'Person', course:'' };
        const values = Object.values(days || {});
        const present = values.filter(v => v === 'P').length;
        const absent = values.filter(v => v === 'A').length;
        const leave = values.filter(v => v === 'L').length;
        const total = present + absent + leave;
        rows.push({
          month,
          personId,
          name: info.name,
          role: info.role,
          course: info.course,
          present,
          absent,
          leave,
          totalMarked: total,
          percentage: total ? Math.round((present / total) * 100) : 0,
        });
      });
    });
    return rows;
  }

  function timetableRows(data) {
    const tt = data.timetable || {};
    const rows = [];
    Object.entries(tt.entries || {}).forEach(([slotKey, value]) => {
      rows.push({
        slot: slotKey,
        student: value && (value.studentName || value.student || value.name) || '',
        course: value && value.course || '',
        teacher: value && value.teacher || '',
        note: value && (value.note || value.remarks) || '',
      });
    });
    if (!rows.length) {
      (tt.devices || tt.days || []).forEach(device => rows.push({
        slot: device,
        student: '',
        course: '',
        teacher: '',
        note: 'Device configured',
      }));
    }
    return rows;
  }

  function salaryRows(data) {
    const teachers = new Map((data.teachers || []).map(t => [t.id, t]));
    const rows = [];
    Object.entries(data.salary || {}).forEach(([teacherId, record]) => {
      const teacher = teachers.get(teacherId) || {};
      const payments = (record && record.records) || [];
      if (!payments.length) {
        rows.push({
          teacherId,
          teacherName: teacher.name || teacherId,
          baseSalary: num(record && record.baseSalary || teacher.salary),
          date: '',
          amount: 0,
          note: 'No salary payments recorded',
        });
        return;
      }
      payments.forEach(payment => rows.push({
        teacherId,
        teacherName: teacher.name || teacherId,
        baseSalary: num(record && record.baseSalary || teacher.salary),
        date: payment.date || payment.paidAt || '',
        amount: num(payment.amount),
        mode: payment.mode || 'Cash',
        note: payment.note || payment.remark || '',
      }));
    });
    return rows;
  }

  function storageRows() {
    if (window.StorageHub && typeof StorageHub.getAdapters === 'function') {
      return StorageHub.getAdapters();
    }
    return [
      { title:'Local Storage', group:'Client-Side', state:'Live', detail:'Primary browser database' },
      { title:'Server-Side - Backend + Database', group:'Server-Side', state:'Live', detail:'Node.js JSON database API' },
      { title:'CSV/Excel', group:'Exports', state:'Live', detail:'Single formatted workbook export' },
    ];
  }

  function addTitle(ws, title, subtitle, columns) {
    ws.mergeCells(1, 1, 1, columns);
    ws.mergeCells(2, 1, 2, columns);
    ws.getCell(1, 1).value = title;
    ws.getCell(1, 1).font = { name:'Aptos Display', size:18, bold:true, color:{ argb:colors.white } };
    ws.getCell(1, 1).fill = { type:'pattern', pattern:'solid', fgColor:{ argb:colors.title } };
    ws.getCell(1, 1).alignment = { horizontal:'center', vertical:'middle', wrapText:true };
    ws.getCell(2, 1).value = subtitle;
    ws.getCell(2, 1).font = { name:'Aptos', size:10, color:{ argb:'FF334155' } };
    ws.getCell(2, 1).fill = { type:'pattern', pattern:'solid', fgColor:{ argb:colors.soft } };
    ws.getCell(2, 1).alignment = { horizontal:'center', vertical:'middle', wrapText:true };
    ws.getRow(1).height = 28;
    ws.getRow(2).height = 24;
  }

  function styleCell(cell, opts = {}) {
    cell.font = opts.font || { name:'Aptos', size:10, color:{ argb:'FF0F172A' } };
    cell.alignment = opts.alignment || { vertical:'middle', wrapText:true };
    cell.border = thinBorder;
    if (opts.fill) cell.fill = { type:'pattern', pattern:'solid', fgColor:{ argb:opts.fill } };
    if (opts.numFmt) cell.numFmt = opts.numFmt;
  }

  function addTableSheet(workbook, name, columns, rows, options = {}) {
    const ws = workbook.addWorksheet(cleanSheetName(name), {
      pageSetup: {
        paperSize: 9,
        orientation: 'landscape',
        fitToPage: true,
        fitToWidth: 1,
        fitToHeight: 0,
        horizontalCentered: true,
      },
      properties: { tabColor: { argb: options.tabColor || colors.primary } },
    });
    ws.properties.defaultRowHeight = 20;
    ws.views = [{ state:'frozen', ySplit:4 }];
    ws.pageSetup.printTitlesRow = '1:4';
    addTitle(ws, name, `${rows.length} record(s) | Exported ${new Date().toLocaleString()}`, columns.length);

    const headerRow = ws.getRow(4);
    headerRow.values = columns.map(c => c.header);
    headerRow.height = 26;
    headerRow.eachCell(cell => {
      styleCell(cell, {
        font: { name:'Aptos', size:10, bold:true, color:{ argb:colors.white } },
        fill: colors.header,
        alignment: { vertical:'middle', horizontal:'center', wrapText:true, textRotation: 0 },
      });
    });

    rows.forEach((row, index) => {
      const wsRow = ws.addRow(columns.map(c => cellValue(row[c.key])));
      wsRow.height = 22;
      wsRow.eachCell((cell, colNumber) => {
        const col = columns[colNumber - 1];
        styleCell(cell, {
          fill: index % 2 ? 'FFFFFFFF' : colors.soft,
          numFmt: col && col.numFmt,
          alignment: { vertical:'top', wrapText:true },
        });
      });
    });

    if (!rows.length) {
      const empty = ws.addRow(['No records found']);
      ws.mergeCells(empty.number, 1, empty.number, columns.length);
      styleCell(ws.getCell(empty.number, 1), { fill:colors.softAmber });
    }

    ws.columns = columns.map(c => ({ width: c.width || 18 }));
    ws.autoFilter = { from:{ row:4, column:1 }, to:{ row:Math.max(5, rows.length + 4), column:columns.length } };
    return ws;
  }

  function writeDashboard(workbook, data) {
    const ws = workbook.addWorksheet('Dashboard', {
      pageSetup: { paperSize:9, orientation:'landscape', fitToPage:true, fitToWidth:1, fitToHeight:0 },
      properties: { tabColor: { argb: colors.primary } },
    });
    addTitle(ws, 'Computer Care Academy - Master Data Dashboard', 'Single workbook export with source data, storage map, and print-ready sheets', 8);
    ws.views = [{ state:'frozen', ySplit:3 }];
    ws.pageSetup.printTitlesRow = '1:3';
    ws.columns = Array.from({ length:8 }, () => ({ width:18 }));

    const totalFees = (data.students || []).reduce((sum, s) => sum + num(s.totalFees), 0);
    const paid = (data.students || []).reduce((sum, s) => sum + (DB.paidFees ? num(DB.paidFees(s.id)) : 0), 0);
    const kpis = [
      ['Students', (data.students || []).length, colors.softBlue],
      ['Teachers', (data.teachers || []).length, colors.softGreen],
      ['Courses', (data.courses || []).length, colors.softAmber],
      ['Collected Fees', paid, colors.softGreen, '#,##0'],
      ['Pending Fees', totalFees - paid, 'FFFFE4E6', '#,##0'],
      ['Tasks', (data.tasks || []).length, colors.softBlue],
      ['Internships', (data.internships || []).length, colors.softAmber],
      ['Inquiries', (data.inquiries || []).length, 'FFFFE4E6'],
      ['Storage Adapters', storageRows().length, colors.softGreen],
    ];

    kpis.forEach((item, i) => {
      const row = 4 + Math.floor(i / 4) * 4;
      const col = 1 + (i % 4) * 2;
      ws.mergeCells(row, col, row, col + 1);
      ws.mergeCells(row + 1, col, row + 2, col + 1);
      const label = ws.getCell(row, col);
      label.value = item[0];
      styleCell(label, {
        fill: colors.title,
        font: { name:'Aptos', size:10, bold:true, color:{ argb:colors.white } },
        alignment: { horizontal:'center', vertical:'middle', wrapText:true },
      });
      const value = ws.getCell(row + 1, col);
      value.value = item[1];
      styleCell(value, {
        fill: item[2],
        numFmt: item[3],
        font: { name:'Aptos Display', size:18, bold:true, color:{ argb:colors.title } },
        alignment: { horizontal:'center', vertical:'middle', wrapText:true },
      });
    });

    ws.getRow(17).values = ['Storage / Export Area', 'Status', 'Side', 'Data Format', 'Notes'];
    ws.getRow(17).eachCell(cell => styleCell(cell, {
      fill: colors.header,
      font: { name:'Aptos', size:10, bold:true, color:{ argb:colors.white } },
      alignment: { horizontal:'center', vertical:'middle', wrapText:true },
    }));
    storageRows().slice(0, 18).forEach(adapter => {
      const row = ws.addRow([
        adapter.title || adapter.name,
        adapter.state || adapter.status,
        adapter.side || adapter.group,
        adapter.format || adapter.technology || '',
        adapter.detail || adapter.description || '',
      ]);
      row.eachCell(cell => styleCell(cell, { fill: row.number % 2 ? colors.soft : 'FFFFFFFF' }));
    });
  }

  function buildWorkbook(data) {
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'Computer Care Academy Management';
    workbook.created = new Date();
    workbook.modified = new Date();
    workbook.properties = {
      title: 'Computer Care Academy Master Data Export',
      subject: 'All academy data in one formatted workbook',
      company: 'Computer Care (Anubhav EduVista)',
    };

    writeDashboard(workbook, data);

    addTableSheet(workbook, 'Students', [
      { header:'ID', key:'id', width:14 },
      { header:'Name', key:'name', width:24 },
      { header:'Father', key:'fatherName', width:22 },
      { header:'Mobile', key:'mobile', width:15 },
      { header:'Email', key:'email', width:24 },
      { header:'Course', key:'course', width:24 },
      { header:'Batch', key:'batchNo', width:14 },
      { header:'Device', key:'pcNo', width:12 },
      { header:'Status', key:'courseStatus', width:14 },
      { header:'Admission', key:'admissionDate', width:14 },
      { header:'Total Fees', key:'totalFees', width:13, numFmt:'#,##0' },
      { header:'Paid', key:'paid', width:13, numFmt:'#,##0' },
      { header:'Balance', key:'balance', width:13, numFmt:'#,##0' },
      { header:'Address', key:'address', width:34 },
    ], (data.students || []).map(s => {
      const paid = DB.paidFees ? num(DB.paidFees(s.id)) : 0;
      return { ...s, paid, balance:num(s.totalFees) - paid };
    }), { tabColor:colors.secondary });

    addTableSheet(workbook, 'Teachers', [
      { header:'ID', key:'id', width:14 },
      { header:'Name', key:'name', width:24 },
      { header:'Qualification', key:'qualification', width:18 },
      { header:'Subject', key:'subject', width:18 },
      { header:'Mobile', key:'mobile', width:15 },
      { header:'Email', key:'email', width:24 },
      { header:'Join Date', key:'joinDate', width:14 },
      { header:'Salary', key:'salary', width:13, numFmt:'#,##0' },
      { header:'Performance', key:'performance', width:16 },
      { header:'Active', key:'active', width:10 },
      { header:'Address', key:'address', width:34 },
    ], data.teachers || [], { tabColor:colors.primary });

    addTableSheet(workbook, 'Fees', [
      { header:'Student ID', key:'studentId', width:14 },
      { header:'Student', key:'studentName', width:24 },
      { header:'Course', key:'course', width:24 },
      { header:'Date', key:'date', width:14 },
      { header:'Amount', key:'amount', width:13, numFmt:'#,##0' },
      { header:'Mode', key:'mode', width:14 },
      { header:'Receipt No', key:'receiptNo', width:16 },
      { header:'Note', key:'note', width:34 },
    ], paymentRows(data), { tabColor:colors.accent });

    addTableSheet(workbook, 'Attendance', [
      { header:'Month', key:'month', width:12 },
      { header:'Person ID', key:'personId', width:14 },
      { header:'Name', key:'name', width:24 },
      { header:'Role', key:'role', width:12 },
      { header:'Course / Subject', key:'course', width:24 },
      { header:'Present', key:'present', width:11 },
      { header:'Absent', key:'absent', width:11 },
      { header:'Leave', key:'leave', width:11 },
      { header:'Total Marked', key:'totalMarked', width:13 },
      { header:'Percentage', key:'percentage', width:13, numFmt:'0"%"' },
    ], attendanceRows(data), { tabColor:colors.danger });

    addTableSheet(workbook, 'Courses', [
      { header:'ID', key:'id', width:12 },
      { header:'Name', key:'name', width:28 },
      { header:'Duration', key:'duration', width:14 },
      { header:'Fees', key:'fees', width:12, numFmt:'#,##0' },
      { header:'Subcategories', key:'subcategories', width:44 },
    ], data.courses || [], { tabColor:colors.secondary });

    addTableSheet(workbook, 'Timetable', [
      { header:'Slot / Device', key:'slot', width:22 },
      { header:'Student', key:'student', width:24 },
      { header:'Course', key:'course', width:24 },
      { header:'Teacher', key:'teacher', width:22 },
      { header:'Note', key:'note', width:36 },
    ], timetableRows(data), { tabColor:colors.primary });

    addTableSheet(workbook, 'Topics', [
      { header:'ID', key:'id', width:14 },
      { header:'Title', key:'title', width:28 },
      { header:'Course', key:'course', width:24 },
      { header:'Teacher', key:'teacher', width:20 },
      { header:'Date', key:'date', width:14 },
      { header:'Description', key:'description', width:42 },
    ], data.topics || [], { tabColor:colors.accent });

    addTableSheet(workbook, 'Internships', [
      { header:'ID', key:'id', width:16 },
      { header:'Student', key:'studentName', width:24 },
      { header:'Program', key:'program', width:28 },
      { header:'Company', key:'company', width:24 },
      { header:'Mentor', key:'mentor', width:22 },
      { header:'Start', key:'startDate', width:14 },
      { header:'End', key:'endDate', width:14 },
      { header:'Hours', key:'hours', width:10 },
      { header:'Status', key:'status', width:14 },
      { header:'Project', key:'projectTitle', width:30 },
    ], data.internships || [], { tabColor:colors.secondary });

    addTableSheet(workbook, 'Inquiries', [
      { header:'ID', key:'id', width:16 },
      { header:'Name', key:'name', width:24 },
      { header:'Gender', key:'gender', width:12 },
      { header:'Mobile', key:'mobile', width:16 },
      { header:'Course', key:'course', width:28 },
      { header:'Batch', key:'batchNo', width:14 },
      { header:'Source', key:'source', width:16 },
      { header:'Status', key:'status', width:14 },
      { header:'Priority', key:'priority', width:12 },
      { header:'Inquiry Date', key:'inquiryDate', width:14 },
      { header:'Follow Up', key:'followUpDate', width:14 },
      { header:'Expected Join', key:'expectedJoinDate', width:14 },
      { header:'Quoted Fees', key:'quotedFees', width:13, numFmt:'#,##0' },
      { header:'Notes', key:'notes', width:44 },
    ], data.inquiries || [], { tabColor:colors.danger });

    addTableSheet(workbook, 'Tasks', [
      { header:'ID', key:'id', width:16 },
      { header:'Title', key:'title', width:28 },
      { header:'Assigned To', key:'assignedTo', width:18 },
      { header:'Status', key:'status', width:14 },
      { header:'Priority', key:'priority', width:12 },
      { header:'Due Date', key:'dueDate', width:14 },
      { header:'Created At', key:'createdAt', width:20 },
      { header:'Description', key:'description', width:42 },
    ], data.tasks || [], { tabColor:colors.accent });

    addTableSheet(workbook, 'Salary', [
      { header:'Teacher ID', key:'teacherId', width:14 },
      { header:'Teacher', key:'teacherName', width:24 },
      { header:'Base Salary', key:'baseSalary', width:14, numFmt:'#,##0' },
      { header:'Date', key:'date', width:16 },
      { header:'Amount', key:'amount', width:14, numFmt:'#,##0' },
      { header:'Mode', key:'mode', width:14 },
      { header:'Note', key:'note', width:36 },
    ], salaryRows(data), { tabColor:colors.primary });

    addTableSheet(workbook, 'Notifications', [
      { header:'ID', key:'id', width:16 },
      { header:'Title', key:'title', width:30 },
      { header:'Type', key:'type', width:14 },
      { header:'Target', key:'target', width:14 },
      { header:'Date', key:'date', width:14 },
      { header:'Priority', key:'priority', width:12 },
      { header:'Message', key:'message', width:48 },
    ], data.notifications || [], { tabColor:colors.danger });

    addTableSheet(workbook, 'Gallery', [
      { header:'ID', key:'id', width:16 },
      { header:'Title', key:'title', width:28 },
      { header:'Category', key:'category', width:18 },
      { header:'Uploaded At', key:'uploadedAt', width:20 },
      { header:'Description', key:'description', width:42 },
      { header:'Image', key:'image', width:36 },
    ], data.gallery || [], { tabColor:colors.secondary });

    addTableSheet(workbook, 'Blog', [
      { header:'ID', key:'id', width:16 },
      { header:'Title', key:'title', width:34 },
      { header:'Category', key:'category', width:18 },
      { header:'Author', key:'author', width:18 },
      { header:'Published', key:'publishedAt', width:14 },
      { header:'Featured', key:'featured', width:10 },
      { header:'Views', key:'views', width:10 },
      { header:'Excerpt', key:'excerpt', width:48 },
    ], data.blog || [], { tabColor:colors.accent });

    addTableSheet(workbook, 'Teacher Notes', [
      { header:'ID', key:'id', width:16 },
      { header:'Title', key:'title', width:28 },
      { header:'Teacher', key:'teacherName', width:22 },
      { header:'Course', key:'course', width:22 },
      { header:'Created At', key:'createdAt', width:20 },
      { header:'Content', key:'content', width:52 },
    ], data.teacherNotes || [], { tabColor:colors.primary });

    addTableSheet(workbook, 'Settings', [
      { header:'Setting', key:'key', width:28 },
      { header:'Value', key:'value', width:60 },
    ], Object.entries(data.settings || {}).map(([key, value]) => ({ key, value })), { tabColor:colors.secondary });

    addTableSheet(workbook, 'Storage Map', [
      { header:'Storage Type', key:'title', width:28 },
      { header:'Group', key:'group', width:20 },
      { header:'Side', key:'side', width:18 },
      { header:'State', key:'state', width:16 },
      { header:'Format', key:'format', width:18 },
      { header:'Details', key:'detail', width:56 },
    ], storageRows(), { tabColor:colors.primary });

    const raw = DB.exportStorage ? DB.exportStorage() : data;
    addTableSheet(workbook, 'Raw JSON', [
      { header:'Key', key:'key', width:28 },
      { header:'JSON Value', key:'value', width:90 },
    ], Object.entries(raw).map(([key, value]) => ({ key, value: JSON.stringify(value, null, 2) })), { tabColor:colors.title });

    return workbook;
  }

  async function exportAllData() {
    if (!window.ExcelJS) {
      if (window.location.protocol.startsWith('http')) {
        window.location.href = 'api/export/master.xlsx';
        return;
      }
      Toast.error('ExcelJS is not loaded. Start the backend or connect to the internet for the formatted workbook export.');
      return;
    }
    const workbook = buildWorkbook(getSnapshot());
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `computer-care-master-data-${todayName()}.xlsx`;
    a.click();
    URL.revokeObjectURL(a.href);
    Toast.success('Complete formatted Excel workbook exported.');
  }

  return {
    exportAllData,
    buildWorkbook,
  };
})();

window.MasterExcel = MasterExcel;

// ---- Import hook: add import button to any export dropdown ----
MasterExcel.addImportButtonToExportDropdowns = function() {
  document.querySelectorAll('.dropdown-menu').forEach(menu => {
    if (!menu.querySelector('[data-import-excel-btn]') && menu.innerHTML.includes('Export')) {
      const divider = document.createElement('div');
      divider.className = 'dropdown-divider';
      const btn = document.createElement('button');
      btn.className = 'dropdown-item';
      btn.setAttribute('data-import-excel-btn', '1');
      btn.innerHTML = '📥 Import from Excel';
      btn.onclick = function() { if (window.ExcelImport) ExcelImport.openImportModal(); };
      menu.appendChild(divider);
      menu.appendChild(btn);
    }
  });
};

document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => MasterExcel.addImportButtonToExportDropdowns(), 800);
});

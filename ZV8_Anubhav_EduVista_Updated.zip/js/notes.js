/* ==========================================================================
   NOTES.JS — Teacher Notes & Syllabus Management
   Computer Care (Anubhav EduVista) Academy Management System
   ========================================================================== */

let notesSession = null;

function initNotesPage() {
  notesSession = Auth.requireAuth(['admin','teacher','student']);
  if (!notesSession) return;
  renderNotesPage();
}

function renderNotesPage() {
  const isTeacher = notesSession.role === 'teacher' || notesSession.role === 'admin';
  const uploadForm = document.getElementById('noteUploadForm');
  if (uploadForm && !isTeacher) uploadForm.style.display = 'none';

  if (isTeacher) {
    populateNotesTargetDropdown();
  }
  renderNotesList();
}

function populateNotesTargetDropdown() {
  const sel = document.getElementById('noteTarget');
  if (!sel) return;
  const students = DB.getStudents();
  sel.innerHTML = `
    <option value="all">👥 All Students</option>
    <option value="batch1">📦 Batch 1</option>
    <option value="batch2">📦 Batch 2</option>
    <option value="batch3">📦 Batch 3</option>
    <optgroup label="👨‍🎓 Specific Student">
      ${students.map(s=>`<option value="student:${s.id}">${s.name} (${s.batchNo||'No batch'})</option>`).join('')}
    </optgroup>`;
}

function saveNote() {
  const title   = document.getElementById('noteTitle').value.trim();
  const subject = document.getElementById('noteSubject').value.trim();
  const content = document.getElementById('noteContent').value.trim();
  const target  = document.getElementById('noteTarget').value;
  const format  = document.getElementById('noteFormat').value;
  const fileInput = document.getElementById('noteFile');

  if (!title || !content) { Toast.warning('Title and content are required'); return; }

  const noteObj = {
    title, subject, content, target, format,
    createdBy: notesSession.name,
    createdById: notesSession.id,
    createdAt: new Date().toISOString(),
    fileData: null, fileName: '', fileType: '',
  };

  if (fileInput && fileInput.files && fileInput.files[0]) {
    const file = fileInput.files[0];
    const reader = new FileReader();
    reader.onload = (e) => {
      noteObj.fileData = e.target.result;
      noteObj.fileName = file.name;
      noteObj.fileType = file.type;
      DB.addTeacherNote(noteObj);
      renderNotesList();
      clearNoteForm();
      Toast.success('Note/Syllabus shared with students!');
    };
    reader.readAsDataURL(file);
  } else {
    DB.addTeacherNote(noteObj);
    renderNotesList();
    clearNoteForm();
    Toast.success('Note shared successfully!');
  }
}

function clearNoteForm() {
  ['noteTitle','noteSubject','noteContent'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  const fi = document.getElementById('noteFile');
  if (fi) fi.value = '';
}

function deleteNote(id) {
  if (!confirm('Delete this note?')) return;
  DB.deleteTeacherNote(id);
  renderNotesList();
  Toast.info('Note deleted');
}

function downloadNoteFile(noteId) {
  const notes = DB.getTeacherNotes();
  const note = notes.find(n=>n.id===noteId);
  if (!note || !note.fileData) { Toast.warning('No file attached'); return; }

  const a = document.createElement('a');
  a.href = note.fileData;
  a.download = note.fileName || 'note-file';
  a.click();
}

function printNoteContent(noteId) {
  const notes = DB.getTeacherNotes();
  const note = notes.find(n=>n.id===noteId);
  if (!note) return;
  const settings = DB.getSettings();

  const w = window.open('','_blank');
  w.document.write(`<!DOCTYPE html><html><head><title>${note.title}</title>
  <style>
    body{font-family:Georgia,serif;padding:40px;max-width:800px;margin:0 auto;color:#222;font-size:14px;line-height:1.7}
    h1{color:#047857;font-size:22px;border-bottom:2px solid #047857;padding-bottom:8px}
    h2{font-size:14px;color:#555;margin-bottom:4px}
    .meta{font-size:12px;color:#888;margin-bottom:20px}
    .content{white-space:pre-wrap;background:#f9f9f9;padding:20px;border-radius:8px;border:1px solid #eee}
    .header{text-align:center;margin-bottom:30px}
    .academy{font-size:20px;font-weight:700;color:#047857}
    @media print{button{display:none}}
  </style></head><body>
  <div class="header">
    <div class="academy">${settings.academyName}</div>
    <div style="font-size:12px;color:#666">${settings.address} | ${settings.mobile}</div>
    <hr>
  </div>
  <h1>${note.title}</h1>
  <div class="meta">
    ${note.subject?`<strong>Subject:</strong> ${note.subject} &nbsp;|&nbsp; `:''}
    <strong>Format:</strong> ${note.format||'Notes'} &nbsp;|&nbsp;
    <strong>By:</strong> ${note.createdBy} &nbsp;|&nbsp;
    <strong>Date:</strong> ${new Date(note.createdAt).toLocaleDateString('en-IN',{day:'2-digit',month:'long',year:'numeric'})}
  </div>
  <div class="content">${note.content}</div>
  <br>
  <button onclick="window.print()" style="padding:10px 24px;background:#047857;color:#fff;border:none;border-radius:6px;cursor:pointer">🖨️ Print</button>
  </body></html>`);
  w.document.close();
}

let notesFilter = 'all';

function filterNotesByTab(btn, filter) {
  document.querySelectorAll('.notes-filter-btn').forEach(b=>{ b.classList.remove('active'); b.classList.add('btn-secondary'); });
  btn.classList.add('active'); btn.classList.remove('btn-secondary');
  notesFilter = filter;
  renderNotesList();
}

function renderNotesList() {
  const listEl = document.getElementById('notesList');
  if (!listEl) return;

  let notes = DB.getTeacherNotes();

  // Filter by what student can see
  if (notesSession.role === 'student') {
    notes = notes.filter(n => {
      if (n.target === 'all') return true;
      if (n.target && n.target.startsWith('batch')) {
        const student = DB.getStudent(notesSession.id);
        if (!student) return false;
        const batchNum = n.target.replace('batch','');
        return student.batchNo === 'Batch '+batchNum;
      }
      if (n.target && n.target.startsWith('student:')) {
        return n.target === 'student:' + notesSession.id;
      }
      return false;
    });
  }

  // Filter by format tab
  if (notesFilter !== 'all') {
    notes = notes.filter(n => n.format === notesFilter);
  }

  if (!notes.length) {
    listEl.innerHTML = `<div class="empty-state"><div class="empty-state-icon">📚</div><p>${notesSession.role==='student'?'No notes shared with you yet':'No notes uploaded yet'}</p></div>`;
    return;
  }

  const formatIcons = {
    'Notes':'📝', 'Syllabus':'📋', 'Assignment':'📌', 'PDF':'📄',
    'Tutorial':'📖', 'Reference':'🔗', 'Practice Sheet':'🗒️', 'Other':'📁'
  };
  const canDelete = notesSession.role === 'admin' ||
    (notesSession.role === 'teacher' && notes.some(n=>n.createdById===notesSession.id));

  listEl.innerHTML = notes.map(n => `
    <div class="glass-card" style="margin-bottom:14px;padding:18px;border-left:4px solid var(--primary)">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap">
        <div style="display:flex;gap:14px;align-items:flex-start;flex:1">
          <div style="font-size:2rem;line-height:1">${formatIcons[n.format]||'📝'}</div>
          <div style="flex:1">
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px">
              <span style="font-weight:700;font-size:0.95rem">${n.title}</span>
              <span class="badge badge-primary" style="font-size:0.7rem">${n.format||'Notes'}</span>
              ${n.subject?`<span class="badge badge-secondary" style="font-size:0.7rem">📚 ${n.subject}</span>`:''}
            </div>
            <div style="font-size:0.85rem;color:var(--text-muted);line-height:1.6;white-space:pre-line;margin-bottom:10px">${n.content.slice(0,300)}${n.content.length>300?'...':''}</div>
            <div style="font-size:0.75rem;color:var(--text-muted)">
              👨‍🏫 ${n.createdBy} &nbsp;|&nbsp; 📅 ${new Date(n.createdAt).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})}
              ${n.target==='all'?'&nbsp;|&nbsp; 👥 All Students':n.target&&n.target.startsWith('batch')?`&nbsp;|&nbsp; 📦 Batch ${n.target.replace('batch','')}`:n.target&&n.target.startsWith('student:')?'&nbsp;|&nbsp; 👤 Specific Student':''}
            </div>
          </div>
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;flex-shrink:0">
          <button class="btn btn-sm btn-secondary" onclick="printNoteContent('${n.id}')">🖨 Print</button>
          ${n.fileData?`<button class="btn btn-sm btn-primary" onclick="downloadNoteFile('${n.id}')">⬇️ ${n.fileName||'File'}</button>`:''}
          ${notesSession.role==='admin'||(notesSession.role==='teacher'&&n.createdById===notesSession.id)?`<button class="btn btn-sm btn-danger" onclick="deleteNote('${n.id}')">🗑</button>`:''}
        </div>
      </div>
    </div>`).join('');
}

document.addEventListener('DOMContentLoaded', initNotesPage);

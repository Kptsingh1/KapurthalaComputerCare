/* ==========================================================================
   NOTIFICATIONS.JS — Emergency Notifications & Announcements
   Computer Care (Anubhav EduVista) Academy Management System
   ========================================================================== */

let notifSession = null;

function initNotificationsPage() {
  notifSession = Auth.requireAuth(['admin','teacher','student']);
  if (!notifSession) return;
  renderNotificationsPage();
}

function renderNotificationsPage() {
  const canManage = notifSession.role === 'admin' || notifSession.role === 'teacher';

  const form = document.getElementById('notifForm');
  if (form && !canManage) form.style.display = 'none';

  renderNotifList();
  updateNotifStats();
}

function updateNotifStats() {
  const all = DB.getNotifications().filter(n => DB.notificationAppliesToSession(n, notifSession));
  const unread = all.filter(n => !isNotifRead(n.id));

  const els = {
    statTotal:     document.getElementById('statNotifTotal'),
    statHoliday:   document.getElementById('statNotifHoliday'),
    statUrgent:    document.getElementById('statNotifUrgent'),
    statUnread:    document.getElementById('statNotifUnread'),
  };
  if (els.statTotal)   els.statTotal.textContent   = all.length;
  if (els.statHoliday) els.statHoliday.textContent = all.filter(n=>n.type==='Holiday').length;
  if (els.statUrgent)  els.statUrgent.textContent  = all.filter(n=>n.priority==='High').length;
  if (els.statUnread)  els.statUnread.textContent  = unread.length;
}

function isNotifRead(id) {
  const read = JSON.parse(localStorage.getItem('cc_notif_read') || '[]');
  return read.includes(id);
}
function markNotifRead(id) {
  const read = JSON.parse(localStorage.getItem('cc_notif_read') || '[]');
  if (!read.includes(id)) { read.push(id); localStorage.setItem('cc_notif_read', JSON.stringify(read)); }
}
function markAllRead() {
  const all = DB.getNotifications().filter(n => DB.notificationAppliesToSession(n, notifSession));
  const ids = all.map(n=>n.id);
  localStorage.setItem('cc_notif_read', JSON.stringify(ids));
  renderNotifList();
  updateNotifStats();
  Toast.success('All marked as read!');
}

function saveNotification() {
  const title    = document.getElementById('notifTitle').value.trim();
  const message  = document.getElementById('notifMessage').value.trim();
  const type     = document.getElementById('notifType').value;
  const target   = document.getElementById('notifTarget').value;
  const date     = document.getElementById('notifDate').value;
  const priority = document.getElementById('notifPriority').value;

  if (!title || !message) { Toast.warning('Title and message are required'); return; }

  const icons = { Holiday:'🏖️', Announcement:'📢', Meeting:'👔', Fee:'💰', Exam:'📝', Event:'🎉', Emergency:'🚨', Other:'📌' };

  DB.addNotification({
    title, message, type, target, date, priority,
    icon: icons[type] || '📌',
    createdBy: notifSession.name || notifSession.username,
    createdByRole: notifSession.role,
  });

  // Clear form
  document.getElementById('notifTitle').value = '';
  document.getElementById('notifMessage').value = '';
  document.getElementById('notifDate').value = new Date().toISOString().slice(0,10);

  renderNotifList();
  updateNotifStats();
  Toast.success('Notification sent!');
  showAutoSave();
}

function generateFeeReminderNow() {
  const result = DB.generateMonthlyFeeReminders(new Date(), { force:true });
  renderNotifList();
  updateNotifStats();
  Toast.success(`Pending fee reminders updated (${result.created} notice entries)`);
  showAutoSave();
}

function deleteNotification(id) {
  if (!confirm('Delete this notification?')) return;
  DB.deleteNotification(id);
  renderNotifList();
  updateNotifStats();
  Toast.info('Notification deleted');
}

let notifFilter = 'all';

function filterNotifs(btn, type) {
  document.querySelectorAll('.notif-filter-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  notifFilter = type;
  renderNotifList();
}

function renderNotifList() {
  const listEl = document.getElementById('notifList');
  if (!listEl) return;

  let notifs = DB.getNotifications().filter(n => DB.notificationAppliesToSession(n, notifSession));

  // Filter by type tab
  if (notifFilter !== 'all') {
    notifs = notifs.filter(n => n.type === notifFilter);
  }

  if (!notifs.length) {
    listEl.innerHTML = `<div class="empty-state"><div class="empty-state-icon">🔔</div><p>No notifications found</p></div>`;
    return;
  }

  const priorityColors = { High:'var(--danger)', Medium:'var(--warning)', Low:'var(--success)' };
  const typeColors = {
    Holiday:'rgba(251,191,36,0.1)', Announcement:'rgba(94,234,212,0.1)',
    Meeting:'rgba(139,156,255,0.1)', Fee:'rgba(251,113,133,0.1)',
    Exam:'rgba(147,197,253,0.1)', Event:'rgba(52,211,153,0.1)',
    Emergency:'rgba(251,113,133,0.15)', Other:'rgba(255,255,255,0.05)'
  };
  const borderColors = {
    Holiday:'rgba(251,191,36,0.3)', Announcement:'rgba(94,234,212,0.3)',
    Meeting:'rgba(139,156,255,0.3)', Fee:'rgba(251,113,133,0.3)',
    Exam:'rgba(147,197,253,0.3)', Event:'rgba(52,211,153,0.3)',
    Emergency:'rgba(251,113,133,0.4)', Other:'rgba(255,255,255,0.1)'
  };

  const canManage = notifSession.role === 'admin';

  listEl.innerHTML = notifs.map(n => {
    const read = isNotifRead(n.id);
    return `<div class="glass-card notif-card" id="nc-${n.id}"
      style="margin-bottom:14px;padding:18px;background:${typeColors[n.type]||'rgba(255,255,255,0.05)'};
      border:1px solid ${borderColors[n.type]||'var(--glass-border)'};
      border-left:4px solid ${priorityColors[n.priority]||'var(--primary)'};
      opacity:${read?'0.75':'1'};transition:all 0.2s"
      onclick="markNotifRead('${n.id}');document.getElementById('nc-${n.id}').style.opacity=0.75">

      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap">
        <div style="display:flex;gap:14px;align-items:flex-start;flex:1">
          <div style="font-size:2rem;line-height:1">${n.icon||'📌'}</div>
          <div style="flex:1">
            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px">
              <span style="font-weight:700;font-size:0.95rem">${n.title}</span>
              ${!read?'<span style="width:8px;height:8px;background:var(--danger);border-radius:50%;display:inline-block"></span>':''}
              <span class="badge" style="background:${typeColors[n.type]||'var(--glass-bg-heavy)'};color:inherit;font-size:0.7rem">${n.type}</span>
              <span class="badge" style="background:${priorityColors[n.priority]||'var(--primary)'}22;color:${priorityColors[n.priority]||'var(--primary)'};font-size:0.7rem">${n.priority}</span>
              ${n.target!=='all'?`<span class="badge badge-secondary" style="font-size:0.7rem">→ ${n.target==='students'?'👨‍🎓 Students':'👨‍🏫 Teachers'}</span>`:'<span class="badge badge-secondary" style="font-size:0.7rem">→ Everyone</span>'}
            </div>
            <div style="color:var(--text-muted);font-size:0.88rem;line-height:1.6;white-space:pre-line">${n.message}</div>
            <div style="display:flex;gap:16px;margin-top:10px;font-size:0.75rem;color:var(--text-muted)">
              ${n.date?`<span>📅 Effective: ${Fmt.date(n.date)}</span>`:''}
              <span>🕒 Posted: ${Fmt.date((n.createdAt||'').slice(0,10))}</span>
              <span>By: ${n.createdBy||'Admin'}</span>
            </div>
          </div>
        </div>
        <div style="display:flex;gap:6px;flex-shrink:0">
          ${canManage?`<button class="btn btn-sm btn-danger" onclick="event.stopPropagation();deleteNotification('${n.id}')">🗑</button>`:''}
        </div>
      </div>
    </div>`;
  }).join('');
}

document.addEventListener('DOMContentLoaded', initNotificationsPage);

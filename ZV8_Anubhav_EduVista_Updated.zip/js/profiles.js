/* ==========================================================================
   PROFILES.JS — Student & Teacher Profile Pages
   Full-detail read-only profile cards accessible from both portals.
   ========================================================================== */

const Profiles = (() => {

  function studentProfileHTML(s) {
    if (!s) return '<p style="color:var(--danger)">Student not found.</p>';
    const paid = DB.paidFees ? DB.paidFees(s.id) : 0;
    const balance = (s.totalFees || 0) - paid;
    const attMonths = Object.keys(DB.getAttendance ? DB.getAttendance() || {} : {});
    let totalP = 0, totalA = 0, totalL = 0;
    attMonths.forEach(m => {
      const days = ((DB.getAttendance() || {})[m] || {})[s.id] || {};
      const vals = Object.values(days);
      totalP += vals.filter(v => v === 'P').length;
      totalA += vals.filter(v => v === 'A').length;
      totalL += vals.filter(v => v === 'L').length;
    });
    const totalMarked = totalP + totalA + totalL;
    const attPct = totalMarked ? Math.round((totalP / totalMarked) * 100) : 0;

    const topics = (DB.getTopics ? DB.getTopics() : []).filter(t => t.studentId === s.id || t.studentName === s.name);

    const statusColors = { 'Continue': 'badge-primary', 'Complete': 'badge-success', 'Pending': 'badge-warning', 'Leave': 'badge-warning', 'Left': 'badge-danger' };

    return `
    <div class="profile-page-wrap">
      <!-- Hero Banner -->
      <div class="profile-hero" style="background:linear-gradient(135deg,var(--bg-deep-3),var(--bg-deep-4));border-radius:var(--radius-lg);padding:28px 24px;margin-bottom:20px;position:relative;overflow:hidden;border:1px solid var(--glass-border)">
        <div style="position:absolute;inset:0;background:var(--bg-gradient);opacity:0.3"></div>
        <div style="position:relative;display:flex;align-items:center;gap:20px;flex-wrap:wrap">
          <div style="width:80px;height:80px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:2rem;font-weight:700;background:linear-gradient(135deg,var(--primary),var(--secondary));color:var(--bg-deep-1);flex-shrink:0;border:3px solid var(--glass-border-highlight);overflow:hidden">
            ${s.profileImage ? `<img src="${s.profileImage}" style="width:100%;height:100%;object-fit:cover">` : s.name.charAt(0).toUpperCase()}
          </div>
          <div style="flex:1;min-width:200px">
            <div style="font-size:1.5rem;font-weight:700;color:var(--text-main)">${s.name}</div>
            <div style="color:var(--primary);font-size:0.9rem;margin:4px 0">${s.course || '—'}</div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
              <span class="badge ${statusColors[s.courseStatus] || 'badge-info'}">${s.courseStatus || '—'}</span>
              <span class="badge badge-secondary">${s.batchNo || '—'}</span>
              <span class="badge badge-secondary">PC: ${s.pcNo || '—'}</span>
            </div>
          </div>
          <div style="text-align:right;min-width:130px">
            <div style="font-size:0.75rem;color:var(--text-muted)">Admission</div>
            <div style="font-weight:600;color:var(--text-main)">${s.admissionDate ? new Date(s.admissionDate).toLocaleDateString('en-IN') : '—'}</div>
            <div style="font-size:0.75rem;color:var(--text-muted);margin-top:4px">Timings</div>
            <div style="font-size:0.8rem;color:var(--accent)">${s.timings || '—'}</div>
          </div>
        </div>
      </div>

      <!-- Stats Row -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px;margin-bottom:20px">
        ${[
          ['💰', 'Total Fees', `₹${(s.totalFees||0).toLocaleString('en-IN')}`, 'var(--primary)'],
          ['✅', 'Paid', `₹${paid.toLocaleString('en-IN')}`, 'var(--success)'],
          ['⚠️', 'Balance', `₹${balance.toLocaleString('en-IN')}`, balance > 0 ? 'var(--danger)' : 'var(--success)'],
          ['📋', 'Attendance', `${attPct}%`, attPct >= 75 ? 'var(--success)' : 'var(--danger)'],
          ['📚', 'Topics Done', topics.length, 'var(--secondary)'],
          ['🎓', 'Grade', s.grade || 'N/A', 'var(--accent)'],
        ].map(([icon, label, val, color]) => `
        <div class="glass-panel" style="padding:12px;text-align:center;border-left:3px solid ${color}">
          <div style="font-size:1.5rem">${icon}</div>
          <div style="font-size:1.1rem;font-weight:700;color:${color}">${val}</div>
          <div style="font-size:0.72rem;color:var(--text-muted)">${label}</div>
        </div>`).join('')}
      </div>

      <!-- Details Grid -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin-bottom:20px">
        <!-- Personal Info -->
        <div class="glass-panel" style="padding:16px">
          <h4 style="margin-bottom:12px;color:var(--primary)">👤 Personal Details</h4>
          ${profileRows([
            ['Father', s.fatherName], ['Mother', s.motherName], ['Gender', s.gender],
            ['DOB', s.dob], ['Mobile', s.mobile], ['Alt Mobile', s.altMobile],
            ['Email', s.email], ['Aadhaar', s.aadhaar], ['Qualification', s.qualification],
            ['Religion', s.religion], ['Caste', s.caste], ['Marital Status', s.maritalStatus],
          ])}
        </div>
        <!-- Academic Info -->
        <div class="glass-panel" style="padding:16px">
          <h4 style="margin-bottom:12px;color:var(--secondary)">🎓 Academic Details</h4>
          ${profileRows([
            ['Course', s.course], ['Batch', s.batchNo], ['Device', s.pcNo],
            ['Timings', s.timings], ['Day', s.day], ['Duration', s.duration],
            ['Monthly Fees', `₹${s.monthlyFees || 0}`], ['Percentage', s.percentage ? s.percentage + '%' : '—'],
            ['Grade', s.grade], ['Rank', s.rank], ['Feedback', s.feedback],
          ])}
        </div>
        <!-- Address Info -->
        <div class="glass-panel" style="padding:16px">
          <h4 style="margin-bottom:12px;color:var(--accent)">📍 Address & Family</h4>
          ${profileRows([
            ['Address', s.address], ['Landmark', s.landmark], ['Village', s.village],
            ['District', s.district], ['Pincode', s.pincode], ['State', s.state],
            ['Family Members', s.familyMembers], ['Annual Income', s.annualIncome ? `₹${s.annualIncome}` : '—'],
            ['Father Occupation', s.fatherOccupation], ['Mother Occupation', s.motherOccupation],
            ['Reference', s.reference], ['Occupation', s.occupation],
          ])}
        </div>
      </div>

      <!-- Topics Table -->
      ${topics.length ? `
      <div class="glass-panel" style="padding:0;margin-bottom:16px">
        <div style="padding:14px 18px;border-bottom:1px solid var(--glass-border)">
          <h4 style="color:var(--primary);margin:0">📚 Daily Topics Covered (${topics.length})</h4>
        </div>
        <div class="table-container" style="max-height:240px;overflow-y:auto">
          <table>
            <thead><tr><th>Date</th><th>Topic</th><th>Course</th><th>Teacher</th><th>Status</th></tr></thead>
            <tbody>
              ${topics.slice(0, 50).map(t => `
              <tr>
                <td style="font-size:0.8rem">${t.date || '—'}</td>
                <td style="font-size:0.82rem;font-weight:500">${t.title || '—'}</td>
                <td style="font-size:0.8rem">${t.course || '—'}</td>
                <td style="font-size:0.8rem">${t.teacher || '—'}</td>
                <td><span class="badge ${t.status === 'Completed' ? 'badge-success' : t.status === 'In Progress' ? 'badge-primary' : 'badge-warning'}" style="font-size:0.7rem">${t.status || 'Pending'}</span></td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>` : ''}
    </div>`;
  }

  function teacherProfileHTML(t) {
    if (!t) return '<p style="color:var(--danger)">Teacher not found.</p>';
    const salaryRaw = JSON.parse(localStorage.getItem('cc_salary') || '{}');
    const salaryRecord = salaryRaw[t.id] || {};
    const payments = salaryRecord.records || [];
    const totalPaid = payments.reduce((s, p) => s + (Number(p.amount) || 0), 0);
    const studentsUnder = (DB.getStudents ? DB.getStudents() : []).filter(s => s.course && t.subject && s.course.toLowerCase().includes(t.subject.toLowerCase().split(' ')[0]));

    return `
    <div class="profile-page-wrap">
      <!-- Hero -->
      <div class="profile-hero" style="background:linear-gradient(135deg,var(--bg-deep-3),var(--bg-deep-4));border-radius:var(--radius-lg);padding:28px 24px;margin-bottom:20px;border:1px solid var(--glass-border)">
        <div style="display:flex;align-items:center;gap:20px;flex-wrap:wrap">
          <div style="width:80px;height:80px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:2rem;font-weight:700;background:linear-gradient(135deg,var(--secondary),var(--info));color:#fff;flex-shrink:0;border:3px solid var(--glass-border-highlight);overflow:hidden">
            ${t.profileImage ? `<img src="${t.profileImage}" style="width:100%;height:100%;object-fit:cover">` : t.name.charAt(0).toUpperCase()}
          </div>
          <div style="flex:1">
            <div style="font-size:1.5rem;font-weight:700;color:var(--text-main)">${t.name}</div>
            <div style="color:var(--secondary);font-size:0.9rem;margin:4px 0">${t.subject || '—'} • ${t.qualification || '—'}</div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
              <span class="badge ${t.active ? 'badge-success' : 'badge-danger'}">${t.active ? 'Active' : 'Inactive'}</span>
              <span class="badge badge-secondary">${t.performance || 'Good'}</span>
            </div>
          </div>
          <div style="text-align:right">
            <div style="font-size:0.75rem;color:var(--text-muted)">Join Date</div>
            <div style="font-weight:600">${t.joinDate ? new Date(t.joinDate).toLocaleDateString('en-IN') : '—'}</div>
            <div style="font-size:0.75rem;color:var(--text-muted);margin-top:4px">Base Salary</div>
            <div style="color:var(--success);font-weight:700">₹${(t.salary || 0).toLocaleString('en-IN')}/mo</div>
          </div>
        </div>
      </div>

      <!-- Stats -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px;margin-bottom:20px">
        ${[
          ['💰', 'Total Paid', `₹${totalPaid.toLocaleString('en-IN')}`, 'var(--success)'],
          ['📚', 'Payments', payments.length, 'var(--primary)'],
          ['👥', 'Students', studentsUnder.length, 'var(--secondary)'],
          ['⭐', 'Performance', t.performance || 'N/A', 'var(--accent)'],
        ].map(([icon, label, val, color]) => `
        <div class="glass-panel" style="padding:12px;text-align:center;border-left:3px solid ${color}">
          <div style="font-size:1.5rem">${icon}</div>
          <div style="font-size:1.1rem;font-weight:700;color:${color}">${val}</div>
          <div style="font-size:0.72rem;color:var(--text-muted)">${label}</div>
        </div>`).join('')}
      </div>

      <!-- Details -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px">
        <div class="glass-panel" style="padding:16px">
          <h4 style="margin-bottom:12px;color:var(--secondary)">👤 Personal & Contact</h4>
          ${profileRows([
            ['Gender', t.gender], ['DOB', t.dob], ['Mobile', t.mobile],
            ['Email', t.email], ['Address', t.address], ['Qualification', t.qualification],
          ])}
        </div>
        <div class="glass-panel" style="padding:16px">
          <h4 style="margin-bottom:12px;color:var(--primary)">💼 Work Details</h4>
          ${profileRows([
            ['Subject', t.subject], ['Join Date', t.joinDate], ['Salary', `₹${t.salary || 0}`],
            ['Performance', t.performance], ['Status', t.active ? 'Active' : 'Inactive'],
          ])}
        </div>
      </div>

      <!-- Salary Payments -->
      ${payments.length ? `
      <div class="glass-panel" style="padding:0;margin-top:16px">
        <div style="padding:14px 18px;border-bottom:1px solid var(--glass-border)">
          <h4 style="color:var(--secondary);margin:0">💼 Salary Payment History</h4>
        </div>
        <div class="table-container" style="max-height:240px;overflow-y:auto">
          <table>
            <thead><tr><th>Date</th><th>Amount</th><th>Mode</th><th>Note</th></tr></thead>
            <tbody>
              ${payments.map(p => `
              <tr>
                <td style="font-size:0.8rem">${p.date || '—'}</td>
                <td style="color:var(--success);font-weight:600">₹${Number(p.amount).toLocaleString('en-IN')}</td>
                <td style="font-size:0.8rem">${p.mode || 'Cash'}</td>
                <td style="font-size:0.8rem;color:var(--text-muted)">${p.note || '—'}</td>
              </tr>`).join('')}
            </tbody>
          </table>
        </div>
      </div>` : ''}
    </div>`;
  }

  function profileRows(pairs) {
    return pairs.filter(([,v]) => v !== null && v !== undefined && v !== '')
      .map(([label, val]) => `
      <div style="display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--glass-border);font-size:0.82rem">
        <span style="color:var(--text-muted);flex:0 0 130px">${label}</span>
        <span style="color:var(--text-main);text-align:right;flex:1;word-break:break-word">${val || '—'}</span>
      </div>`).join('');
  }

  function openStudentProfile(id) {
    const s = DB.getStudent ? DB.getStudent(id) : null;
    openProfileModal('student', s ? s.name : 'Student Profile', studentProfileHTML(s));
  }

  function openTeacherProfile(id) {
    const t = DB.getTeacher ? DB.getTeacher(id) : null;
    openProfileModal('teacher', t ? t.name : 'Teacher Profile', teacherProfileHTML(t));
  }

  function openProfileModal(type, title, html) {
    const modalId = 'profileViewModal';
    let modal = document.getElementById(modalId);
    if (!modal) {
      const el = document.createElement('div');
      el.innerHTML = `
      <div class="modal-overlay" id="${modalId}">
        <div class="modal" style="max-width:860px">
          <div class="modal-header">
            <h3 class="modal-title" id="profileModalTitle">Profile</h3>
            <button class="modal-close" onclick="Modal.close('${modalId}')">✕</button>
          </div>
          <div class="modal-body" style="max-height:80vh;overflow-y:auto;padding:0 24px 24px" id="profileModalBody"></div>
        </div>
      </div>`;
      document.body.appendChild(el.firstElementChild);
      modal = document.getElementById(modalId);
    }
    document.getElementById('profileModalTitle').textContent = (type === 'teacher' ? '👨‍🏫 ' : '👨‍🎓 ') + title;
    document.getElementById('profileModalBody').innerHTML = html;
    Modal.open(modalId);
  }

  return { openStudentProfile, openTeacherProfile, studentProfileHTML, teacherProfileHTML };
})();

window.Profiles = Profiles;

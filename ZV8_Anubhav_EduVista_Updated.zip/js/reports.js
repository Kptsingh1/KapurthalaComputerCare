/* ==========================================================================
   REPORTS.JS — Reports, Certificates, DMC, PDF Export
   ========================================================================== */

function initReportsPage() {
  const session = Auth.requireAuth(['admin','teacher']);
  if (!session) return;
  populateStudentDropdown();
  renderReportsSummary();
}

function populateStudentDropdown() {
  const students = DB.getStudents();
  const teachers = DB.getTeachers();
  ['certStudentId','dmcStudentId','profileStudentId'].forEach(id=>{
    const sel = document.getElementById(id);
    if (!sel) return;
    sel.innerHTML = `<option value="">-- Select Student --</option>` +
      students.map(s=>`<option value="${s.id}">${s.name} — ${s.course||'—'}</option>`).join('');
  });
  const teacherSel = document.getElementById('profileTeacherId');
  if (teacherSel) {
    teacherSel.innerHTML = `<option value="">-- Select Teacher --</option>` +
      teachers.map(t=>`<option value="${t.id}">${t.name} — ${t.subject||'Faculty'}</option>`).join('');
  }
}

function renderReportsSummary() {
  const students = DB.getStudents();
  const teachers = DB.getTeachers();
  let totalFees=0, paidFees=0;
  students.forEach(s=>{ totalFees+=s.totalFees||0; paidFees+=DB.paidFees(s.id); });

  const el=id=>document.getElementById(id);
  const set=(id,v)=>{const e=el(id);if(e)e.textContent=v;};
  set('rpTotalStudents', students.length);
  set('rpTotalTeachers', teachers.length);
  set('rpTotalFees', Fmt.currency(totalFees));
  set('rpCollected', Fmt.currency(paidFees));
  set('rpPending', Fmt.currency(totalFees-paidFees));
  set('rpCompleted', students.filter(s=>s.courseStatus==='Complete').length);
}

/* ---- CERTIFICATE ---- */
function generateCertificate() {
  const studentId = document.getElementById('certStudentId').value;
  if (!studentId) { Toast.warning('Select a student'); return; }
  const student = DB.getStudent(studentId);
  if (!student) return;
  const settings = DB.getSettings();
  const certNo = 'CC-' + Date.now().toString().slice(-6);
  const today = new Date().toLocaleDateString('en-IN',{day:'numeric',month:'long',year:'numeric'});

  const html = `
    <div style="border:8px double #047857;padding:48px;text-align:center;position:relative;font-family:'Times New Roman',serif">
      <div style="position:absolute;top:20px;left:20px;font-size:60px;opacity:0.05;font-weight:900;color:#047857">CC</div>
      <div style="position:absolute;top:20px;right:20px;font-size:60px;opacity:0.05;font-weight:900;color:#047857">CC</div>
      
      <div style="color:#047857;font-size:14px;letter-spacing:2px;text-transform:uppercase;margin-bottom:8px">
        ${settings.academyName}
      </div>
      <div style="font-size:11px;color:#666;margin-bottom:24px">${settings.address}<br>${settings.mobile} | ${settings.website}</div>
      
      <div style="border-top:2px solid #047857;border-bottom:2px solid #047857;padding:8px 0;margin:0 auto 24px;display:inline-block;width:80%">
        <div style="font-size:32px;font-weight:700;color:#047857;letter-spacing:3px">CERTIFICATE</div>
        <div style="font-size:14px;color:#666;letter-spacing:2px">OF COMPLETION</div>
      </div>

      <p style="font-size:14px;margin-bottom:12px">This is to certify that</p>
      <div style="font-size:28px;font-weight:700;color:#0f172a;border-bottom:2px solid #ccc;display:inline-block;padding-bottom:4px;margin-bottom:12px">${student.name}</div>
      
      <p style="font-size:13px;margin:12px 0">Son/Daughter of <strong>${student.fatherName||'—'}</strong></p>
      <p style="font-size:13px;margin:12px 0">has successfully completed the course of</p>
      <div style="font-size:22px;font-weight:700;color:#047857;margin:16px 0">${student.course||'—'}</div>
      
      ${student.subcategories&&student.subcategories.length?`<p style="font-size:12px;color:#666;margin-bottom:12px">Covering: ${student.subcategories.join(', ')}</p>`:''}
      
      <div style="display:flex;justify-content:center;gap:40px;margin:16px 0;font-size:13px">
        <div><strong>Duration:</strong> ${student.duration||'—'}</div>
        ${student.grade?`<div><strong>Grade:</strong> ${student.grade}</div>`:''}
        ${student.percentage?`<div><strong>Score:</strong> ${student.percentage}%</div>`:''}
      </div>
      
      <p style="font-size:12px;color:#666;margin:16px 0">Certificate No: <strong>${certNo}</strong> &nbsp;|&nbsp; Date: <strong>${today}</strong></p>
      
      <div style="display:flex;justify-content:space-around;margin-top:40px;padding-top:20px;border-top:1px solid #ccc">
        <div style="text-align:center;font-size:12px">
          <div style="border-top:1px solid #333;padding-top:8px;width:120px">Student Signature</div>
        </div>
        <div style="text-align:center;font-size:12px">
          <div style="font-weight:700;color:#047857;margin-bottom:4px">Computer Care</div>
          <div style="border-top:1px solid #333;padding-top:8px;width:120px">Authorized Signatory</div>
        </div>
      </div>
    </div>`;

  Exporter.toPDF_simple('Certificate — ' + student.name, html);
  Toast.success('Certificate generated!');
}

/* ---- DMC (Detail Marks Card) ---- */
function generateDMC() {
  const studentId = document.getElementById('dmcStudentId').value;
  if (!studentId) { Toast.warning('Select a student'); return; }
  const student = DB.getStudent(studentId);
  if (!student) return;
  const settings = DB.getSettings();
  const dmcNo = 'DMC-' + Date.now().toString().slice(-6);
  const today = new Date().toLocaleDateString('en-IN',{day:'numeric',month:'long',year:'numeric'});

  const subcats = student.subcategories || [];
  const marksRows = subcats.map(sub=>{
    const marks = (student.marks||{})[sub] || { theory:0, practical:0, total:0, grade:'' };
    return `<tr>
      <td style="border:1px solid #ccc;padding:8px">${sub}</td>
      <td style="border:1px solid #ccc;padding:8px;text-align:center">100</td>
      <td style="border:1px solid #ccc;padding:8px;text-align:center">${marks.theory||'—'}</td>
      <td style="border:1px solid #ccc;padding:8px;text-align:center">${marks.practical||'—'}</td>
      <td style="border:1px solid #ccc;padding:8px;text-align:center">${marks.total||'—'}</td>
      <td style="border:1px solid #ccc;padding:8px;text-align:center">${marks.grade||'—'}</td>
    </tr>`;
  }).join('');

  const html = `
    <div style="border:3px solid #047857;padding:32px;font-family:Arial,sans-serif">
      <div style="display:flex;justify-content:space-between;align-items:start;border-bottom:2px solid #047857;padding-bottom:16px;margin-bottom:16px">
        <div>
          <div style="font-size:18px;font-weight:700;color:#047857">${settings.academyName}</div>
          <div style="font-size:11px;color:#666">${settings.address}</div>
          <div style="font-size:11px;color:#666">${settings.mobile} | ${settings.email}</div>
        </div>
        <div style="text-align:center">
          <div style="font-size:20px;font-weight:700;color:#047857">DETAIL MARKS CARD</div>
          <div style="font-size:11px;color:#666">DMC No: ${dmcNo}</div>
          <div style="font-size:11px;color:#666">Date: ${today}</div>
        </div>
      </div>
      
      <table style="width:100%;font-size:12px;border-collapse:collapse;margin-bottom:16px">
        <tr>
          <td style="padding:4px;width:50%"><strong>Student Name:</strong> ${student.name}</td>
          <td style="padding:4px"><strong>Father's Name:</strong> ${student.fatherName||'—'}</td>
        </tr>
        <tr>
          <td style="padding:4px"><strong>Course:</strong> ${student.course||'—'}</td>
          <td style="padding:4px"><strong>Duration:</strong> ${student.duration||'—'}</td>
        </tr>
        <tr>
          <td style="padding:4px"><strong>Batch:</strong> ${student.batchNo||'—'}</td>
          <td style="padding:4px"><strong>Admission Date:</strong> ${Fmt.date(student.admissionDate)}</td>
        </tr>
      </table>

      <table style="width:100%;border-collapse:collapse;font-size:12px;margin-bottom:16px">
        <thead>
          <tr style="background:#047857;color:#fff">
            <th style="border:1px solid #ccc;padding:8px;text-align:left">Subject/Topic</th>
            <th style="border:1px solid #ccc;padding:8px">Max Marks</th>
            <th style="border:1px solid #ccc;padding:8px">Theory</th>
            <th style="border:1px solid #ccc;padding:8px">Practical</th>
            <th style="border:1px solid #ccc;padding:8px">Total</th>
            <th style="border:1px solid #ccc;padding:8px">Grade</th>
          </tr>
        </thead>
        <tbody>${marksRows||'<tr><td colspan="6" style="text-align:center;padding:12px;border:1px solid #ccc">No subjects recorded</td></tr>'}</tbody>
      </table>

      <div style="display:flex;justify-content:space-between;background:#f0fdf4;padding:12px;border-radius:4px;font-size:13px">
        <span><strong>Overall Grade:</strong> ${student.grade||'—'}</span>
        <span><strong>Percentage:</strong> ${student.percentage||0}%</span>
        <span><strong>Result:</strong> ${student.courseStatus==='Complete'?'<span style="color:green">PASS</span>':'—'}</span>
        <span><strong>Rank:</strong> ${student.rank||'—'}</span>
      </div>

      <div style="display:flex;justify-content:space-around;margin-top:32px;padding-top:16px;border-top:1px solid #ccc;font-size:12px">
        <div><div style="border-top:1px solid #333;padding-top:6px;width:100px;text-align:center">Examiner</div></div>
        <div><div style="border-top:1px solid #333;padding-top:6px;width:100px;text-align:center">Principal</div></div>
        <div><div style="border-top:1px solid #333;padding-top:6px;width:100px;text-align:center">Student</div></div>
      </div>
    </div>`;

  Exporter.toPDF_simple('DMC — ' + student.name, html);
  Toast.success('DMC generated!');
}

/* ---- STUDENT PROFILE ---- */
function generateStudentProfile() {
  const studentId = document.getElementById('profileStudentId').value;
  if (!studentId) { Toast.warning('Select a student'); return; }
  const student = DB.getStudent(studentId);
  if (!student) return;
  const settings = DB.getSettings();
  const paid = DB.paidFees(studentId);
  const balance = (student.totalFees||0)-paid;

  const rows = [
    ['Full Name',student.name],['Father\'s Name',student.fatherName||'—'],['Mother\'s Name',student.motherName||'—'],
    ['Date of Birth',Fmt.date(student.dob)],['Gender',student.gender||'—'],['Mobile',student.mobile||'—'],
    ['Email',student.email||'—'],['Aadhaar',student.aadhaar||'—'],['Qualification',student.qualification||'—'],
    ['Religion',student.religion||'—'],['Caste',student.caste||'—'],['Marital Status',student.maritalStatus||'—'],
    ['Address',`${student.address||''}, ${student.village||''}, ${student.district||''}, ${student.state||''} - ${student.pincode||''}`],
    ['Course',student.course||'—'],['Batch',student.batchNo||'—'],['PC/Laptop',student.pcNo||'—'],
    ['Timings',student.timings||'—'],['Admission Date',Fmt.date(student.admissionDate)],
    ['Course Status',student.courseStatus||'—'],['Total Fees',Fmt.currency(student.totalFees||0)],
    ['Paid Fees',Fmt.currency(paid)],['Balance Due',Fmt.currency(balance)],
    ['Grade',student.grade||'—'],['Percentage',student.percentage+'%'],
  ].map(([k,v])=>`<tr><td style="border:1px solid #eee;padding:7px;font-weight:600;width:40%;background:#f8f9fa">${k}</td><td style="border:1px solid #eee;padding:7px">${v}</td></tr>`).join('');

  Exporter.toPDF_simple('Profile — '+student.name, `
    <div style="border:2px solid #047857;border-radius:8px;overflow:hidden">
      <div style="background:#047857;color:#fff;padding:16px 24px">
        <div style="font-size:18px;font-weight:700">${settings.academyName}</div>
        <div style="font-size:12px;opacity:0.8">Student Profile Report</div>
      </div>
      <div style="padding:20px">
        <table style="width:100%;border-collapse:collapse;font-size:13px">${rows}</table>
      </div>
    </div>`);
  Toast.success('Profile PDF generated!');
}

/* ---- TEACHER PROFILE ---- */
function canViewTeacherFinancialsReport(teacher) {
  const session = Auth.getSession ? Auth.getSession() : null;
  return !!session && (session.role === 'admin' || session.id === teacher.id);
}

function generateTeacherProfile() {
  const teacherId = document.getElementById('profileTeacherId')?.value;
  if (!teacherId) { Toast.warning('Select a teacher'); return; }
  const teacher = DB.getTeacher(teacherId);
  if (!teacher) return;

  const settings = DB.getSettings();
  const currentMonth = new Date().toISOString().slice(0, 7);
  const attendance = DB.attendanceSummary(teacher.id, currentMonth);
  const salary = DB.getSalary ? DB.getSalary(teacher.id) : { records:[], baseSalary:0 };
  const salaryRecords = salary.records || [];
  const baseSalary = Number(salary.baseSalary || teacher.salary || 0);
  const salaryPaid = salaryRecords.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
  const showFinancials = canViewTeacherFinancialsReport(teacher);
  const image = teacher.profileImage
    ? `<img src="${teacher.profileImage}" alt="${Fmt.escape(teacher.name)}" style="width:88px;height:88px;object-fit:cover;border-radius:14px;border:2px solid #2563eb">`
    : `<div style="width:88px;height:88px;border-radius:14px;border:2px solid #2563eb;display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:800;color:#2563eb">${Fmt.initials(teacher.name)}</div>`;

  const rows = [
    ['Teacher ID', teacher.id],
    ['Full Name', teacher.name],
    ['Qualification', teacher.qualification],
    ['Subject / Expertise', teacher.subject],
    ['Mobile', teacher.mobile],
    ['Email', teacher.email],
    ['Gender', teacher.gender],
    ['Date of Birth', Fmt.date(teacher.dob)],
    ['Join Date', Fmt.date(teacher.joinDate)],
    ['Performance', teacher.performance],
    ['Username', teacher.username],
    ['Status', teacher.active ? 'Active' : 'Inactive'],
    ['Address', teacher.address],
    ['Current Month Present', attendance.present],
    ['Current Month Absent', attendance.absent],
    ['Current Month Leave', attendance.leave],
  ];

  if (showFinancials) {
    rows.push(['Base Salary', Fmt.currency(baseSalary)]);
    rows.push(['Salary Paid Records', String(salaryRecords.length)]);
    rows.push(['Total Salary Paid', Fmt.currency(salaryPaid)]);
  }

  const details = rows
    .map(([k, v]) => `<tr><td style="border:1px solid #eee;padding:7px;font-weight:600;width:38%;background:#f5f8ff">${Fmt.escape(k)}</td><td style="border:1px solid #eee;padding:7px">${Fmt.escape(v || '-')}</td></tr>`)
    .join('');

  Exporter.toPDF_simple('Teacher Profile - ' + teacher.name, `
    <div style="border:2px solid #2563eb;border-radius:8px;overflow:hidden">
      <div style="display:flex;gap:16px;align-items:center;background:#2563eb;color:#fff;padding:16px 22px">
        ${image}
        <div>
          <div style="font-size:20px;font-weight:800">${Fmt.escape(teacher.name)}</div>
          <div style="font-size:12px;opacity:0.88">${Fmt.escape(teacher.subject || 'Faculty')} | ${Fmt.escape(teacher.qualification || '')}</div>
          <div style="font-size:12px;opacity:0.88">${Fmt.escape(settings.academyName || 'Computer Care')}</div>
        </div>
      </div>
      <div style="padding:20px;background:#fff">
        <table style="width:100%;border-collapse:collapse;font-size:13px">${details}</table>
      </div>
    </div>`);
  Toast.success('Teacher profile PDF generated!');
}

/* ---- BULK EXPORTS ---- */
function exportAllStudentsPDF() {
  const students = DB.getStudents();
  const rows = students.map(s=>{
    const paid=DB.paidFees(s.id);
    return `<tr><td>${s.name}</td><td>${s.course||'—'}</td><td>${s.batchNo||'—'}</td><td>${s.mobile||'—'}</td><td>${s.courseStatus||'—'}</td><td>${Fmt.currency(paid)}</td><td style="color:${(s.totalFees||0)-paid>0?'red':'green'}">${Fmt.currency((s.totalFees||0)-paid)}</td></tr>`;
  }).join('');
  Exporter.toPDF_simple('All Students Report', `<table><thead><tr><th>Name</th><th>Course</th><th>Batch</th><th>Mobile</th><th>Status</th><th>Paid</th><th>Balance</th></tr></thead><tbody>${rows}</tbody></table>`);
  Toast.success('PDF generated!');
}

function exportAllStudentsCSV() {
  const students = DB.getStudents();
  const headers = ['Name','Father','Course','Batch','PC','Mobile','Email','Status','Total Fees','Paid','Balance','Admission'];
  const rows = students.map(s=>{
    const paid=DB.paidFees(s.id);
    return [s.name,s.fatherName||'',s.course||'',s.batchNo||'',s.pcNo||'',s.mobile||'',s.email||'',s.courseStatus||'',s.totalFees||0,paid,(s.totalFees||0)-paid,s.admissionDate||''];
  });
  Exporter.toCSV(headers,rows,'all-students.csv');
  Toast.success('CSV exported!');
}

function exportFullDatabase() {
  Exporter.toJSON(DB.exportAll(), 'academy-backup-'+new Date().toISOString().slice(0,10)+'.json');
  Toast.success('Full database exported!');
}

function importDatabase() {
  const input = document.getElementById('importFile');
  if (!input || !input.files[0]) { Toast.warning('Select a JSON file'); return; }
  const reader = new FileReader();
  reader.onload = e=>{
    try {
      const data = JSON.parse(e.target.result);
      if(data.students) DB.saveStudents(data.students);
      if(data.teachers) DB.saveTeachers(data.teachers);
      if(data.fees) DB.set(DB.KEYS.fees, data.fees);
      if(data.attendance) DB.set(DB.KEYS.attendance, data.attendance);
      if(data.timetable) DB.saveTimetable(data.timetable);
      if(data.topics) DB.set(DB.KEYS.topics, data.topics);
      if(data.gallery) DB.set(DB.KEYS.gallery, data.gallery);
      if(data.internships) DB.saveInternships(data.internships);
      Toast.success('Database imported successfully!');
      renderReportsSummary();
    } catch(err) {
      Toast.error('Invalid JSON file');
    }
  };
  reader.readAsText(input.files[0]);
}

document.addEventListener('DOMContentLoaded', initReportsPage);

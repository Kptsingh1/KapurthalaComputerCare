/* ==========================================================================
   SALARY.JS — Teacher Salary Management
   Computer Care (Anubhav EduVista) Academy Management System
   ========================================================================== */

let salarySession = null;
let selectedTeacherId = null;

function initSalaryPage() {
  salarySession = Auth.requireAuth(['admin','teacher']);
  if (!salarySession) return;

  populateTeacherList();

  const teachers = DB.getTeachers();
  if (salarySession.role === 'teacher') {
    const own = teachers.find(t => t.id === salarySession.id);
    if (own) selectTeacher(own.id);
    return;
  }

  const firstTeacher = teachers[0];
  if (firstTeacher) selectTeacher(firstTeacher.id);
}

function populateTeacherList() {
  const teachers = DB.getTeachers();
  const listEl = document.getElementById('teacherSalaryList');
  if (!listEl) return;

  // If logged in as teacher, only show own record
  const visibleTeachers = salarySession.role === 'teacher'
    ? teachers.filter(t => t.id === salarySession.id)
    : teachers;

  listEl.innerHTML = visibleTeachers.map(t => {
    const sal = DB.getSalary(t.id);
    const totalPaid = (sal.records||[]).reduce((s,r)=>s+(Number(r.net)||0), 0);
    return `<div class="glass-card teacher-sal-item" id="sal-item-${t.id}"
      onclick="selectTeacher('${t.id}')"
      style="padding:12px 14px;cursor:pointer;margin-bottom:8px;transition:all 0.2s">
      <div style="display:flex;align-items:center;gap:10px">
        <div class="avatar" style="width:36px;height:36px;font-size:0.8rem">${Fmt.initials(t.name)}</div>
        <div style="flex:1">
          <div style="font-weight:700;font-size:0.88rem">${t.name}</div>
          <div style="font-size:0.75rem;color:var(--text-muted)">${t.subject||'—'}</div>
        </div>
        <div style="text-align:right">
          <div style="font-size:0.75rem;color:var(--text-muted)">Base</div>
          <div style="font-weight:700;color:var(--success);font-size:0.88rem">${Fmt.currency(t.salary||0)}</div>
        </div>
      </div>
    </div>`;
  }).join('');

  // Auto-select first for teacher role
  if (salarySession.role === 'teacher') {
    const own = teachers.find(t=>t.id===salarySession.id);
    if (own) selectTeacher(own.id);
  }
}

function selectTeacher(teacherId) {
  if (salarySession.role === 'teacher' && teacherId !== salarySession.id) {
    Toast.warning('Teachers can view only their own salary record');
    teacherId = salarySession.id;
  }
  selectedTeacherId = teacherId;

  // Highlight selected
  document.querySelectorAll('.teacher-sal-item').forEach(el => {
    el.style.background = '';
    el.style.borderColor = '';
  });
  const selEl = document.getElementById(`sal-item-${teacherId}`);
  if (selEl) {
    selEl.style.background = 'rgba(94,234,212,0.08)';
    selEl.style.borderColor = 'var(--primary)';
  }

  renderSalaryDetail(teacherId);
}

function renderSalaryDetail(teacherId) {
  if (salarySession.role === 'teacher' && teacherId !== salarySession.id) {
    Toast.warning('Salary details are private to each teacher');
    return;
  }
  const teacher = DB.getTeacher(teacherId);
  if (!teacher) return;
  const salData = DB.getSalary(teacherId);
  const records = salData.records || [];

  const totalPaid = records.reduce((s,r)=>s+(Number(r.net)||0), 0);
  const totalAdvance = records.reduce((s,r)=>s+(Number(r.advance)||0), 0);
  const totalBonus = records.reduce((s,r)=>s+(Number(r.bonus)||0), 0);
  const totalDeductions = records.reduce((s,r)=>s+(Number(r.deductions)||0), 0);

  const detailEl = document.getElementById('salaryDetail');
  if (!detailEl) return;

  const isAdmin = salarySession.role === 'admin';

  detailEl.innerHTML = `
    <!-- Teacher Info Header -->
    <div class="glass-panel" style="margin-bottom:16px">
      <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap">
        <div class="avatar avatar-lg">${Fmt.initials(teacher.name)}</div>
        <div style="flex:1">
          <h3 style="margin-bottom:4px">${teacher.name}</h3>
          <div style="color:var(--text-muted);font-size:0.85rem">${teacher.qualification||''} • ${teacher.subject||''} • Joined: ${Fmt.date(teacher.joinDate)}</div>
        </div>
        <div style="text-align:center">
          <div style="font-size:0.72rem;color:var(--text-muted)">Monthly Salary</div>
          <div style="font-size:1.8rem;font-weight:700;color:var(--success)">${Fmt.currency(teacher.salary||0)}</div>
        </div>
      </div>
    </div>

    <!-- Stats -->
    <div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:16px">
      <div class="stat-card" style="--card-color:var(--success)">
        <div class="stat-icon">💵</div>
        <div class="stat-value" style="font-size:1.4rem">${Fmt.currency(totalPaid)}</div>
        <div class="stat-label">Total Paid</div>
      </div>
      <div class="stat-card" style="--card-color:var(--info)">
        <div class="stat-icon">🎁</div>
        <div class="stat-value" style="font-size:1.4rem">${Fmt.currency(totalBonus)}</div>
        <div class="stat-label">Total Bonus</div>
      </div>
      <div class="stat-card" style="--card-color:var(--warning)">
        <div class="stat-icon">📤</div>
        <div class="stat-value" style="font-size:1.4rem">${Fmt.currency(totalAdvance)}</div>
        <div class="stat-label">Total Advance</div>
      </div>
      <div class="stat-card" style="--card-color:var(--danger)">
        <div class="stat-icon">📉</div>
        <div class="stat-value" style="font-size:1.4rem">${Fmt.currency(totalDeductions)}</div>
        <div class="stat-label">Total Deductions</div>
      </div>
    </div>

    ${isAdmin ? `
    <!-- Add Salary Record -->
    <div class="glass-panel" style="margin-bottom:16px">
      <h4 style="margin-bottom:14px;color:var(--primary)">➕ Add Salary Record</h4>
      <div class="form-grid" style="grid-template-columns:repeat(auto-fill,minmax(180px,1fr))">
        <div class="form-group">
          <label class="form-label">Month</label>
          <input type="month" id="salMonth" class="form-control" value="${new Date().toISOString().slice(0,7)}">
        </div>
        <div class="form-group">
          <label class="form-label">Base Salary (₹)</label>
          <input type="number" id="salBase" class="form-control" placeholder="Monthly base" value="${teacher.salary||0}">
        </div>
        <div class="form-group">
          <label class="form-label">Bonus (₹)</label>
          <input type="number" id="salBonus" class="form-control" placeholder="0" value="0">
        </div>
        <div class="form-group">
          <label class="form-label">Advance (₹)</label>
          <input type="number" id="salAdvance" class="form-control" placeholder="0" value="0">
        </div>
        <div class="form-group">
          <label class="form-label">Deductions (₹)</label>
          <input type="number" id="salDeductions" class="form-control" placeholder="0" value="0">
        </div>
        <div class="form-group">
          <label class="form-label">Payment Mode</label>
          <select id="salMode" class="form-control">
            <option>Cash</option>
            <option>Bank Transfer</option>
            <option>UPI</option>
            <option>Cheque</option>
          </select>
        </div>
        <div class="form-group" style="grid-column:1/-1">
          <label class="form-label">Notes</label>
          <input type="text" id="salNotes" class="form-control" placeholder="Optional notes">
        </div>
      </div>
      <div style="display:flex;gap:10px;margin-top:10px">
        <button class="btn btn-primary" onclick="addSalaryRecord()">💾 Save Salary Record</button>
        <button class="btn btn-secondary btn-sm" onclick="generateSalarySlip('${teacherId}')">🖨️ Slip</button>
      </div>
    </div>` : ''}

    <!-- Salary Records Table -->
    <div class="glass-panel" style="padding:0;overflow:hidden">
      <div style="padding:16px 20px;border-bottom:1px solid var(--glass-border);display:flex;justify-content:space-between;align-items:center">
        <h4 style="color:var(--primary)">📜 Salary History</h4>
        <button class="btn btn-sm btn-secondary" onclick="generateSalarySlip('${teacherId}')">🖨️ Generate Slip</button>
      </div>
      ${records.length ? `
      <div class="table-container">
        <table>
          <thead><tr>
            <th>Month</th><th>Base</th><th>Bonus</th><th>Advance</th><th>Deductions</th>
            <th>Net Paid</th><th>Mode</th><th>Notes</th>
            ${isAdmin?'<th>Action</th>':''}
          </tr></thead>
          <tbody>
            ${records.map(r=>`<tr>
              <td style="font-weight:700">${r.month||'—'}</td>
              <td>${Fmt.currency(r.base||0)}</td>
              <td style="color:var(--success)">${Fmt.currency(r.bonus||0)}</td>
              <td style="color:var(--warning)">${Fmt.currency(r.advance||0)}</td>
              <td style="color:var(--danger)">${Fmt.currency(r.deductions||0)}</td>
              <td style="font-weight:700;color:var(--primary)">${Fmt.currency(r.net||0)}</td>
              <td>${r.mode||'Cash'}</td>
              <td style="font-size:0.8rem;color:var(--text-muted)">${r.notes||'—'}</td>
              ${isAdmin?`<td><button class="btn btn-sm btn-danger" onclick="deleteSalaryRecord('${teacherId}','${r.id}')">🗑</button></td>`:''}
            </tr>`).join('')}
          </tbody>
        </table>
      </div>` : `<div class="empty-state" style="padding:40px">
        <div class="empty-state-icon">💼</div>
        <p>No salary records yet</p>
      </div>`}
    </div>
  `;
}

function addSalaryRecord() {
  if (!salarySession || salarySession.role !== 'admin') {
    Toast.warning('Only admin can add salary records');
    return;
  }
  if (!selectedTeacherId) return;
  const base = Number(document.getElementById('salBase').value) || 0;
  const bonus = Number(document.getElementById('salBonus').value) || 0;
  const advance = Number(document.getElementById('salAdvance').value) || 0;
  const deductions = Number(document.getElementById('salDeductions').value) || 0;
  const month = document.getElementById('salMonth').value;
  const mode = document.getElementById('salMode').value;
  const notes = document.getElementById('salNotes').value;
  const net = base + bonus - advance - deductions;

  if (!month) { Toast.warning('Please select a month'); return; }

  DB.addSalaryPayment(selectedTeacherId, { month, base, bonus, advance, deductions, net, mode, notes });
  Toast.success(`Salary record added! Net: ${Fmt.currency(net)}`);
  renderSalaryDetail(selectedTeacherId);
  showAutoSave();
}

function deleteSalaryRecord(teacherId, recordId) {
  if (!salarySession || salarySession.role !== 'admin') {
    Toast.warning('Only admin can delete salary records');
    return;
  }
  if (!confirm('Delete this salary record?')) return;
  const sal = DB.getSalary(teacherId);
  sal.records = (sal.records||[]).filter(r=>r.id!==recordId);
  DB.saveSalaryRecord(teacherId, sal);
  renderSalaryDetail(teacherId);
  Toast.info('Record deleted');
}

function generateSalarySlip(teacherId) {
  if (salarySession.role === 'teacher' && teacherId !== salarySession.id) {
    Toast.warning('Teachers can generate only their own salary slip');
    return;
  }
  const teacher = DB.getTeacher(teacherId);
  if (!teacher) return;
  const records = DB.getSalary(teacherId).records || [];
  const settings = DB.getSettings();

  // Get latest record or show all
  const latest = records[0];
  if (!latest) { Toast.warning('No salary records found'); return; }

  Exporter.toPDF_simple(`Salary Slip — ${teacher.name}`, `
    <h2 style="color:#047857;margin-bottom:4px">SALARY SLIP</h2>
    <table style="width:100%;border:none;font-size:13px;margin-bottom:20px">
      <tr>
        <td style="border:none;padding:4px"><strong>Employee:</strong> ${teacher.name}</td>
        <td style="border:none;padding:4px"><strong>Month:</strong> ${latest.month}</td>
      </tr>
      <tr>
        <td style="border:none;padding:4px"><strong>Qualification:</strong> ${teacher.qualification||'—'}</td>
        <td style="border:none;padding:4px"><strong>Subject:</strong> ${teacher.subject||'—'}</td>
      </tr>
      <tr>
        <td style="border:none;padding:4px"><strong>Mobile:</strong> ${teacher.mobile||'—'}</td>
        <td style="border:none;padding:4px"><strong>Join Date:</strong> ${teacher.joinDate||'—'}</td>
      </tr>
    </table>
    <table>
      <thead><tr>
        <th>Description</th><th>Amount</th>
      </tr></thead>
      <tbody>
        <tr><td>Basic Salary</td><td>₹${latest.base||0}</td></tr>
        <tr><td>Bonus</td><td style="color:green">+ ₹${latest.bonus||0}</td></tr>
        <tr><td>Advance</td><td style="color:red">- ₹${latest.advance||0}</td></tr>
        <tr><td>Deductions</td><td style="color:red">- ₹${latest.deductions||0}</td></tr>
        <tr style="background:#e6f4f1"><td><strong>Net Salary</strong></td><td><strong>₹${latest.net||0}</strong></td></tr>
      </tbody>
    </table>
    <br>
    <p><strong>Payment Mode:</strong> ${latest.mode||'Cash'} &nbsp;&nbsp; <strong>Notes:</strong> ${latest.notes||'—'}</p>
    <br>
    <div style="display:flex;justify-content:space-between;margin-top:40px">
      <div style="text-align:center;width:180px"><div style="border-top:1px solid #333;padding-top:6px;font-size:12px">Employee Signature</div></div>
      <div style="text-align:center;width:180px"><div style="border-top:1px solid #333;padding-top:6px;font-size:12px">Principal / Director</div></div>
    </div>
  `);
}

function updateBaseSalary(teacherId) {
  if (!salarySession || salarySession.role !== 'admin') {
    Toast.warning('Only admin can update base salary');
    return;
  }
  const newBase = Number(prompt('Enter new monthly base salary (₹):'));
  if (!newBase || newBase < 0) return;
  DB.updateTeacher(teacherId, { salary: newBase });
  renderSalaryDetail(teacherId);
  populateTeacherList();
  Toast.success('Base salary updated!');
}

document.addEventListener('DOMContentLoaded', initSalaryPage);

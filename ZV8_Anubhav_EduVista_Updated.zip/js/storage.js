/* ==========================================================================
   STORAGE HUB
   Browser, backend, database, cloud, API, and export storage controls.
   ========================================================================== */

const StorageHub = (() => {
  const SNAPSHOT_KEY = 'cc_storage_snapshot';
  const CACHE_NAME = 'computer-care-academy-storage';
  const CACHE_URL = '/computer-care-storage-snapshot.json';
  const INDEXED_DB = 'computerCareAcademyStorage';
  const INDEXED_STORE = 'snapshots';

  const adapters = [
    { id:'remote', title:'Remote Storage', group:'Remote', side:'Server', state:'Ready', format:'REST JSON', detail:'Syncs the same academy snapshot to an online or LAN server endpoint.' },
    { id:'local', title:'Local Storage', group:'Client-Side', side:'Browser', state:'Live', format:'JSON', detail:'Primary app database already used by every page.' },
    { id:'file', title:'File-Based Storage', group:'Flat Files', side:'Client/Server', state:'Live', format:'JSON', detail:'Downloads and restores complete database backup files.' },
    { id:'cookies', title:'Cookies Storage', group:'Client-Side', side:'Browser', state:'Live', format:'Metadata', detail:'Stores small session/storage metadata because cookies have strict size limits.' },
    { id:'session', title:'Session Storage', group:'Client-Side', side:'Browser', state:'Live', format:'JSON', detail:'Stores a temporary snapshot that clears when the browser session ends.' },
    { id:'indexeddb', title:'Indexed DB', group:'Client-Side', side:'Browser', state:'Live', format:'Object store', detail:'Stores a full structured snapshot in a browser database.' },
    { id:'cache', title:'Cache API', group:'Client-Side', side:'Browser', state:'Live', format:'Response JSON', detail:'Stores a complete snapshot in a named browser cache.' },
    { id:'server', title:'Server-Side - Backend + Database', group:'Server-Side', side:'Node.js', state:'Live', format:'db/database.json', detail:'Node backend reads, writes, downloads, and exports the JSON database.' },
    { id:'browser', title:'Client-Side - Browser-Based', group:'Client-Side', side:'Browser', state:'Live', format:'HTML/CSS/JS', detail:'All existing pages keep the same design, functions, queries, and data model.' },
    { id:'relational', title:'Relational Databases', group:'Database', side:'Server', state:'Blueprint', format:'MySQL schema', detail:'MySQL-compatible table design is exposed through backend metadata.' },
    { id:'nosql', title:'NoSQL Databases', group:'Database', side:'Server', state:'Blueprint', format:'MongoDB collections', detail:'MongoDB stores the same snapshot as collections or a single academy document.' },
    { id:'flat', title:'Flat Files', group:'Flat Files', side:'Client/Server', state:'Live', format:'JSON/CSV/XML', detail:'JSON, CSV, and XML exports use the same DB snapshot.' },
    { id:'cloudDb', title:'Cloud Databases', group:'Cloud', side:'Server', state:'Ready', format:'REST adapter', detail:'Designed for hosted MongoDB, MySQL, Firebase, Supabase, or similar services.' },
    { id:'csvExcel', title:'CSV/Excel', group:'Exports', side:'Client/Server', state:'Live', format:'CSV/XLSX', detail:'Single formatted master workbook plus focused CSV exports.' },
    { id:'pdf', title:'PDF', group:'Exports', side:'Client', state:'Live', format:'Print/PDF', detail:'Report pages already generate printable PDFs, with storage summary PDF added here.' },
    { id:'jsonXml', title:'JSON/XML', group:'Exports', side:'Client/Server', state:'Live', format:'JSON/XML', detail:'Full database backup and XML export from the same data model.' },
    { id:'google', title:'Google Sheets / Google Drive', group:'Cloud APIs', side:'Remote', state:'Needs credentials', format:'API adapter', detail:'Adapter slot ready for OAuth/API keys; exports can be uploaded from the master workbook.' },
    { id:'dropbox', title:'Dropbox / OneDrive APIs', group:'Cloud APIs', side:'Remote', state:'Needs credentials', format:'API adapter', detail:'Adapter slot ready for file upload APIs and backup synchronization.' },
    { id:'restGraphql', title:'REST APIs / GraphQL APIs', group:'APIs', side:'Server', state:'Live', format:'REST/GraphQL', detail:'REST routes are live; GraphQL-style summary/database endpoint is available in backend mode.' },
    { id:'specialized', title:'Specialized Storage', group:'Advanced', side:'Server', state:'Ready', format:'Adapter', detail:'Reserved for LMS, biometric, payment, analytics, or certificate systems.' },
    { id:'sessions', title:'Session Management Systems', group:'Security', side:'Browser/Server', state:'Live', format:'Session JSON', detail:'Existing auth session is preserved and can be mirrored to sessionStorage.' },
    { id:'blockchain', title:'Blockchain Storage', group:'Advanced', side:'Remote', state:'Blueprint', format:'Hash ledger', detail:'Stores backup hashes or certificate verification IDs without exposing private data.' },
    { id:'object', title:'Object Storage', group:'Cloud', side:'Remote', state:'Ready', format:'Files/blobs', detail:'Designed for S3, Cloudflare R2, Azure Blob, or image/document storage.' },
    { id:'node', title:'Node.js Backend', group:'Technology', side:'Server', state:'Live', format:'HTTP API', detail:'Current backend serves static pages, JSON database routes, storage metadata, and exports.' },
    { id:'react', title:'React.js Frontend Adapter', group:'Technology', side:'Client', state:'Blueprint', format:'Component adapter', detail:'Storage hub can be reused as a React component against the same APIs.' },
    { id:'python', title:'Python Utility Adapter', group:'Technology', side:'Server/Tools', state:'Blueprint', format:'CLI scripts', detail:'Python can read the same db/database.json file for reports, migration, or automation.' },
    { id:'mysql', title:'MySQL Adapter', group:'Technology', side:'Server', state:'Blueprint', format:'SQL tables', detail:'Relational schema maps academy data to students, teachers, payments, and attendance.' },
    { id:'mongodb', title:'MongoDB Adapter', group:'Technology', side:'Server', state:'Blueprint', format:'Collections', detail:'NoSQL adapter can mirror the current JSON keys as MongoDB collections.' },
    { id:'exe', title:'EXE Desktop Package', group:'Packaging', side:'Desktop', state:'Blueprint', format:'Electron', detail:'Backend mode can be wrapped as a Windows desktop app without changing the UI.' },
    { id:'apk', title:'APK Mobile Package', group:'Packaging', side:'Android', state:'Blueprint', format:'Capacitor/PWA', detail:'Browser-first app can be packaged for Android while keeping the same pages and logic.' },
  ];

  function getAdapters() {
    return adapters.map(item => ({ ...item }));
  }

  function snapshot() {
    return DB.exportStorage ? DB.exportStorage() : DB.exportAll();
  }

  function publicData() {
    return DB.exportAll ? DB.exportAll() : snapshot();
  }

  function sizeOf(value) {
    return new Blob([typeof value === 'string' ? value : JSON.stringify(value)]).size;
  }

  function countPayments(fees) {
    return Object.values(fees || {}).reduce((sum, record) => {
      if (Array.isArray(record)) return sum + record.length;
      return sum + ((record && record.payments && record.payments.length) || 0);
    }, 0);
  }

  function summaryRows() {
    const data = snapshot();
    return [
      { label:'Students', count:(data.cc_students || []).length },
      { label:'Teachers', count:(data.cc_teachers || []).length },
      { label:'Courses', count:(data.cc_courses || []).length },
      { label:'Payments', count:countPayments(data.cc_fees) },
      { label:'Attendance Months', count:Object.keys(data.cc_attendance || {}).length },
      { label:'Topics', count:(data.cc_topics || []).length },
      { label:'Tasks', count:(data.cc_tasks || []).length },
      { label:'Internships', count:(data.cc_internships || []).length },
      { label:'Inquiries', count:(data.cc_inquiries || []).length },
      { label:'Snapshot Size', count:(sizeOf(data) / 1024).toFixed(1) + ' KB' },
    ];
  }

  function supportMap() {
    return {
      localStorage: typeof localStorage !== 'undefined',
      sessionStorage: typeof sessionStorage !== 'undefined',
      cookies: typeof document !== 'undefined' && 'cookie' in document,
      indexedDB: typeof indexedDB !== 'undefined',
      cacheAPI: typeof caches !== 'undefined',
      fileExport: typeof Blob !== 'undefined',
      backend: typeof fetch === 'function' && window.location.protocol.startsWith('http'),
      excel: !!window.ExcelJS,
    };
  }

  function stateClass(state) {
    const s = String(state || '').toLowerCase();
    if (s.includes('live')) return 'is-live';
    if (s.includes('ready')) return 'is-ready';
    if (s.includes('credential')) return 'is-credential';
    return 'is-blueprint';
  }

  function renderSummary() {
    const wrap = document.getElementById('storageStatusSummary');
    if (!wrap) return;
    wrap.innerHTML = summaryRows().map(item => `
      <div class="storage-mini-card">
        <span>${item.label}</span>
        <strong>${item.count}</strong>
      </div>
    `).join('');
  }

  function renderAdapters() {
    const wrap = document.getElementById('storageAdapterGrid');
    if (!wrap) return;
    wrap.innerHTML = adapters.map(item => `
      <article class="storage-adapter-card">
        <div class="storage-adapter-top">
          <span class="storage-adapter-group">${item.group}</span>
          <span class="storage-state ${stateClass(item.state)}">${item.state}</span>
        </div>
        <h4>${item.title}</h4>
        <div class="storage-meta">
          <span>${item.side}</span>
          <span>${item.format}</span>
        </div>
        <p>${item.detail}</p>
      </article>
    `).join('');
  }

  function renderSupport() {
    const wrap = document.getElementById('browserStorageSupport');
    if (!wrap) return;
    const supports = supportMap();
    wrap.innerHTML = Object.entries(supports).map(([key, ok]) => `
      <div class="database-pill">
        <span class="database-pill-icon">${ok ? 'OK' : '--'}</span>
        <span>${key}</span>
        <strong>${ok ? 'Ready' : 'No'}</strong>
      </div>
    `).join('');
  }

  async function fetchBackendAdapters() {
    const wrap = document.getElementById('backendAdapterSummary');
    if (!wrap) return;
    if (!supportMap().backend) {
      wrap.innerHTML = '<div class="backend-note">Open through <code>npm start</code> to view live backend adapter details.</div>';
      return;
    }
    try {
      const res = await fetch('api/storage/adapters', { cache:'no-store' });
      if (!res.ok) throw new Error('Backend adapter route is unavailable');
      const data = await res.json();
      wrap.innerHTML = `
        <div class="storage-mini-card"><span>Backend</span><strong>${data.ok ? 'Online' : 'Offline'}</strong></div>
        <div class="storage-mini-card"><span>Adapters</span><strong>${(data.adapters || []).length}</strong></div>
        <div class="storage-mini-card"><span>Database File</span><strong>${data.databaseFile ? 'Ready' : '-'}</strong></div>
        <div class="storage-mini-card"><span>Updated</span><strong>${data.updatedAt ? Fmt.dateTime(data.updatedAt) : '-'}</strong></div>
      `;
    } catch (err) {
      wrap.innerHTML = '<div class="backend-note">Backend adapter metadata is not available yet.</div>';
    }
  }

  function openIndexedDb() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(INDEXED_DB, 1);
      request.onupgradeneeded = event => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(INDEXED_STORE)) {
          db.createObjectStore(INDEXED_STORE, { keyPath:'id' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async function saveIndexedDBSnapshot() {
    if (!supportMap().indexedDB) {
      Toast.error('IndexedDB is not supported in this browser.');
      return;
    }
    const db = await openIndexedDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(INDEXED_STORE, 'readwrite');
      tx.objectStore(INDEXED_STORE).put({ id:'latest', updatedAt:new Date().toISOString(), data:snapshot() });
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
    });
    db.close();
    Toast.success('Full snapshot saved to IndexedDB.');
  }

  function saveSessionSnapshot() {
    sessionStorage.setItem(SNAPSHOT_KEY, JSON.stringify(snapshot()));
    Toast.success('Full snapshot saved to Session Storage.');
    renderSupport();
  }

  function saveCookieMetadata() {
    const data = snapshot();
    const meta = {
      updatedAt: data._updatedAt || new Date().toISOString(),
      students: (data.cc_students || []).length,
      teachers: (data.cc_teachers || []).length,
      courses: (data.cc_courses || []).length,
    };
    document.cookie = `cc_storage_meta=${encodeURIComponent(JSON.stringify(meta))}; path=/; max-age=604800; SameSite=Lax`;
    Toast.success('Storage metadata saved to Cookies.');
  }

  async function saveCacheSnapshot() {
    if (!supportMap().cacheAPI) {
      Toast.error('Cache API is not supported in this browser.');
      return;
    }
    const cache = await caches.open(CACHE_NAME);
    const body = JSON.stringify(snapshot(), null, 2);
    await cache.put(CACHE_URL, new Response(body, {
      headers: { 'Content-Type':'application/json; charset=utf-8' },
    }));
    Toast.success('Full snapshot saved to Cache API.');
  }

  function downloadFlatFile() {
    Exporter.toJSON(snapshot(), `computer-care-flat-file-${new Date().toISOString().slice(0,10)}.json`);
    Toast.success('Flat-file JSON backup downloaded.');
  }

  function toXmlValue(key, value) {
    const safeKey = String(key).replace(/[^a-zA-Z0-9_-]/g, '_');
    if (Array.isArray(value)) {
      return `<${safeKey}>${value.map((item, index) => toXmlValue('item_' + (index + 1), item)).join('')}</${safeKey}>`;
    }
    if (value && typeof value === 'object') {
      return `<${safeKey}>${Object.entries(value).map(([k, v]) => toXmlValue(k, v)).join('')}</${safeKey}>`;
    }
    return `<${safeKey}>${String(value ?? '').replace(/[<>&'"]/g, ch => ({ '<':'&lt;', '>':'&gt;', '&':'&amp;', "'":'&apos;', '"':'&quot;' }[ch]))}</${safeKey}>`;
  }

  function downloadXml() {
    const xml = `<?xml version="1.0" encoding="UTF-8"?><academy>${Object.entries(publicData()).map(([k, v]) => toXmlValue(k, v)).join('')}</academy>`;
    Exporter.download(xml, `computer-care-data-${new Date().toISOString().slice(0,10)}.xml`, 'application/xml;charset=utf-8');
    Toast.success('XML export downloaded.');
  }

  function downloadStoragePdf() {
    const rows = adapters.map(item => `
      <tr>
        <td>${item.title}</td>
        <td>${item.group}</td>
        <td>${item.state}</td>
        <td>${item.format}</td>
        <td>${item.detail}</td>
      </tr>
    `).join('');
    Exporter.toPDF_simple('Storage Systems Summary', `
      <h2>Storage Systems Summary</h2>
      <table>
        <thead><tr><th>Storage</th><th>Group</th><th>Status</th><th>Format</th><th>Details</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    `);
    Toast.success('Storage PDF opened.');
  }

  function downloadCsvSummary() {
    const headers = ['Storage Type', 'Group', 'Side', 'Status', 'Format', 'Details'];
    const rows = adapters.map(item => [item.title, item.group, item.side, item.state, item.format, item.detail]);
    Exporter.toCSV(headers, rows, `computer-care-storage-map-${new Date().toISOString().slice(0,10)}.csv`);
    Toast.success('Storage map CSV downloaded.');
  }

  async function saveServerSnapshot() {
    if (!supportMap().backend) {
      Toast.error('Start backend with npm start before server sync.');
      return;
    }
    const data = snapshot();
    data._updatedAt = new Date().toISOString();
    const res = await fetch('api/storage/snapshot', {
      method:'POST',
      headers:{ 'Content-Type':'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('Server save failed');
    Toast.success('Snapshot saved to backend database.');
    fetchBackendAdapters();
  }

  async function loadServerSnapshot() {
    if (!supportMap().backend) {
      Toast.error('Start backend with npm start before server load.');
      return;
    }
    if (!confirm('Load backend database into this browser? Current browser data will be replaced.')) return;
    const data = await fetch('api/db', { cache:'no-store' }).then(res => {
      if (!res.ok) throw new Error('Server load failed');
      return res.json();
    });
    DB.applyStorageSnapshot(data);
    Toast.success('Backend database loaded into browser.');
    refresh();
  }

  function exportMasterExcel() {
    if (window.MasterExcel && typeof MasterExcel.exportAllData === 'function') {
      MasterExcel.exportAllData();
      return;
    }
    if (supportMap().backend) {
      window.location.href = 'api/export/master.xlsx';
      return;
    }
    Toast.error('Master Excel exporter is not available.');
  }

  function refresh() {
    renderSummary();
    renderAdapters();
    renderSupport();
    fetchBackendAdapters();
  }

  function init() {
    if (!document.getElementById('storageHubPage')) return;
    refresh();
  }

  return {
    init,
    refresh,
    getAdapters,
    saveSessionSnapshot,
    saveCookieMetadata,
    saveIndexedDBSnapshot,
    saveCacheSnapshot,
    downloadFlatFile,
    downloadXml,
    downloadStoragePdf,
    downloadCsvSummary,
    saveServerSnapshot,
    loadServerSnapshot,
    exportMasterExcel,
  };
})();

window.StorageHub = StorageHub;
window.storageSaveSession = () => StorageHub.saveSessionSnapshot();
window.storageSaveCookie = () => StorageHub.saveCookieMetadata();
window.storageSaveIndexedDB = () => StorageHub.saveIndexedDBSnapshot().catch(err => Toast.error(err.message));
window.storageSaveCache = () => StorageHub.saveCacheSnapshot().catch(err => Toast.error(err.message));
window.storageDownloadFlatFile = () => StorageHub.downloadFlatFile();
window.storageDownloadXml = () => StorageHub.downloadXml();
window.storageDownloadPdf = () => StorageHub.downloadStoragePdf();
window.storageDownloadCsv = () => StorageHub.downloadCsvSummary();
window.storageSaveServer = () => StorageHub.saveServerSnapshot().catch(err => Toast.error(err.message));
window.storageLoadServer = () => StorageHub.loadServerSnapshot().catch(err => Toast.error(err.message));
window.storageExportMasterExcel = () => StorageHub.exportMasterExcel();

document.addEventListener('DOMContentLoaded', StorageHub.init);

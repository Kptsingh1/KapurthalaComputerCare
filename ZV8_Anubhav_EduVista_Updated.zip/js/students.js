/* ==========================================================================
   STUDENTS.JS — Student & Teacher Management
   ========================================================================== */

let currentView = 'students'; // 'students' | 'teachers'
let editingId = null;
let viewingId = null;
let studentImageControl = null;
let teacherImageControl = null;
let studentViewMode = AcademyView ? AcademyView.get('students_page_students', 'list') : 'list';
let teacherViewMode = AcademyView ? AcademyView.get('students_page_teachers', 'list') : 'list';

function initStudentsPage() {
  const session = Auth.requireAuth(['admin','teacher']);
  if (!session) return;

  bindStudentForm();
  bindTeacherForm();
  enhancePeoplePageControls();
  bindPeopleFilters();
  renderStudentList();
  renderTeacherList();

  // Tab switch
  document.querySelectorAll('[data-people-tab]').forEach(btn=>{
    btn.addEventListener('click',()=>{
      const tab = btn.dataset.peopleTab;
      document.querySelectorAll('[data-people-tab]').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById('studentSection').style.display = tab==='students'?'':'none';
      document.getElementById('teacherSection').style.display = tab==='teachers'?'':'none';
      currentView = tab;
    });
  });
}

function bindPeopleFilters() {
  ['studentSearch','statusFilter','courseFilter','studentGenderFilter','studentBatchFilter','studentFeesFilter','studentDayFilter','studentDateFrom','studentDateTo'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('input', renderStudentList);
    if (el && el.tagName === 'SELECT') el.addEventListener('change', renderStudentList);
  });
  ['teacherSearch','teacherGenderFilter','teacherActiveFilter'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('input', renderTeacherList);
    if (el && el.tagName === 'SELECT') el.addEventListener('change', renderTeacherList);
  });
}

function enhancePeoplePageControls() {
  const studentPanel = document.querySelector('#studentSection .glass-panel');
  if (studentPanel && !document.getElementById('studentAdvancedFilters')) {
    studentPanel.insertAdjacentHTML('beforeend', `
      <div class="academy-filter-panel" id="studentAdvancedFilters" style="margin:12px 0 0">
        <div class="academy-filter-grid">
          <select id="studentBatchFilter" class="form-control">${AcademyFilters.batchOptions()}</select>
          <select id="studentFeesFilter" class="form-control">${AcademyFilters.feeStatusOptions()}</select>
          <select id="studentDayFilter" class="form-control">${AcademyFilters.dayOptions()}</select>
          <input type="date" id="studentDateFrom" class="form-control" title="Admission from">
          <input type="date" id="studentDateTo" class="form-control" title="Admission to">
          <button type="button" class="btn btn-secondary filter-clear-btn" onclick="clearStudentFilters()">Clear Filters</button>
        </div>
      </div>
    `);
  }
  const studentTablePanel = document.querySelector('#studentSection .glass-panel:last-child');
  if (studentTablePanel && !document.getElementById('studentViewToolbar')) {
    studentTablePanel.insertAdjacentHTML('beforebegin', AcademyView.toolbarMarkup('students_page_students', studentViewMode, 'Students view', 'studentRecordCount', '0 students'));
    const toolbar = document.querySelector('[data-view-toolbar="students_page_students"]');
    if (toolbar) toolbar.id = 'studentViewToolbar';
    AcademyView.bind(toolbar, 'students_page_students', mode => {
      studentViewMode = mode;
      renderStudentList();
    });
  }
  if (studentTablePanel && !document.getElementById('studentCardsGrid')) {
    studentTablePanel.insertAdjacentHTML('afterend', '<div id="studentCardsGrid" class="people-card-grid" style="display:none"></div>');
  }

  const teacherPanel = document.querySelector('#teacherSection .glass-panel');
  if (teacherPanel && !document.getElementById('teacherAdvancedFilters')) {
    teacherPanel.insertAdjacentHTML('beforeend', `
      <div class="academy-filter-panel" id="teacherAdvancedFilters" style="margin:12px 0 0">
        <div class="academy-filter-grid">
          <select id="teacherActiveFilter" class="form-control">
            <option value="All">All Status</option>
            <option value="true">Active Teachers</option>
            <option value="false">Inactive Teachers</option>
          </select>
          <button type="button" class="btn btn-secondary filter-clear-btn" onclick="clearTeacherFilters()">Clear Filters</button>
        </div>
      </div>
    `);
  }
  const teacherTablePanel = document.querySelector('#teacherSection .glass-panel:last-child');
  if (teacherTablePanel && !document.getElementById('teacherViewToolbar')) {
    teacherTablePanel.insertAdjacentHTML('beforebegin', AcademyView.toolbarMarkup('students_page_teachers', teacherViewMode, 'Teachers view', 'teacherRecordCount', '0 teachers'));
    const toolbar = document.querySelector('[data-view-toolbar="students_page_teachers"]');
    if (toolbar) toolbar.id = 'teacherViewToolbar';
    AcademyView.bind(toolbar, 'students_page_teachers', mode => {
      teacherViewMode = mode;
      renderTeacherList();
    });
  }
  if (teacherTablePanel && !document.getElementById('teacherCardsGrid')) {
    teacherTablePanel.insertAdjacentHTML('afterend', '<div id="teacherCardsGrid" class="people-card-grid" style="display:none"></div>');
  }
}

function clearStudentFilters() {
  ['studentSearch','studentDateFrom','studentDateTo'].forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
  [['statusFilter','All'],['courseFilter','All'],['studentGenderFilter','All'],['studentBatchFilter','All'],['studentFeesFilter','All'],['studentDayFilter','All']].forEach(([id, value]) => {
    const el = document.getElementById(id); if (el) el.value = value;
  });
  document.querySelectorAll('#statusTabBar .status-tab').forEach((btn, i) => btn.classList.toggle('active', i === 0));
  renderStudentList();
}

function clearTeacherFilters() {
  const search = document.getElementById('teacherSearch'); if (search) search.value = '';
  [['teacherGenderFilter','All'],['teacherActiveFilter','All']].forEach(([id, value]) => {
    const el = document.getElementById(id); if (el) el.value = value;
  });
  renderTeacherList();
}

function textMatches(text, query) {
  return !query || String(text || '').toLowerCase().includes(query);
}

function getFilteredStudents() {
  const status = document.getElementById('statusFilter')?.value || 'All';
  const courseId = document.getElementById('courseFilter')?.value || 'All';
  const gender = document.getElementById('studentGenderFilter')?.value || 'All';
  const batch = document.getElementById('studentBatchFilter')?.value || 'All';
  const feesStatus = document.getElementById('studentFeesFilter')?.value || 'All';
  const day = document.getElementById('studentDayFilter')?.value || 'All';
  const dateFrom = document.getElementById('studentDateFrom')?.value || '';
  const dateTo = document.getElementById('studentDateTo')?.value || '';
  const query = (document.getElementById('studentSearch')?.value || '').trim().toLowerCase();
  return DB.filterStudents({ status, courseId, gender, batch, feesStatus, day, dateFrom, dateTo, query });
}

function getFilteredTeachers() {
  const gender = document.getElementById('teacherGenderFilter')?.value || 'All';
  const active = document.getElementById('teacherActiveFilter')?.value || 'All';
  const query = (document.getElementById('teacherSearch')?.value || '').trim().toLowerCase();
  return DB.filterTeachers({ gender, active }).filter(t =>
    textMatches([t.name, t.email, t.mobile, t.subject, t.qualification, t.gender].join(' '), query)
  );
}

/* ---- STUDENT LIST ---- */
function renderStudentList() {
  const students = getFilteredStudents();
  const tbody = document.getElementById('studentTableBody');
  if (!tbody) return;
  const tablePanel = tbody.closest('.glass-panel');
  const cardsGrid = document.getElementById('studentCardsGrid');
  const countEl = document.getElementById('studentRecordCount');
  if (countEl) countEl.textContent = `${students.length} student${students.length === 1 ? '' : 's'}`;
  if (tablePanel) tablePanel.style.display = studentViewMode === 'grid' ? 'none' : '';
  if (cardsGrid) {
    cardsGrid.style.display = studentViewMode === 'grid' ? 'grid' : 'none';
    if (studentViewMode === 'grid') renderStudentCards(students, cardsGrid);
  }
  tbody.innerHTML = students.length ? students.map(s=>{
    const paid = DB.paidFees(s.id);
    const balance = (s.totalFees||0) - paid;
    const statusBadge = {
      'Continue':'badge-primary','Complete':'badge-success',
      'Pending':'badge-warning','Leave':'badge-warning','Left':'badge-danger'
    }[s.courseStatus]||'badge-info';
    return `<tr>
      <td style="min-width:160px"><div style="display:flex;align-items:center;gap:10px">
        ${ProfileImage.avatar(s, '', 'width:32px;height:32px;font-size:0.75rem;flex-shrink:0')}
        <div><div style="font-weight:600;font-size:0.88rem;white-space:nowrap">${s.name}</div>
        <div style="font-size:0.72rem;color:var(--text-muted);white-space:nowrap">${s.mobile||'—'}</div></div></div></td>
      <td style="font-size:0.85rem;white-space:nowrap;min-width:130px">${s.course||'—'}</td>
      <td style="font-size:0.82rem;white-space:nowrap">${s.batchNo||'—'} / ${s.pcNo||'—'}</td>
      <td><span class="badge ${statusBadge}">${s.courseStatus||'—'}</span></td>
      <td style="font-size:0.82rem;white-space:nowrap">${Fmt.date(s.admissionDate)}</td>
      <td style="color:${balance>0?'var(--danger)':'var(--success)'};font-size:0.82rem;font-weight:600;white-space:nowrap">${Fmt.currency(balance)}</td>
      <td style="white-space:nowrap">
        <div style="display:flex;gap:6px">
          <button class="btn btn-sm btn-secondary" onclick="viewStudent('${s.id}')">👁 View</button>
          <button class="btn btn-sm btn-ghost" onclick="editStudent('${s.id}')">✏️ Edit</button>
          <button class="btn btn-sm btn-danger" onclick="deleteStudent('${s.id}','${s.name}')">🗑</button>
        </div>
      </td>
    </tr>`;
  }).join('') : '<tr><td colspan="7" style="text-align:center;padding:40px;color:var(--text-muted)">No students found. <button class="btn btn-sm btn-primary" onclick="openAddStudentModal()" style="margin-left:10px">+ Add Student</button></td></tr>';
}

function renderStudentCards(students, container) {
  container.innerHTML = students.length ? students.map(s => {
    const fee = DB.studentFeeSummary(s);
    const statusBadge = {
      Continue:'badge-primary', Complete:'badge-success',
      Pending:'badge-warning', Leave:'badge-warning', Left:'badge-danger',
    }[s.courseStatus] || 'badge-info';
    return `<article class="person-card">
      <div class="person-card-top">
        <div style="display:flex;gap:10px;align-items:center;min-width:0">
          ${ProfileImage.avatar(s, '', 'width:42px;height:42px;font-size:0.82rem;flex-shrink:0')}
          <div style="min-width:0">
            <div class="person-title">${Fmt.escape(s.name)}</div>
            <div class="card-meta-line"><span>${Fmt.escape(s.mobile || '-')}</span><span>${Fmt.escape(s.gender || '-')}</span></div>
          </div>
        </div>
        <span class="badge ${statusBadge}">${Fmt.escape(s.courseStatus || '-')}</span>
      </div>
      <div class="detail-row"><span>Course</span><strong>${Fmt.escape(s.course || '-')}</strong></div>
      <div class="detail-row"><span>Batch / PC</span><strong>${Fmt.escape((s.batchNo || '-') + ' / ' + (s.pcNo || '-'))}</strong></div>
      <div class="detail-row"><span>Days</span><strong>${Fmt.escape(s.day || '-')}</strong></div>
      <div class="detail-row"><span>Admission</span><strong>${Fmt.date(s.admissionDate)}</strong></div>
      <div class="detail-row"><span>Fees</span><strong>${Fmt.currency(fee.paid)} / ${Fmt.currency(fee.total)} (${fee.status})</strong></div>
      <div class="progress-mini"><span style="width:${fee.percent}%"></span></div>
      <div class="card-actions">
        <button class="btn btn-sm btn-secondary" onclick="viewStudent('${s.id}')">View</button>
        <button class="btn btn-sm btn-ghost" onclick="editStudent('${s.id}')">Edit</button>
        <button class="btn btn-sm btn-danger" onclick="deleteStudent('${s.id}','${Fmt.escape(s.name)}')">Delete</button>
      </div>
    </article>`;
  }).join('') : '<div class="empty-state"><p>No students found</p></div>';
}

/* ---- TEACHER LIST ---- */
function renderTeacherList() {
  const teachers = getFilteredTeachers();
  const tbody = document.getElementById('teacherTableBody');
  if (!tbody) return;
  const tablePanel = tbody.closest('.glass-panel');
  const cardsGrid = document.getElementById('teacherCardsGrid');
  const countEl = document.getElementById('teacherRecordCount');
  if (countEl) countEl.textContent = `${teachers.length} teacher${teachers.length === 1 ? '' : 's'}`;
  if (tablePanel) tablePanel.style.display = teacherViewMode === 'grid' ? 'none' : '';
  if (cardsGrid) {
    cardsGrid.style.display = teacherViewMode === 'grid' ? 'grid' : 'none';
    if (teacherViewMode === 'grid') renderTeacherCards(teachers, cardsGrid);
  }
  tbody.innerHTML = teachers.length ? teachers.map(t=>`<tr>
    <td style="min-width:150px"><div style="display:flex;align-items:center;gap:10px">
      ${ProfileImage.avatar(t, '', 'width:32px;height:32px;font-size:0.75rem;flex-shrink:0;background:linear-gradient(135deg,var(--secondary),var(--info))')}
      <div><div style="font-weight:600;font-size:0.88rem;white-space:nowrap">${t.name}</div>
      <div style="font-size:0.72rem;color:var(--text-muted);white-space:nowrap">${t.email||'—'}</div></div></div></td>
    <td style="font-size:0.85rem;white-space:nowrap">${t.qualification||'—'}</td>
    <td style="font-size:0.85rem;white-space:nowrap">${t.subject||'—'}</td>
    <td style="font-size:0.82rem;white-space:nowrap">${t.mobile||'—'}</td>
    <td><span class="badge ${t.active?'badge-success':'badge-danger'}">${t.active?'Active':'Inactive'}</span></td>
    <td style="white-space:nowrap">
      <div style="display:flex;gap:6px">
        <button class="btn btn-sm btn-secondary" onclick="viewTeacher('${t.id}')">View</button>
        <button class="btn btn-sm btn-ghost" onclick="downloadTeacherProfileReport('${t.id}')">Report</button>
        <button class="btn btn-sm btn-ghost" onclick="editTeacher('${t.id}')">Edit</button>
        <button class="btn btn-sm btn-danger" onclick="deleteTeacher('${t.id}','${t.name}')">Delete</button>
      </div>
    </td>
  </tr>`).join('') : '<tr><td colspan="6" style="text-align:center;padding:40px;color:var(--text-muted)">No teachers found.</td></tr>';
}

function renderTeacherCards(teachers, container) {
  container.innerHTML = teachers.length ? teachers.map(t => {
    const currentMonth = new Date().toISOString().slice(0, 7);
    const attendance = DB.attendanceSummary(t.id, currentMonth);
    return `<article class="person-card">
      <div class="person-card-top">
        <div style="display:flex;gap:10px;align-items:center;min-width:0">
          ${ProfileImage.avatar(t, '', 'width:42px;height:42px;font-size:0.82rem;flex-shrink:0;background:linear-gradient(135deg,var(--secondary),var(--info))')}
          <div style="min-width:0">
            <div class="person-title">${Fmt.escape(t.name)}</div>
            <div class="card-meta-line"><span>${Fmt.escape(t.subject || 'Faculty')}</span><span>${Fmt.escape(t.gender || '-')}</span></div>
          </div>
        </div>
        <span class="badge ${t.active ? 'badge-success' : 'badge-danger'}">${t.active ? 'Active' : 'Inactive'}</span>
      </div>
      <div class="detail-row"><span>Mobile</span><strong>${Fmt.escape(t.mobile || '-')}</strong></div>
      <div class="detail-row"><span>Email</span><strong>${Fmt.escape(t.email || '-')}</strong></div>
      <div class="detail-row"><span>Qualification</span><strong>${Fmt.escape(t.qualification || '-')}</strong></div>
      <div class="detail-row"><span>Join Date</span><strong>${Fmt.date(t.joinDate)}</strong></div>
      <div class="detail-row"><span>Present</span><strong>${attendance.present} this month</strong></div>
      <div class="card-actions">
        <button class="btn btn-sm btn-secondary" onclick="viewTeacher('${t.id}')">View</button>
        <button class="btn btn-sm btn-ghost" onclick="downloadTeacherProfileReport('${t.id}')">Report</button>
        <button class="btn btn-sm btn-ghost" onclick="editTeacher('${t.id}')">Edit</button>
        <button class="btn btn-sm btn-danger" onclick="deleteTeacher('${t.id}','${Fmt.escape(t.name)}')">Delete</button>
      </div>
    </article>`;
  }).join('') : '<div class="empty-state"><p>No teachers found</p></div>';
}

/* ---- ADD/EDIT STUDENT MODAL ---- */
function openAddStudentModal() {
  editingId = null;
  document.getElementById('studentModalTitle').textContent = '➕ Add New Student';
  document.getElementById('studentForm').reset();
  ensureProfileImageControls();
  studentImageControl.setValue('');
  // Reset course checkboxes
  renderCourseCheckboxes();
  Modal.open('studentModal');
}

function editStudent(id) {
  editingId = id;
  const s = DB.getStudent(id);
  if (!s) return;
  document.getElementById('studentModalTitle').textContent = '✏️ Edit Student — ' + s.name;
  // Populate all fields
  const fields = ['name','fatherName','motherName','gender','dob','mobile','altMobile','email',
    'aadhaar','qualification','religion','caste','maritalStatus','familyMembers','annualIncome',
    'fatherOccupation','motherOccupation','address','landmark','village','district','pincode',
    'state','reference','occupation','experience','batchNo','pcNo','timings','day',
    'totalFees','monthlyFees','duration','admissionDate','courseStatus','username','password',
    'grade','percentage','rank','feedback','resignNo'];
  fields.forEach(f=>{
    const el=document.getElementById('sf_'+f);
    if(el) el.value=s[f]||'';
  });
  ensureProfileImageControls();
  studentImageControl.setValue(s.profileImage || '');
  renderCourseCheckboxes(s.courseId, s.subcategories||[]);
  Modal.open('studentModal');
}

function ensureProfileImageControls() {
  if (!studentImageControl) studentImageControl = ProfileImage.bindInput('sf_profileImage','sf_profileImagePreview','');
  if (!teacherImageControl) teacherImageControl = ProfileImage.bindInput('tf_profileImage','tf_profileImagePreview','');
}

function renderCourseCheckboxes(selectedCourseId, selectedSubs=[]) {
  const courses = DB.getCourses();
  const container = document.getElementById('courseCheckboxContainer');
  if (!container) return;
  container.innerHTML = courses.map(c=>`
    <div style="margin-bottom:12px;background:var(--glass-bg-ultra-light);border-radius:8px;padding:10px;border:1px solid var(--glass-border)">
      <label class="checkbox-group" style="margin-bottom:6px">
        <input type="radio" name="courseSelect" value="${c.id}" ${selectedCourseId===c.id?'checked':''}
          onchange="renderSubcatCheckboxes('${c.id}')" style="accent-color:var(--primary)">
        <strong>${c.name}</strong>
        <span class="text-muted" style="font-size:0.78rem">(${c.duration} — ${Fmt.currency(c.fees)})</span>
      </label>
      <div id="subcat_${c.id}" style="${selectedCourseId===c.id?'':'display:none'};padding-left:16px;display:flex;flex-wrap:wrap;gap:8px">
        ${c.subcategories.map(sub=>`
          <label class="checkbox-group">
            <input type="checkbox" name="subcat" value="${sub}" ${selectedSubs.includes(sub)?'checked':''}
              style="accent-color:var(--primary)">
            <span style="font-size:0.82rem">${sub}</span>
          </label>`).join('')}
      </div>
    </div>`).join('');
}

function renderSubcatCheckboxes(courseId) {
  DB.getCourses().forEach(c=>{
    const div = document.getElementById('subcat_'+c.id);
    if(div) div.style.display = c.id===courseId ? 'flex' : 'none';
  });
  // Update course fields
  const courses = DB.getCourses();
  const c = courses.find(x=>x.id===courseId);
  if(c){
    const feeEl = document.getElementById('sf_totalFees');
    const durEl = document.getElementById('sf_duration');
    if(feeEl) feeEl.value = c.fees;
    if(durEl) durEl.value = c.duration;
  }
}

function bindStudentForm() {
  const form = document.getElementById('studentForm');
  if (!form) return;
  form.addEventListener('submit', e=>{
    e.preventDefault();
    const fd = new FormData(form);
    const get = id => { const el=document.getElementById('sf_'+id); return el?el.value:''; };

    // Get selected course
    const courseRadio = form.querySelector('input[name="courseSelect"]:checked');
    const courseId = courseRadio ? courseRadio.value : '';
    const courses = DB.getCourses();
    const course = courses.find(c=>c.id===courseId);
    const subcategories = [...form.querySelectorAll('input[name="subcat"]:checked')].map(c=>c.value);

    const student = {
      name:get('name'), fatherName:get('fatherName'), motherName:get('motherName'),
      gender:get('gender'), dob:get('dob'), mobile:get('mobile'), altMobile:get('altMobile'),
      email:get('email'), aadhaar:get('aadhaar'), qualification:get('qualification'),
      religion:get('religion'), caste:get('caste'), maritalStatus:get('maritalStatus'),
      familyMembers:get('familyMembers'), annualIncome:get('annualIncome'),
      fatherOccupation:get('fatherOccupation'), motherOccupation:get('motherOccupation'),
      address:get('address'), landmark:get('landmark'), village:get('village'),
      district:get('district'), pincode:get('pincode'), state:get('state'),
      reference:get('reference'), occupation:get('occupation'), experience:get('experience'),
      batchNo:get('batchNo'), pcNo:get('pcNo'), timings:get('timings'), day:get('day'),
      totalFees:Number(get('totalFees'))||0, monthlyFees:Number(get('monthlyFees'))||0,
      duration:get('duration'), admissionDate:get('admissionDate'),
      courseId, course:course?course.name:'', subcategories,
      courseStatus:get('courseStatus')||'Continue',
      username:get('username'), password:get('password')||'student123',
      grade:get('grade'), percentage:Number(get('percentage'))||0,
      rank:Number(get('rank'))||0, feedback:get('feedback'), resignNo:get('resignNo'),
      profileImage: studentImageControl ? studentImageControl.getValue() : '',
      active:true,
    };

    if(!student.name.trim()){ Toast.warning('Student name is required'); return; }

    if(editingId){
      DB.updateStudent(editingId, student);
      Toast.success('Student updated successfully!');
    } else {
      DB.addStudent(student);
      Toast.success('Student added successfully!');
    }
    Modal.close('studentModal');
    enhancePeoplePageControls();
    renderStudentList();
    showAutoSave();
  });
}

/* ---- VIEW STUDENT ---- */
function viewStudent(id) {
  const s = DB.getStudent(id);
  if (!s) return;
  viewingId = id;
  const paid = DB.paidFees(id);
  const balance = (s.totalFees||0)-paid;
  const modal = document.getElementById('viewStudentModal');
  const content = document.getElementById('viewStudentContent');
  if (!content) return;

  content.innerHTML = `
    <div class="profile-header">
      ${ProfileImage.avatar(s, 'avatar-xl')}
      <div class="profile-info">
        <h3>${s.name}</h3>
        <div class="role-badge">👨‍🎓 Student</div>
        <div style="margin-top:8px;font-size:0.82rem;color:var(--text-muted)">${s.course||'No Course'} • ${s.batchNo||''} • ${s.pcNo||''}</div>
        <div style="margin-top:4px;font-size:0.82rem;color:var(--text-muted)">${s.timings||''} ${s.day||''}</div>
      </div>
      <div style="margin-left:auto;text-align:right">
        <div style="font-size:0.75rem;color:var(--text-muted)">Admission Date</div>
        <div style="font-weight:700">${Fmt.date(s.admissionDate)}</div>
        <div style="margin-top:8px">
          <span class="badge ${{Continue:'badge-primary',Complete:'badge-success',Pending:'badge-warning',Leave:'badge-warning',Left:'badge-danger'}[s.courseStatus]||'badge-info'}">${s.courseStatus}</span>
        </div>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;margin-top:16px">
      ${infoBlock('📱 Mobile',s.mobile)} ${infoBlock('✉️ Email',s.email)}
      ${infoBlock('🎂 DOB',Fmt.date(s.dob)+' (Age: '+Fmt.age(s.dob)+')')}
      ${infoBlock('🪪 Aadhaar',s.aadhaar)} ${infoBlock('👤 Gender',s.gender)}
      ${infoBlock('🎓 Qualification',s.qualification)} ${infoBlock('🛐 Religion',s.religion)}
      ${infoBlock('👨‍👩‍👧 Caste',s.caste)} ${infoBlock('💍 Marital',s.maritalStatus)}
      ${infoBlock('👥 Family Members',s.familyMembers)} ${infoBlock('💰 Annual Income','₹'+s.annualIncome)}
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-top:12px">
      <div class="glass-card" style="text-align:center"><div class="text-muted" style="font-size:0.75rem">Total Fees</div><div style="font-size:1.3rem;font-weight:700">${Fmt.currency(s.totalFees)}</div></div>
      <div class="glass-card" style="text-align:center"><div class="text-muted" style="font-size:0.75rem">Paid</div><div style="font-size:1.3rem;font-weight:700;color:var(--success)">${Fmt.currency(paid)}</div></div>
      <div class="glass-card" style="text-align:center"><div class="text-muted" style="font-size:0.75rem">Balance</div><div style="font-size:1.3rem;font-weight:700;color:${balance>0?'var(--danger)':'var(--success)'}">${Fmt.currency(balance)}</div></div>
    </div>
    ${s.subcategories&&s.subcategories.length?`<div style="margin-top:12px"><div class="text-muted" style="font-size:0.78rem;margin-bottom:8px">SUBCATEGORIES</div><div style="display:flex;flex-wrap:wrap;gap:6px">${s.subcategories.map(sub=>`<span class="badge badge-primary">${sub}</span>`).join('')}</div></div>`:''}
    <div style="margin-top:12px;font-size:0.82rem;color:var(--text-muted)">
      <strong>Username:</strong> ${s.username||'Not set'} &nbsp;|&nbsp; <strong>Father:</strong> ${s.fatherName||'—'} &nbsp;|&nbsp; <strong>Address:</strong> ${s.address||'—'}, ${s.district||''}, ${s.state||''}
    </div>
  `;

  document.getElementById('viewStudentModalTitle').textContent = '👤 ' + s.name;
  content.insertAdjacentHTML('beforeend', `
    <div class="profile-report-actions">
      <button class="btn btn-primary" onclick="downloadStudentProfileReport('${s.id}')">Download Full Profile Report</button>
      <button class="btn btn-secondary" onclick="CertificateGenerator.generate(DB.getStudent('${s.id}'))">Course Certificate</button>
    </div>
  `);
  Modal.open('viewStudentModal');
}

function infoBlock(label, val) {
  return `<div class="glass-card" style="padding:12px"><div style="font-size:0.7rem;color:var(--text-muted);margin-bottom:2px">${label}</div><div style="font-size:0.85rem;font-weight:600">${val||'—'}</div></div>`;
}

function downloadStudentProfileReport(id) {
  const s = DB.getStudent(id || viewingId);
  if (!s) { Toast.warning('Open a student profile first'); return; }

  const paid = DB.paidFees(s.id);
  const balance = (s.totalFees || 0) - paid;
  const fees = DB.getStudentFees(s.id);
  const currentMonth = new Date().toISOString().slice(0, 7);
  const attendance = DB.attendanceSummary(s.id, currentMonth);
  const settings = DB.getSettings();
  const image = s.profileImage
    ? `<img src="${s.profileImage}" alt="${Fmt.escape(s.name)}" style="width:92px;height:92px;object-fit:cover;border-radius:14px;border:2px solid #047857">`
    : `<div style="width:92px;height:92px;border-radius:14px;border:2px solid #047857;display:flex;align-items:center;justify-content:center;font-size:26px;font-weight:800;color:#047857">${Fmt.initials(s.name)}</div>`;

  const detailRows = [
    ['Student ID', s.id], ['Full Name', s.name], ['Father Name', s.fatherName], ['Mother Name', s.motherName],
    ['Gender', s.gender], ['Date of Birth', Fmt.date(s.dob)], ['Mobile', s.mobile], ['Alternate Mobile', s.altMobile],
    ['Email', s.email], ['Aadhaar', s.aadhaar], ['Qualification', s.qualification], ['Religion', s.religion],
    ['Category/Caste', s.caste], ['Marital Status', s.maritalStatus], ['Family Members', s.familyMembers],
    ['Annual Income', s.annualIncome ? Fmt.currency(s.annualIncome) : ''], ['Address', [s.address, s.landmark, s.village, s.district, s.state, s.pincode].filter(Boolean).join(', ')],
    ['Course', s.course], ['Subcategories', (s.subcategories || []).join(', ')], ['Batch', s.batchNo],
    ['PC/Laptop', s.pcNo], ['Timings', s.timings], ['Days', s.day], ['Duration', s.duration],
    ['Admission Date', Fmt.date(s.admissionDate)], ['Course Status', s.courseStatus], ['Reference', s.reference],
    ['Username', s.username], ['Grade', s.grade], ['Percentage', s.percentage ? s.percentage + '%' : ''],
    ['Rank', s.rank], ['Feedback', s.feedback],
  ].map(([key, value]) => `<tr><td>${Fmt.escape(key)}</td><td>${Fmt.escape(value || '—')}</td></tr>`).join('');

  const paymentRows = fees.length ? fees.map(f => `<tr>
    <td>${Fmt.escape(Fmt.date(f.date))}</td>
    <td>${Fmt.escape(f.mode || 'Cash')}</td>
    <td>${Fmt.escape(f.receiptNo || f.id || '—')}</td>
    <td style="text-align:right">${Fmt.currency(f.amount || 0)}</td>
    <td>${Fmt.escape(f.note || f.remark || '')}</td>
  </tr>`).join('') : '<tr><td colspan="5" style="text-align:center;color:#666">No payment records</td></tr>';

  Exporter.toPDF_simple('Student Full Profile - ' + s.name, `
    <style>
      .profile-report td{border:1px solid #ddd;padding:7px;font-size:12px}
      .profile-report td:first-child{width:34%;font-weight:700;background:#f3f8f5}
      .profile-report th{background:#047857;color:#fff;padding:8px;text-align:left;font-size:12px}
      .summary-box{border:1px solid #d8e6dd;background:#f4fbf7;border-radius:8px;padding:10px;text-align:center}
      .summary-box strong{display:block;font-size:16px;color:#047857}
    </style>
    <div style="border:2px solid #047857;border-radius:12px;overflow:hidden">
      <div style="display:flex;gap:18px;align-items:center;background:#047857;color:#fff;padding:18px 22px">
        ${image}
        <div>
          <div style="font-size:22px;font-weight:800">${Fmt.escape(s.name)}</div>
          <div style="font-size:12px;opacity:0.9">${Fmt.escape(s.course || 'No course')} | ${Fmt.escape(s.batchNo || 'No batch')} | ${Fmt.escape(s.courseStatus || '')}</div>
          <div style="font-size:12px;opacity:0.9">${Fmt.escape(settings.academyName || 'Computer Care')}</div>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;padding:16px;background:#fff">
        <div class="summary-box"><span>Total Fees</span><strong>${Fmt.currency(s.totalFees || 0)}</strong></div>
        <div class="summary-box"><span>Paid</span><strong>${Fmt.currency(paid)}</strong></div>
        <div class="summary-box"><span>Balance</span><strong style="color:${balance > 0 ? '#dc2626' : '#047857'}">${Fmt.currency(balance)}</strong></div>
        <div class="summary-box"><span>This Month Present</span><strong>${attendance.present}</strong></div>
      </div>
      <div style="padding:0 16px 18px;background:#fff">
        <h2 style="font-size:16px;margin:6px 0 10px;color:#047857">Full Profile Details</h2>
        <table class="profile-report" style="width:100%;border-collapse:collapse">${detailRows}</table>
        <h2 style="font-size:16px;margin:18px 0 10px;color:#047857">Fee Ledger</h2>
        <table style="width:100%;border-collapse:collapse;font-size:12px">
          <thead><tr><th>Date</th><th>Mode</th><th>Receipt</th><th>Amount</th><th>Note</th></tr></thead>
          <tbody>${paymentRows}</tbody>
        </table>
      </div>
    </div>
  `);
  Toast.success('Student profile report generated');
}

function deleteStudent(id, name) {
  if (!confirm(`Delete student "${name}"? This cannot be undone.`)) return;
  DB.deleteStudent(id);
  Toast.success('Student deleted');
  enhancePeoplePageControls();
  renderStudentList();
}

/* ---- TEACHER FORM ---- */
let editingTeacherId = null;

function openAddTeacherModal() {
  editingTeacherId = null;
  document.getElementById('teacherModalTitle').textContent = '➕ Add New Teacher';
  document.getElementById('teacherForm').reset();
  ensureProfileImageControls();
  teacherImageControl.setValue('');
  Modal.open('teacherModal');
}

function editTeacher(id) {
  editingTeacherId = id;
  const t = DB.getTeacher(id);
  if (!t) return;
  document.getElementById('teacherModalTitle').textContent = '✏️ Edit Teacher — ' + t.name;
  const fields = ['name','qualification','subject','mobile','email','gender','dob','joinDate','address','username','password','performance'];
  fields.forEach(f=>{ const el=document.getElementById('tf_'+f); if(el) el.value=t[f]||''; });
  ensureProfileImageControls();
  teacherImageControl.setValue(t.profileImage || '');
  Modal.open('teacherModal');
}

function bindTeacherForm() {
  const form = document.getElementById('teacherForm');
  if (!form) return;
  form.addEventListener('submit', e=>{
    e.preventDefault();
    const get = id=>{ const el=document.getElementById('tf_'+id); return el?el.value:''; };
    const teacher = {
      name:get('name'), qualification:get('qualification'), subject:get('subject'),
      mobile:get('mobile'), email:get('email'), gender:get('gender'),
      dob:get('dob'), joinDate:get('joinDate'), address:get('address'),
      username:get('username'), password:get('password')||'teacher123',
      performance:get('performance'), role:'teacher', active:true,
      profileImage: teacherImageControl ? teacherImageControl.getValue() : '',
    };
    if(!teacher.name.trim()){ Toast.warning('Teacher name is required'); return; }
    if(editingTeacherId){
      DB.updateTeacher(editingTeacherId, teacher);
      Toast.success('Teacher updated!');
    } else {
      DB.addTeacher(teacher);
      Toast.success('Teacher added!');
    }
    Modal.close('teacherModal');
    enhancePeoplePageControls();
    renderTeacherList();
    showAutoSave();
  });
}

function deleteTeacher(id, name) {
  if (!confirm(`Delete teacher "${name}"?`)) return;
  DB.deleteTeacher(id);
  Toast.success('Teacher deleted');
  renderTeacherList();
}

function canViewTeacherFinancials(teacher) {
  const session = Auth.getSession ? Auth.getSession() : null;
  return !!session && (session.role === 'admin' || session.id === teacher.id);
}

function teacherFinancialSummary(teacher) {
  const salary = DB.getSalary ? DB.getSalary(teacher.id) : { records:[], baseSalary:0 };
  const records = salary.records || [];
  const baseSalary = Number(salary.baseSalary || teacher.salary || 0);
  const paid = records.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
  return { baseSalary, paid, records };
}

function viewTeacher(id) {
  const t = DB.getTeacher(id);
  if (!t) return;
  const content = document.getElementById('viewTeacherContent');
  if (!content) return;

  const currentMonth = new Date().toISOString().slice(0, 7);
  const attendance = DB.attendanceSummary(t.id, currentMonth);
  const financials = teacherFinancialSummary(t);
  const showFinancials = canViewTeacherFinancials(t);

  content.innerHTML = `
    <div class="profile-header">
      ${ProfileImage.avatar(t, 'avatar-xl', 'background:linear-gradient(135deg,var(--secondary),var(--info))')}
      <div class="profile-info">
        <h3>${Fmt.escape(t.name)}</h3>
        <div class="role-badge">Teacher</div>
        <div style="margin-top:8px;font-size:0.82rem;color:var(--text-muted)">${Fmt.escape(t.subject || 'Faculty')} &middot; ${Fmt.escape(t.qualification || 'Qualification not set')}</div>
        <div style="margin-top:4px;font-size:0.82rem;color:var(--text-muted)">Joined ${Fmt.escape(Fmt.date(t.joinDate))}</div>
      </div>
      <div style="margin-left:auto;text-align:right">
        <div style="font-size:0.75rem;color:var(--text-muted)">Status</div>
        <span class="badge ${t.active ? 'badge-success' : 'badge-danger'}">${t.active ? 'Active' : 'Inactive'}</span>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;margin-top:16px">
      ${infoBlock('Mobile', t.mobile)}
      ${infoBlock('Email', t.email)}
      ${infoBlock('Gender', t.gender)}
      ${infoBlock('DOB', Fmt.date(t.dob) + (t.dob ? ' (Age: ' + Fmt.age(t.dob) + ')' : ''))}
      ${infoBlock('Performance', t.performance)}
      ${infoBlock('Username', t.username)}
      ${infoBlock('Address', t.address)}
      ${infoBlock('This Month Present', attendance.present)}
    </div>
    ${showFinancials ? `
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:12px">
        <div class="glass-card" style="text-align:center"><div class="text-muted" style="font-size:0.75rem">Base Salary</div><div style="font-size:1.25rem;font-weight:700">${Fmt.currency(financials.baseSalary)}</div></div>
        <div class="glass-card" style="text-align:center"><div class="text-muted" style="font-size:0.75rem">Salary Paid</div><div style="font-size:1.25rem;font-weight:700;color:var(--success)">${Fmt.currency(financials.paid)}</div></div>
      </div>` : ''}
    <div class="profile-report-actions">
      <button class="btn btn-primary" onclick="downloadTeacherProfileReport('${t.id}')">Download Full Teacher Report</button>
      <button class="btn btn-secondary" onclick="Modal.close('viewTeacherModal')">Close</button>
    </div>
  `;

  document.getElementById('viewTeacherModalTitle').textContent = t.name + ' Profile';
  Modal.open('viewTeacherModal');
}

function downloadTeacherProfileReport(id) {
  const t = DB.getTeacher(id);
  if (!t) { Toast.warning('Teacher not found'); return; }

  const settings = DB.getSettings();
  const currentMonth = new Date().toISOString().slice(0, 7);
  const attendance = DB.attendanceSummary(t.id, currentMonth);
  const financials = teacherFinancialSummary(t);
  const showFinancials = canViewTeacherFinancials(t);
  const image = t.profileImage
    ? `<img src="${t.profileImage}" alt="${Fmt.escape(t.name)}" style="width:92px;height:92px;object-fit:cover;border-radius:14px;border:2px solid #2563eb">`
    : `<div style="width:92px;height:92px;border-radius:14px;border:2px solid #2563eb;display:flex;align-items:center;justify-content:center;font-size:26px;font-weight:800;color:#2563eb">${Fmt.initials(t.name)}</div>`;

  const detailRows = [
    ['Teacher ID', t.id],
    ['Full Name', t.name],
    ['Qualification', t.qualification],
    ['Subject / Expertise', t.subject],
    ['Mobile', t.mobile],
    ['Email', t.email],
    ['Gender', t.gender],
    ['Date of Birth', Fmt.date(t.dob)],
    ['Join Date', Fmt.date(t.joinDate)],
    ['Performance', t.performance],
    ['Username', t.username],
    ['Status', t.active ? 'Active' : 'Inactive'],
    ['Address', t.address],
    ['Current Month Present', attendance.present],
    ['Current Month Absent', attendance.absent],
    ['Current Month Leave', attendance.leave],
  ];

  if (showFinancials) {
    detailRows.push(['Base Salary', Fmt.currency(financials.baseSalary)]);
    detailRows.push(['Salary Paid Records', String(financials.records.length)]);
    detailRows.push(['Total Salary Paid', Fmt.currency(financials.paid)]);
  }

  const rows = detailRows
    .map(([key, value]) => `<tr><td>${Fmt.escape(key)}</td><td>${Fmt.escape(value || '-')}</td></tr>`)
    .join('');

  Exporter.toPDF_simple('Teacher Full Profile - ' + t.name, `
    <style>
      .teacher-report td{border:1px solid #ddd;padding:7px;font-size:12px}
      .teacher-report td:first-child{width:34%;font-weight:700;background:#f3f6fb}
      .summary-box{border:1px solid #d8e2f0;background:#f5f8ff;border-radius:8px;padding:10px;text-align:center}
      .summary-box strong{display:block;font-size:16px;color:#2563eb}
    </style>
    <div style="border:2px solid #2563eb;border-radius:12px;overflow:hidden">
      <div style="display:flex;gap:18px;align-items:center;background:#2563eb;color:#fff;padding:18px 22px">
        ${image}
        <div>
          <div style="font-size:22px;font-weight:800">${Fmt.escape(t.name)}</div>
          <div style="font-size:12px;opacity:0.9">${Fmt.escape(t.subject || 'Faculty')} | ${Fmt.escape(t.qualification || '')}</div>
          <div style="font-size:12px;opacity:0.9">${Fmt.escape(settings.academyName || 'Computer Care')}</div>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;padding:16px;background:#fff">
        <div class="summary-box"><span>Present</span><strong>${attendance.present}</strong></div>
        <div class="summary-box"><span>Absent</span><strong>${attendance.absent}</strong></div>
        <div class="summary-box"><span>Leave</span><strong>${attendance.leave}</strong></div>
        <div class="summary-box"><span>Performance</span><strong>${Fmt.escape(t.performance || '-')}</strong></div>
      </div>
      <div style="padding:0 16px 18px;background:#fff">
        <h2 style="font-size:16px;margin:6px 0 10px;color:#2563eb">Full Profile Details</h2>
        <table class="teacher-report" style="width:100%;border-collapse:collapse">${rows}</table>
      </div>
    </div>
  `);
  Toast.success('Teacher profile report generated');
}

/* ---- EXPORT ---- */
function exportStudents(format) {
  const students = getFilteredStudents();
  if (format==='csv') {
    const headers = ['Name','Course','Batch','PC','Status','Mobile','Email','Total Fees','Paid','Balance','Admission Date'];
    const rows = students.map(s=>[
      s.name, s.course, s.batchNo, s.pcNo, s.courseStatus,
      s.mobile, s.email, s.totalFees, DB.paidFees(s.id), (s.totalFees||0)-DB.paidFees(s.id), s.admissionDate
    ]);
    Exporter.toCSV(headers, rows, 'students.csv');
    Toast.success('Exported as CSV!');
  } else if (format==='pdf') {
    const rows = students.map(s=>`<tr><td>${s.name}</td><td>${s.course||'—'}</td><td>${s.batchNo||'—'}</td><td class="${(s.totalFees||0)-DB.paidFees(s.id)>0?'':'success'}">${Fmt.currency((s.totalFees||0)-DB.paidFees(s.id))}</td><td>${s.courseStatus||'—'}</td></tr>`).join('');
    Exporter.toPDF_simple('Students Report', `<h2>Students List</h2><table><thead><tr><th>Name</th><th>Course</th><th>Batch</th><th>Balance</th><th>Status</th></tr></thead><tbody>${rows}</tbody></table>`);
  } else if (format==='json') {
    Exporter.toJSON(students, 'students.json');
    Toast.success('Exported as JSON!');
  }
}

function exportTeachers(format) {
  const teachers = getFilteredTeachers();
  if (format==='csv') {
    const headers = ['Name','Qualification','Subject','Mobile','Email','Join Date','Performance'];
    const rows = teachers.map(t=>[t.name,t.qualification,t.subject,t.mobile,t.email,t.joinDate,t.performance]);
    Exporter.toCSV(headers, rows, 'teachers.csv');
    Toast.success('Exported as CSV!');
  } else if (format==='pdf') {
    const rows = teachers.map(t=>`<tr><td>${t.name}</td><td>${t.qualification}</td><td>${t.subject}</td><td>${t.mobile}</td><td>${t.performance||'—'}</td></tr>`).join('');
    Exporter.toPDF_simple('Teachers Report', `<h2>Teachers List</h2><table><thead><tr><th>Name</th><th>Qualification</th><th>Subject</th><th>Mobile</th><th>Performance</th></tr></thead><tbody>${rows}</tbody></table>`);
  }
}

document.addEventListener('DOMContentLoaded', initStudentsPage);

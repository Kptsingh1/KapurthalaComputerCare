/* ==========================================================================
   TASKS.JS — Task Management for Students & Teachers
   Computer Care (Anubhav EduVista) Academy Management System
   ========================================================================== */

let tasksSession = null;

function initTasksPage() {
  tasksSession = Auth.requireAuth(['admin','teacher','student']);
  if (!tasksSession) return;
  renderTasksPage();
}

function renderTasksPage() {
  const isAdmin = tasksSession.role === 'admin';
  const isTeacher = tasksSession.role === 'teacher';
  const canAssign = isAdmin || isTeacher;

  // Render assign form only for admin/teacher
  const assignForm = document.getElementById('taskAssignForm');
  if (assignForm) {
    if (!canAssign) {
      assignForm.style.display = 'none';
    } else {
      populateAssignDropdowns();
    }
  }

  renderTasksList();
}

function populateAssignDropdowns() {
  const students = DB.getStudents();
  const teachers = DB.getTeachers();

  const assignTo = document.getElementById('taskAssignTo');
  if (!assignTo) return;
  assignTo.innerHTML = `<option value="">-- Select Person --</option>
    <optgroup label="👨‍🎓 Students">
      ${students.map(s=>`<option value="${s.id}" data-name="${s.name}" data-role="student">${s.name} (${s.batchNo||'No batch'})</option>`).join('')}
    </optgroup>
    <optgroup label="👨‍🏫 Teachers">
      ${teachers.map(t=>`<option value="${t.id}" data-name="${t.name}" data-role="teacher">${t.name}</option>`).join('')}
    </optgroup>`;
}

function saveTask() {
  const title = document.getElementById('taskTitle').value.trim();
  const desc  = document.getElementById('taskDesc').value.trim();
  const due   = document.getElementById('taskDue').value;
  const priority = document.getElementById('taskPriority').value;
  const assignToEl = document.getElementById('taskAssignTo');
  const assignedTo = assignToEl ? assignToEl.value : '';
  const opt = assignToEl ? assignToEl.options[assignToEl.selectedIndex] : null;
  const assignedName = opt ? opt.dataset.name || opt.text : '';
  const assignedRole = opt ? opt.dataset.role || '' : '';

  if (!title) { Toast.warning('Please enter a task title'); return; }

  DB.addTask({
    title, description: desc, dueDate: due, priority: priority || 'Medium',
    assignedTo, assignedName, assignedRole,
    createdBy: tasksSession.id, createdByName: tasksSession.name,
  });

  // Reset form
  document.getElementById('taskTitle').value = '';
  document.getElementById('taskDesc').value = '';
  document.getElementById('taskDue').value = '';
  if (document.getElementById('taskPriority')) document.getElementById('taskPriority').value = 'Medium';

  Toast.success('Task assigned successfully!');
  renderTasksList();
}

function updateTaskStatus(taskId, newStatus) {
  DB.updateTask(taskId, { status: newStatus, updatedAt: new Date().toISOString() });
  renderTasksList();
  Toast.info(`Task marked as ${newStatus}`);
}

function deleteTask(taskId) {
  if (!confirm('Delete this task?')) return;
  DB.deleteTask(taskId);
  renderTasksList();
  Toast.success('Task deleted');
}

function renderTasksList() {
  const container = document.getElementById('tasksList');
  if (!container) return;

  const allTasks = DB.getTasks();
  const session = tasksSession;
  let tasks;

  if (session.role === 'admin') {
    tasks = allTasks;
  } else if (session.role === 'teacher') {
    tasks = allTasks.filter(t => t.assignedTo === session.id || t.createdBy === session.id || t.assignedRole === 'teacher');
  } else {
    tasks = allTasks.filter(t => t.assignedTo === session.id);
  }

  // Filter by active tab
  const activeTab = document.querySelector('.task-tab-btn.active');
  const filter = activeTab ? activeTab.dataset.filter : 'all';
  if (filter !== 'all') {
    tasks = tasks.filter(t => t.status === filter);
  }

  // Update counts
  const allTasks2 = session.role === 'admin' ? allTasks : allTasks.filter(t => t.assignedTo === session.id || t.createdBy === session.id);
  document.querySelectorAll('.task-count').forEach(el => {
    const f = el.dataset.filter;
    if (f === 'all') el.textContent = allTasks2.length;
    else el.textContent = allTasks2.filter(t=>t.status===f).length;
  });

  if (!tasks.length) {
    container.innerHTML = `<div class="empty-state"><div class="empty-state-icon">📋</div><p>No tasks found</p></div>`;
    return;
  }

  const priorityColors = { High:'var(--danger)', Medium:'var(--warning)', Low:'var(--success)' };
  const statusColors = { Pending:'var(--warning)', 'In Progress':'var(--info)', Completed:'var(--success)', Cancelled:'var(--danger)' };

  container.innerHTML = tasks.map(task => {
    const isOverdue = task.dueDate && new Date(task.dueDate) < new Date() && task.status !== 'Completed';
    const canModify = session.role === 'admin' || task.assignedTo === session.id || task.createdBy === session.id;
    return `<div class="glass-card task-card" style="margin-bottom:12px;padding:16px;border-left:4px solid ${priorityColors[task.priority]||'var(--primary)'}">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px;flex-wrap:wrap">
        <div style="flex:1">
          <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px">
            <span style="font-weight:700;font-size:0.95rem">${task.title}</span>
            <span class="badge" style="background:${priorityColors[task.priority]||'var(--primary)'}22;color:${priorityColors[task.priority]||'var(--primary)'};font-size:0.7rem">${task.priority||'Medium'}</span>
            <span class="badge" style="background:${statusColors[task.status]||'var(--info)'}22;color:${statusColors[task.status]||'var(--info)'};font-size:0.7rem">${task.status}</span>
            ${isOverdue?`<span class="badge" style="background:var(--danger)22;color:var(--danger);font-size:0.7rem">⚠️ Overdue</span>`:''}
          </div>
          ${task.description?`<div style="font-size:0.83rem;color:var(--text-muted);margin-bottom:6px">${task.description}</div>`:''}
          <div style="display:flex;gap:16px;flex-wrap:wrap;font-size:0.78rem;color:var(--text-muted)">
            ${task.assignedName?`<span>👤 ${task.assignedName}</span>`:''}
            ${task.dueDate?`<span style="${isOverdue?'color:var(--danger);font-weight:700':''}">📅 Due: ${Fmt.date(task.dueDate)}</span>`:''}
            <span>👨‍💼 By: ${task.createdByName||'Admin'}</span>
            <span>🕒 ${Fmt.date(task.createdAt)}</span>
          </div>
        </div>
        ${canModify?`<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">
          ${task.status !== 'Completed' ? `
            <button class="btn btn-sm btn-success" onclick="updateTaskStatus('${task.id}','Completed')">✅ Done</button>
            ${task.status === 'Pending' ? `<button class="btn btn-sm btn-info" style="font-size:0.72rem" onclick="updateTaskStatus('${task.id}','In Progress')">▶ Start</button>` : ''}
          ` : `<button class="btn btn-sm btn-secondary" onclick="updateTaskStatus('${task.id}','Pending')">↩ Reopen</button>`}
          ${session.role==='admin'||task.createdBy===session.id?`<button class="btn btn-sm btn-danger" onclick="deleteTask('${task.id}')">🗑</button>`:''}
        </div>`:''}
      </div>
    </div>`;
  }).join('');
}

function filterTasksByTab(btn, filter) {
  document.querySelectorAll('.task-tab-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  renderTasksList();
}

document.addEventListener('DOMContentLoaded', initTasksPage);

/* ==========================================================================
   TIMETABLE.JS — Time Table Management
   ========================================================================== */

let ttData = null;
let editingCell = null;
let editingDevice = '';
let currentTTCourseStatus = 'Continue';
let currentTTBatch = 'All';
let currentTTCourse = 'All';
let currentTTTeacher = 'All';
let currentTTDevice = 'All';
let currentTTSearch = '';
let ttViewMode = AcademyView ? AcademyView.get('timetable_schedule', 'grid') : 'grid';

function initTimetablePage() {
  const session = Auth.requireAuth(['admin','teacher']);
  if (!session) return;
  ttData = DB.getTimetable();
  populateCourseStatusSelect('ttCourseStatusFilter', currentTTCourseStatus, true);
  enhanceTimetableControls();
  const statusFilter = document.getElementById('ttCourseStatusFilter');
  if (statusFilter) {
    statusFilter.value = currentTTCourseStatus;
    statusFilter.addEventListener('change', () => {
      currentTTCourseStatus = statusFilter.value || 'All';
      renderTimetable();
      renderBatchOverview();
    });
  }
  renderTimetable();
  bindTimetableForms();
  renderBatchOverview();
}

function enhanceTimetableControls() {
  const header = document.querySelector('.tt-grid-header');
  if (header && !document.getElementById('ttAdvancedFilters')) {
    header.insertAdjacentHTML('afterend', `
      <div class="academy-filter-panel" id="ttAdvancedFilters" data-no-auto-enhance="true">
        <div class="academy-filter-grid">
          <div class="search-wrapper">
            <span class="search-icon">&#128269;</span>
            <input type="search" id="ttSearchFilter" class="form-control" placeholder="Search subject, teacher, batch, student, notes">
          </div>
          <select id="ttCourseFilter" class="form-control">${AcademyFilters.coursesOptions()}</select>
          <select id="ttBatchFilter" class="form-control">${AcademyFilters.batchOptions()}</select>
          <select id="ttTeacherFilter" class="form-control"></select>
          <select id="ttDeviceFilter" class="form-control"></select>
          <button type="button" class="btn btn-secondary filter-clear-btn" onclick="clearTimetableFilters()">Clear Filters</button>
        </div>
      </div>
    `);
  }
  const timetableWrap = document.getElementById('timetableWrap');
  if (timetableWrap && !document.getElementById('ttViewToolbar')) {
    timetableWrap.insertAdjacentHTML('beforebegin', AcademyView.toolbarMarkup('timetable_schedule', ttViewMode, 'Timetable view', 'ttRecordCount', '0 classes'));
    const toolbar = document.querySelector('[data-view-toolbar="timetable_schedule"]');
    if (toolbar) toolbar.id = 'ttViewToolbar';
    AcademyView.bind(toolbar, 'timetable_schedule', mode => {
      ttViewMode = mode;
      renderTimetable();
    });
  }
  refreshTimetableFilterOptions();
  [
    ['ttSearchFilter', value => { currentTTSearch = value; }],
    ['ttCourseFilter', value => { currentTTCourse = value || 'All'; }],
    ['ttBatchFilter', value => { currentTTBatch = value || 'All'; }],
    ['ttTeacherFilter', value => { currentTTTeacher = value || 'All'; }],
    ['ttDeviceFilter', value => { currentTTDevice = value || 'All'; }],
  ].forEach(([id, setter]) => {
    const el = document.getElementById(id);
    if (!el || el.dataset.boundTTFilter === '1') return;
    el.dataset.boundTTFilter = '1';
    const refresh = () => {
      setter(el.value || '');
      renderTimetable();
      renderBatchOverview();
    };
    el.addEventListener('input', refresh);
    el.addEventListener('change', refresh);
  });
}

function refreshTimetableFilterOptions() {
  const teacherSel = document.getElementById('ttTeacherFilter');
  if (teacherSel) {
    const old = teacherSel.value || currentTTTeacher || 'All';
    teacherSel.innerHTML = AcademyFilters.optionList(DB.getTeachers().map(t => t.name), old, 'All Teachers');
    teacherSel.value = [...teacherSel.options].some(o => o.value === old) ? old : 'All';
    currentTTTeacher = teacherSel.value || 'All';
  }
  const deviceSel = document.getElementById('ttDeviceFilter');
  if (deviceSel) {
    const old = deviceSel.value || currentTTDevice || 'All';
    deviceSel.innerHTML = AcademyFilters.optionList(getDevices(), old, 'All PCs / Laptops');
    deviceSel.value = [...deviceSel.options].some(o => o.value === old) ? old : 'All';
    currentTTDevice = deviceSel.value || 'All';
  }
}

function clearTimetableFilters() {
  const search = document.getElementById('ttSearchFilter');
  if (search) search.value = '';
  [['ttCourseFilter','All'],['ttBatchFilter','All'],['ttTeacherFilter','All'],['ttDeviceFilter','All'],['ttCourseStatusFilter','All']].forEach(([id, value]) => {
    const el = document.getElementById(id);
    if (el) el.value = value;
  });
  currentTTCourseStatus = 'All';
  currentTTBatch = 'All';
  currentTTCourse = 'All';
  currentTTTeacher = 'All';
  currentTTDevice = 'All';
  currentTTSearch = '';
  renderTimetable();
  renderBatchOverview();
}

function getStudentsForBatch(batchNo) {
  if (!batchNo) return [];
  return getTimetableStudents().filter(s => s.batchNo === batchNo && s.active !== false);
}

function getTimetableStudents() {
  return DB.filterStudents({
    status: currentTTCourseStatus,
    batch: currentTTBatch,
    courseId: currentTTCourse,
  }).filter(s => s.active !== false);
}

function getDevices() {
  return ttData.devices || ttData.days || DB.DEFAULT_DEVICES();
}

function syncTimetablePanelHeight(rowCount = 0, mode = ttViewMode) {
  const panel = document.querySelector('.tt-grid-panel');
  if (!panel) return;
  const isPhone = window.matchMedia && window.matchMedia('(max-width: 700px)').matches;
  const rows = Math.max(Number(rowCount) || 0, 1);
  const baseHeight = mode === 'list'
    ? Math.min(Math.max(620, rows * 155 + 120), 1180)
    : Math.min(Math.max(isPhone ? 620 : 780, rows * 116 + 140), 1380);
  panel.style.setProperty('--tt-panel-height', `${baseHeight}px`);
}

function deviceIcon(device) {
  return String(device || '').toLowerCase().includes('laptop') ? '💻' : '🖥️';
}

function renderTimetable() {
  enhanceTimetableControls();
  const wrap = document.getElementById('timetableWrap');
  if (!wrap) return;

  const { timeSlots, entries } = ttData;
  const devices = getDevices();
  if (ttViewMode === 'list') {
    renderTimetableList(wrap, timeSlots, devices, entries);
    return;
  }

  if (!timeSlots.length || !devices.length) {
    syncTimetablePanelHeight(4, 'grid');
    wrap.innerHTML = `<div class="empty-state" style="padding:60px 20px">
      <div class="empty-state-icon">📋</div>
      <p>Add Time Slots and Devices above to build your timetable</p>
    </div>`;
    return;
  }

  let html = `<div class="tt-scroll-inner">
  <table class="timetable" id="ttTable" style="border-collapse:collapse;width:100%">
    <thead><tr>
      <th class="tt-timecol-head">⏰ Time Slot</th>
      ${devices.map(d=>`<th class="tt-device-head"><span class="device-head-icon">${deviceIcon(d)}</span>${d}</th>`).join('')}
    </tr></thead>
    <tbody>`;

  timeSlots.forEach((slot,si)=>{
    html += `<tr class="tt-row">
      <td class="tt-timecol">${slot}</td>`;
    devices.forEach((device,di)=>{
      const key = `${si}_${di}`;
      const entry = entries[key] || {};
      const batchStudents = entry.batch ? getStudentsForBatch(entry.batch) : [];
      const assignedDevice = entry.device || entry.pc || device;
      const assignedName = entry.studentName || (entry.studentId && DB.getStudent(entry.studentId)?.name) || '';
      const hasContent = !!(entry.subject);

      html += `<td class="tt-cell${hasContent?' tt-cell-filled':''}" onclick="editTTCell('${key}','${slot}','${device}')">
        <div class="timetable-cell-content" title="Click to edit">
          ${hasContent ? `
            <div class="tt-subject">${entry.subject}</div>
            ${entry.teacher ? `<div class="tt-teacher">👨‍🏫 ${entry.teacher}</div>` : ''}
            <div class="tt-batch-pc">
              ${entry.batch ? `<span class="tt-badge-batch">🎓 ${entry.batch}</span>` : ''}
              <span class="tt-badge-pc">💻 ${assignedDevice}</span>
            </div>
            ${assignedName ? `<div class="tt-student-name">👤 ${assignedName}${!entry.batch?' <span class="tt-no-batch">(No Batch)</span>':''}</div>` : ''}
            ${batchStudents.length ? `<div class="tt-students-list">
              ${batchStudents.slice(0,5).map(s=>`<span class="tt-student-chip">${s.name.split(' ')[0]}${s.pcNo?` <em>${s.pcNo}</em>`:''}</span>`).join('')}
              ${batchStudents.length>5?`<span class="tt-chip-more">+${batchStudents.length-5}</span>`:''}
            </div>` : ''}
            ${entry.notes ? `<div class="tt-notes">📝 ${entry.notes}</div>` : ''}
          ` : `<div class="tt-empty-cell">${deviceIcon(device)}<br><span>+ Add Class</span></div>`}
        </div>
      </td>`;
    });
    html += `</tr>`;
  });

  html += `</tbody></table></div>`;
  wrap.innerHTML = html;
  syncTimetablePanelHeight(timeSlots.length, 'grid');
  updateTTRecordCount();
}

function entryMatchesTTFilters(entry, device, slot) {
  const q = String(currentTTSearch || '').trim().toLowerCase();
  const student = entry.studentId ? DB.getStudent(entry.studentId) : null;
  const batchStudents = entry.batch ? getStudentsForBatch(entry.batch) : [];
  const courseOk = currentTTCourse === 'All' || (student && student.courseId === currentTTCourse) || batchStudents.some(s => s.courseId === currentTTCourse);
  const batchOk = currentTTBatch === 'All' || entry.batch === currentTTBatch || (student && student.batchNo === currentTTBatch);
  const teacherOk = currentTTTeacher === 'All' || entry.teacher === currentTTTeacher;
  const deviceOk = currentTTDevice === 'All' || device === currentTTDevice || entry.device === currentTTDevice || entry.pc === currentTTDevice;
  const haystack = [
    entry.subject, entry.teacher, entry.batch, entry.studentName, entry.notes, device, slot,
    student && student.course, student && student.batchNo,
    ...batchStudents.map(s => `${s.name} ${s.course} ${s.batchNo}`),
  ].join(' ').toLowerCase();
  return courseOk && batchOk && teacherOk && deviceOk && (!q || haystack.includes(q));
}

function matchingTTEntries(timeSlots, devices, entries) {
  const rows = [];
  timeSlots.forEach((slot, si) => {
    devices.forEach((device, di) => {
      const entry = entries[`${si}_${di}`] || {};
      if (!entry.subject) return;
      if (!entryMatchesTTFilters(entry, device, slot)) return;
      rows.push({ key:`${si}_${di}`, slot, device, entry });
    });
  });
  return rows;
}

function updateTTRecordCount(count) {
  const el = document.getElementById('ttRecordCount');
  if (!el) return;
  const next = typeof count === 'number' ? count : matchingTTEntries(ttData.timeSlots || [], getDevices(), ttData.entries || {}).length;
  el.textContent = `${next} class${next === 1 ? '' : 'es'}`;
}

function renderTimetableList(wrap, timeSlots, devices, entries) {
  const rows = matchingTTEntries(timeSlots, devices, entries);
  updateTTRecordCount(rows.length);
  syncTimetablePanelHeight(Math.max(rows.length, 3), 'list');
  wrap.innerHTML = `<div class="tt-list-grid">
    ${rows.length ? rows.map(item => {
      const e = item.entry;
      const batchStudents = e.batch ? getStudentsForBatch(e.batch) : [];
      return `<article class="tt-list-card">
        <div class="person-card-top">
          <div>
            <div class="person-title">${Fmt.escape(e.subject || 'Class')}</div>
            <div class="card-meta-line"><span>${Fmt.escape(item.slot)}</span><span>${Fmt.escape(item.device)}</span></div>
          </div>
          <span class="badge badge-primary">${Fmt.escape(e.batch || 'No Batch')}</span>
        </div>
        <div class="detail-row"><span>Teacher</span><strong>${Fmt.escape(e.teacher || '-')}</strong></div>
        <div class="detail-row"><span>Students</span><strong>${Fmt.escape(e.studentName || (batchStudents.length ? batchStudents.map(s => s.name).slice(0, 6).join(', ') : '-'))}${batchStudents.length > 6 ? ' +' + (batchStudents.length - 6) : ''}</strong></div>
        <div class="detail-row"><span>Notes</span><strong>${Fmt.escape(e.notes || '-')}</strong></div>
        <div class="card-actions">
          <button class="btn btn-sm btn-primary" onclick="editTTCell('${item.key}','${Fmt.escape(item.slot)}','${Fmt.escape(item.device)}')">Edit</button>
          <button class="btn btn-sm btn-danger" onclick="editingCell='${item.key}';clearTTCell()">Clear</button>
        </div>
      </article>`;
    }).join('') : '<div class="empty-state"><p>No timetable classes match filters</p></div>'}
  </div>`;
}

function editTTCell(key, slot, device) {
  editingCell = key;
  editingDevice = device;
  const entry = ttData.entries[key] || { subject:'', teacher:'', batch:'', pc:device, device };
  const modal = document.getElementById('ttCellModal');
  if (!modal) return;

  document.getElementById('ttCellLabel').textContent = `${device} • ${slot}`;
  document.getElementById('ttSubject').value = entry.subject || '';
  document.getElementById('ttNotes').value = entry.notes || '';
  const deviceLabel = document.getElementById('ttDeviceLabel');
  if (deviceLabel) deviceLabel.textContent = `${deviceIcon(device)} ${device}`;

  // Populate teacher dropdown fresh each time
  const teachers = DB.getTeachers();
  const tSel = document.getElementById('ttTeacher');
  if (tSel) {
    tSel.innerHTML = `<option value="">-- Select Teacher --</option>` +
      teachers.map(t=>`<option value="${t.name}">${t.name} (${t.subject||''})</option>`).join('');
    tSel.value = entry.teacher || '';
  }

  // Populate batch dropdown with student count
  const bSel = document.getElementById('ttBatch');
  if (bSel) {
    const students = getTimetableStudents();
    const existingBatches = [...new Set(students.map(s=>s.batchNo).filter(Boolean))];
    const allBatches = [...new Set(['Batch 1','Batch 2','Batch 3','Batch 4','Batch 5','Batch 6', ...existingBatches])];
    bSel.innerHTML = `<option value="">-- Select Batch --</option>` +
      allBatches.map(b => {
        const count = students.filter(s=>s.batchNo===b).length;
        return `<option value="${b}">${b}${count?' ('+count+' students)':''}</option>`;
      }).join('');
    bSel.value = entry.batch || '';
    bSel.onchange = () => renderBatchStudentsPreview(bSel.value);
  }

  const modeSel = document.getElementById('ttAssignMode');
  if (modeSel) {
    modeSel.value = entry.assignMode || (entry.studentId ? 'student' : 'batch');
    modeSel.onchange = renderAssignmentMode;
  }
  const sSel = document.getElementById('ttStudent');
  if (sSel) {
    const students = getTimetableStudents();
    sSel.innerHTML = `<option value="">-- Select Student --</option>` +
      students.map(s => `<option value="${s.id}">${s.name} - ${s.batchNo || 'No Batch'} - ${s.course || 'No Course'}</option>`).join('');
    sSel.value = entry.studentId || '';
    sSel.onchange = () => renderStudentPreview(sSel.value);
  }

  renderAssignmentMode();
  renderBatchStudentsPreview(entry.batch || '');
  renderStudentPreview(entry.studentId || '');
  Modal.open('ttCellModal');
}

function renderAssignmentMode() {
  const mode = document.getElementById('ttAssignMode')?.value || 'batch';
  const batchGroup = document.getElementById('ttBatchGroup');
  const studentGroup = document.getElementById('ttStudentGroup');
  const batchPreview = document.getElementById('batchStudentsPreview');
  if (batchGroup) batchGroup.style.display = mode === 'batch' ? '' : 'none';
  if (studentGroup) studentGroup.style.display = mode === 'student' ? '' : 'none';
  if (batchPreview) batchPreview.style.display = mode === 'batch' ? '' : 'none';
}

function renderBatchStudentsPreview(batchNo) {
  const previewEl = document.getElementById('batchStudentsPreview');
  if (!previewEl) return;
  if (!batchNo) { previewEl.innerHTML = ''; return; }
  const students = getStudentsForBatch(batchNo);
  if (!students.length) {
    previewEl.innerHTML = `<div style="font-size:0.78rem;color:var(--text-muted);margin-top:8px">No students in ${batchNo}</div>`;
    return;
  }
  previewEl.innerHTML = `<div style="margin-top:10px">
    <div style="font-size:0.75rem;color:var(--text-muted);margin-bottom:6px">👥 ${students.length} student(s) in ${batchNo}:</div>
    <div style="display:flex;flex-wrap:wrap;gap:4px">
      ${students.map(s=>`<span style="font-size:0.72rem;background:rgba(94,234,212,0.12);color:var(--primary);border-radius:6px;padding:3px 8px">${s.name}</span>`).join('')}
    </div>
  </div>`;
}

function renderStudentPreview(studentId) {
  const previewEl = document.getElementById('studentSelectionPreview');
  if (!previewEl) return;
  if (!studentId) { previewEl.innerHTML = ''; return; }
  const s = DB.getStudent(studentId);
  if (!s) { previewEl.innerHTML = ''; return; }
  previewEl.innerHTML = `<div style="margin-top:8px;font-size:0.78rem;color:var(--text-muted)">
    Selected: <strong style="color:var(--primary)">${s.name}</strong> | ${s.batchNo || 'No Batch'} | ${s.course || 'No Course'}
  </div>`;
}

function saveTTCell() {
  if (!editingCell) return;
  const assignMode = document.getElementById('ttAssignMode')?.value || 'batch';
  const studentId = assignMode === 'student' ? (document.getElementById('ttStudent')?.value || '') : '';
  const selectedStudent = studentId ? DB.getStudent(studentId) : null;
  ttData.entries[editingCell] = {
    subject: document.getElementById('ttSubject').value,
    teacher: document.getElementById('ttTeacher').value,
    assignMode,
    batch:   assignMode === 'batch' ? document.getElementById('ttBatch').value : (selectedStudent?.batchNo || ''),
    studentId,
    studentName: selectedStudent ? selectedStudent.name : '',
    pc:      editingDevice,
    device:  editingDevice,
    notes:   document.getElementById('ttNotes').value,
  };
  DB.saveTimetable(ttData);
  renderTimetable();
  Modal.close('ttCellModal');
  Toast.success('Cell updated!');
  showAutoSave();
}

function clearTTCell() {
  if (!editingCell) return;
  delete ttData.entries[editingCell];
  DB.saveTimetable(ttData);
  renderTimetable();
  Modal.close('ttCellModal');
  Toast.info('Cell cleared');
}

function addTimeSlot() {
  const slot = document.getElementById('newTimeSlot').value.trim();
  if (!slot) { Toast.warning('Enter a time slot'); return; }
  if (ttData.timeSlots.includes(slot)) { Toast.warning('Slot already exists'); return; }
  ttData.timeSlots.push(slot);
  DB.saveTimetable(ttData);
  renderTimetable();
  document.getElementById('newTimeSlot').value='';
  Toast.success('Time slot added!');
}

function reindexEntriesAfterRemove(type, removedIdx) {
  const next = {};
  Object.entries(ttData.entries || {}).forEach(([key, entry]) => {
    const parts = key.split('_').map(Number);
    if (parts.length !== 2) return;
    const [slotIdx, deviceIdx] = parts;
    if (type === 'slot') {
      if (slotIdx === removedIdx) return;
      next[`${slotIdx > removedIdx ? slotIdx - 1 : slotIdx}_${deviceIdx}`] = entry;
    } else {
      if (deviceIdx === removedIdx) return;
      next[`${slotIdx}_${deviceIdx > removedIdx ? deviceIdx - 1 : deviceIdx}`] = entry;
    }
  });
  ttData.entries = next;
}

function removeTimeSlot(idx) {
  reindexEntriesAfterRemove('slot', idx);
  ttData.timeSlots.splice(idx,1);
  DB.saveTimetable(ttData);
  renderTimetable();
  Toast.info('Time slot removed');
}

function addDevice() {
  const device = document.getElementById('newDevice').value.trim();
  if (!device) { Toast.warning('Enter a PC or laptop name'); return; }
  const devices = getDevices();
  if (devices.includes(device)) { Toast.warning('Device already exists'); return; }
  ttData.devices = devices;
  ttData.devices.push(device);
  ttData.days = ttData.devices;
  DB.saveTimetable(ttData);
  renderTimetable();
  refreshTimetableFilterOptions();
  document.getElementById('newDevice').value='';
  Toast.success('Device added!');
}

function removeDevice(idx) {
  const devices = getDevices();
  reindexEntriesAfterRemove('device', idx);
  devices.splice(idx,1);
  ttData.devices = devices;
  ttData.days = devices;
  DB.saveTimetable(ttData);
  renderTimetable();
  refreshTimetableFilterOptions();
  Toast.info('Device removed');
}

function renderSlotManagement() {
  const slotsEl = document.getElementById('slotsList');
  const devicesEl  = document.getElementById('devicesList');
  if(slotsEl) slotsEl.innerHTML = ttData.timeSlots.map((s,i)=>
    `<div style="display:flex;align-items:center;justify-content:space-between;padding:6px 10px;background:var(--glass-bg-ultra-light);border-radius:6px;margin-bottom:4px">
      <span style="font-size:0.85rem">${s}</span>
      <button class="btn btn-sm btn-danger" onclick="removeTimeSlot(${i});renderSlotManagement()">✕</button>
    </div>`).join('');
  if(devicesEl) devicesEl.innerHTML = getDevices().map((d,i)=>
    `<div class="device-chip-row">
      <span style="font-size:0.85rem">${deviceIcon(d)} ${d}</span>
      <button class="btn btn-sm btn-danger" onclick="removeDevice(${i});renderSlotManagement()">✕</button>
    </div>`).join('');
}

function printTimetable() {
  const { timeSlots, entries } = ttData;
  const devices = getDevices();
  const settings = DB.getSettings();
  const students = DB.getStudents();

  let table = `<table style="width:100%;border-collapse:collapse;font-size:10px">
    <thead><tr><th style="border:1px solid #ccc;padding:6px;background:#047857;color:#fff">Time</th>
    ${devices.map(d=>`<th style="border:1px solid #ccc;padding:6px;background:#047857;color:#fff">${d}</th>`).join('')}
    </tr></thead><tbody>`;
  timeSlots.forEach((slot,si)=>{
    table += `<tr><td style="border:1px solid #ccc;padding:6px;font-weight:700;color:#047857;white-space:nowrap">${slot}</td>`;
    devices.forEach((device,di)=>{
      const e = entries[`${si}_${di}`]||{};
      const batchStudents = e.batch ? getTimetableStudents().filter(s=>s.batchNo===e.batch) : [];
      const studentNames = batchStudents.slice(0,3).map(s=>s.name.split(' ')[0]).join(', ') +
        (batchStudents.length>3?` +${batchStudents.length-3}`:'' );
      const singleStudent = e.studentName || (e.studentId && DB.getStudent(e.studentId)?.name) || '';
      const assignedDevice = e.device || e.pc || device;
      table += `<td style="border:1px solid #ccc;padding:5px;vertical-align:top;font-size:10px">
        ${e.subject?`<div style="font-weight:700;color:#047857">${e.subject}</div>`:''}
        ${e.teacher?`<div style="color:#555">${e.teacher}</div>`:''}
        ${e.batch?`<div style="color:#7c3aed;font-weight:600">${e.batch} | ${assignedDevice}</div>`:''}
        ${singleStudent?`<div style="color:#059669;font-weight:600">${singleStudent}</div>`:''}
        ${studentNames?`<div style="color:#065f46;font-size:9px">${studentNames}</div>`:''}
      </td>`;
    });
    table += `</tr>`;
  });
  table += `</tbody></table>`;
  Exporter.toPDF_simple('PC Laptop Time Table', `<h2 style="color:#047857">${settings.academyName} — PC/Laptop Time Table</h2>${table}`);
}

function renderBatchOverview() {
  const students = getTimetableStudents();
  const batches = {};
  students.forEach(s=>{ if(s.batchNo){if(!batches[s.batchNo])batches[s.batchNo]=[];batches[s.batchNo].push(s);} });
  const el = document.getElementById('batchOverview');
  if(!el) return;
  if(!Object.keys(batches).length){el.innerHTML='<span style="font-size:0.82rem;color:var(--text-muted)">No matching batches. Change the course status filter or assign batch numbers in Students.</span>';return;}
  el.innerHTML = Object.entries(batches).map(([batch,sts])=>`
    <div class="glass-card" style="min-width:180px;padding:12px">
      <div style="font-weight:700;color:var(--primary);margin-bottom:8px">${batch}</div>
      <div style="display:flex;flex-direction:column;gap:3px">
        ${sts.map(s=>`<div style="font-size:0.78rem;display:flex;align-items:center;gap:6px">
          <span style="width:6px;height:6px;border-radius:50%;background:var(--primary);display:inline-block"></span>${s.name}
          <span style="font-size:0.7rem;color:var(--text-muted)">${s.pcNo||''}</span>
        </div>`).join('')}
      </div>
    </div>`).join('');
}

function bindTimetableForms() {
  renderSlotManagement();

  const addSlotBtn = document.getElementById('addSlotBtn');
  if(addSlotBtn) addSlotBtn.addEventListener('click', ()=>{ addTimeSlot(); renderSlotManagement(); });

  const addDeviceBtn = document.getElementById('addDeviceBtn');
  if(addDeviceBtn) addDeviceBtn.addEventListener('click', ()=>{ addDevice(); renderSlotManagement(); });
}

document.addEventListener('DOMContentLoaded', initTimetablePage);

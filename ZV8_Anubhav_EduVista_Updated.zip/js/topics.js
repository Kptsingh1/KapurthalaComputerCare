/* ==========================================================================
   TOPICS.JS — Daily Topics Management
   ========================================================================== */

let editingTopicId = null;

function initTopicsPage() {
  const session = Auth.requireAuth(['admin','teacher']);
  if (!session) return;
  renderTopicsList();
  bindTopicForm();
  populateStudentSelector();
  filterTable('topicSearch','topicsTableEl');
}

function populateStudentSelector() {
  const students = DB.getStudents();
  const teachers = DB.getTeachers();
  const sel = document.getElementById('tf_student');
  const tsel = document.getElementById('tf_teacher');
  if(sel){
    sel.innerHTML = `<option value="">-- Select Student --</option>` +
      students.map(s=>`<option value="${s.id}">${s.name} (${s.course||'—'})</option>`).join('');
  }
  if(tsel){
    tsel.innerHTML = `<option value="">-- Select Teacher --</option>` +
      teachers.map(t=>`<option value="${t.id}">${t.name}</option>`).join('');
  }
}

function renderTopicsList() {
  const topics = DB.getTopics();
  const tbody = document.getElementById('topicsTableBody');
  if (!tbody) return;

  tbody.innerHTML = topics.length ? topics.map(t=>`<tr>
    <td style="font-size:0.85rem;font-weight:600">${Fmt.date(t.date||t.createdAt)}</td>
    <td style="font-size:0.85rem">${t.time||'—'}</td>
    <td><div style="font-size:0.88rem;font-weight:600">${t.topic}</div>${t.subtopics?`<div style="font-size:0.75rem;color:var(--text-muted)">${t.subtopics}</div>`:''}</td>
    <td style="font-size:0.82rem">${t.studentName||'—'}</td>
    <td style="font-size:0.82rem">${t.teacherName||'—'}</td>
    <td style="font-size:0.82rem">${t.course||'—'}</td>
    <td><span class="badge ${t.status==='Completed'?'badge-success':t.status==='Pending'?'badge-warning':'badge-info'}">${t.status||'—'}</span></td>
    <td>
      <div style="display:flex;gap:6px">
        <button class="btn btn-sm btn-ghost" onclick="editTopic('${t.id}')">✏️</button>
        <button class="btn btn-sm btn-danger" onclick="deleteTopic('${t.id}')">🗑</button>
      </div>
    </td>
  </tr>`).join('') : '<tr><td colspan="8" style="text-align:center;padding:30px;color:var(--text-muted)">No topics added yet</td></tr>';
}

function openAddTopicModal() {
  editingTopicId = null;
  document.getElementById('topicModalTitle').textContent = '➕ Add Daily Topic';
  document.getElementById('topicForm').reset();
  // Set today
  const dateEl = document.getElementById('tf_date');
  const timeEl = document.getElementById('tf_time');
  if(dateEl) dateEl.value = new Date().toISOString().slice(0,10);
  if(timeEl) timeEl.value = new Date().toTimeString().slice(0,5);
  Modal.open('topicModal');
}

function editTopic(id) {
  editingTopicId = id;
  const topics = DB.getTopics();
  const t = topics.find(x=>x.id===id);
  if (!t) return;
  document.getElementById('topicModalTitle').textContent = '✏️ Edit Topic';
  const fields = ['topic','subtopics','date','time','course','status','notes','homework'];
  fields.forEach(f=>{ const el=document.getElementById('tf_'+f); if(el) el.value=t[f]||''; });
  const sel = document.getElementById('tf_student');
  if(sel) sel.value = t.studentId||'';
  const tsel = document.getElementById('tf_teacher');
  if(tsel) tsel.value = t.teacherId||'';
  Modal.open('topicModal');
}

function bindTopicForm() {
  const form = document.getElementById('topicForm');
  if (!form) return;
  form.addEventListener('submit', e=>{
    e.preventDefault();
    const get = id=>{ const el=document.getElementById('tf_'+id); return el?el.value:''; };
    const studentSel = document.getElementById('tf_student');
    const teacherSel = document.getElementById('tf_teacher');
    const studentId = studentSel ? studentSel.value : '';
    const teacherId = teacherSel ? teacherSel.value : '';
    const students = DB.getStudents();
    const teachers = DB.getTeachers();
    const student = students.find(s=>s.id===studentId);
    const teacher = teachers.find(t=>t.id===teacherId);

    const topic = {
      topic:       get('topic'),
      subtopics:   get('subtopics'),
      date:        get('date'),
      time:        get('time'),
      course:      get('course'),
      status:      get('status')||'Pending',
      notes:       get('notes'),
      homework:    get('homework'),
      studentId,
      studentName: student ? student.name : '',
      teacherId,
      teacherName: teacher ? teacher.name : '',
    };

    if(!topic.topic.trim()){ Toast.warning('Topic name is required'); return; }

    if(editingTopicId){
      DB.updateTopic(editingTopicId, topic);
      Toast.success('Topic updated!');
    } else {
      DB.addTopic(topic);
      Toast.success('Topic added!');
    }
    Modal.close('topicModal');
    renderTopicsList();
    showAutoSave();
  });
}

function deleteTopic(id) {
  if(!confirm('Delete this topic?')) return;
  DB.deleteTopic(id);
  renderTopicsList();
  Toast.success('Deleted');
}

function exportTopics() {
  const topics = DB.getTopics();
  const headers = ['Date','Time','Topic','Subtopics','Student','Teacher','Course','Status','Notes'];
  const rows = topics.map(t=>[t.date||'',t.time||'',t.topic,t.subtopics||'',t.studentName||'',t.teacherName||'',t.course||'',t.status||'',t.notes||'']);
  Exporter.toCSV(headers,rows,'topics.csv');
  Toast.success('Exported!');
}

function filterTopicsByStudent() {
  const val = document.getElementById('topicStudentFilter').value.toLowerCase();
  document.querySelectorAll('#topicsTableBody tr').forEach(row=>{
    row.style.display = !val || row.textContent.toLowerCase().includes(val) ? '' : 'none';
  });
}

document.addEventListener('DOMContentLoaded', initTopicsPage);
